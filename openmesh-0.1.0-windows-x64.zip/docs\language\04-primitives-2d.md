# 2D primitives

This page specifies the four sketch constructors: `rect`, `circle`, `polygon`, and `path`. A `Sketch` is the input to
`extrude`, `revolve`, `offset`, 2D booleans, and SVG or DXF export.

Sketches live in the XY plane at `z = 0`. Lengths are millimetres. A closed sketch has an interior and can be used
for booleans and solid conversion; an open sketch is a polyline and is exported as a cut or engraving path. The
winding of a closed sketch is normalized automatically: outer loops become counter-clockwise and holes become
clockwise.

## rect

Creates an axis-aligned rectangle, either with a corner at the origin or centered on it.

### Signature

```om
rect(w: Length, h: Length, center: Bool = false) -> Sketch
```

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `w` | `Length` | mm | required | `w > 0` | width along X |
| `h` | `Length` | mm | required | `h > 0` | height along Y |
| `center` | `Bool` | bool | `false` | none | center the rectangle on the origin |

### Example

```om
// @om 1
let panel = rect(w = 80mm, h = 50mm, center = true);
export(panel, "panel.svg");
```

### Result

Bounding box `80 x 50 mm`, area `4000 mm2`, perimeter `260 mm`, 4 vertices, 4 edges. With `center = false` the
rectangle spans `x = 0..80` and `y = 0..50`.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0202` | a bare number is passed | add `mm` |
| `E0207` | `w <= 0` or `h <= 0` | use positive dimensions |

### See also

- [offset](#offset)
- [Extrude](07-2d-to-3d.md#extrude)

## circle

Creates a regular polygon approximation of a circle, centered on the origin.

### Signature

```om
circle(d: Length, segments: Number = 64) -> Sketch
```

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `d` | `Length` | mm | required | `d > 0` | diameter |
| `segments` | `Number` | count | `64` | integer, 3..1024 | number of sides |

### Example

```om
// @om 1
let hole = circle(d = 50mm, segments = 64);
export(hole, "hole.svg");
```

### Result

Bounding box `50 x 50 mm`, centered on the origin. Ideal area `1963.50 mm2`; the 64-gon mesh area is
`1960.34 mm2`, 0.16% smaller. Perimeter `157.08 mm`, 64 vertices.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0207` | `d <= 0` | use a positive diameter |
| `E0207` | `segments < 3` | raise the count |
| `E0903` | the polygon exceeds the entity limit | lower `segments` |

### See also

- [Polygon](#polygon)
- [Revolve](07-2d-to-3d.md#revolve)

## polygon

Creates a closed sketch from a point list, with optional inner holes. Use it for profiles that come from SVG paths,
traced outlines, or computed point lists.

### Signature

```om
polygon(points: List<Vec2>, holes: List<List<Vec2>> = []) -> Sketch
```

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `points` | `List<Vec2>` | mm | required | at least 3, no self-intersection, non-zero area | outer boundary |
| `holes` | `List<List<Vec2>>` | mm | `[]` | 3+ points, inside the outer boundary, no intersections | inner boundaries |

The compiler normalizes winding: the outer boundary becomes counter-clockwise and every hole becomes clockwise. A
self-intersecting boundary is `E0303`; a hole that touches or crosses the outer boundary is `E0303`; a zero-area
polygon is `E0305`.

### Example

```om
// @om 1
let outer = [
    [0mm, 0mm], [60mm, 0mm], [60mm, 40mm], [0mm, 40mm],
];
let hole = [
    [20mm, 15mm], [40mm, 15mm], [40mm, 25mm], [20mm, 25mm],
];
let plate = polygon(outer, holes = [hole]);
export(plate, "plate.svg");
```

### Result

Bounding box `60 x 40 mm`, area `2400 - 200 = 2200 mm2`, 8 vertices, 8 edges. The hole is subtracted from the
interior, not from the boundary.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0303` | boundary crosses itself or a hole crosses the boundary | remove the crossing |
| `E0305` | the outer boundary has zero area | order the points around a real region |
| `E0207` | fewer than 3 points | supply a closed boundary |
| `E0201` | a point has three components | pass `Vec2` points to `polygon` |

### See also

- [path](#path)
- [2D to 3D](07-2d-to-3d.md)
- [Logo extrusion](../recipes/logo-extrusion.md)

## path

Creates an open or closed polyline. An open path is a 2D cut or engraving curve; a closed path is a sketch usable by
booleans and `extrude`.

### Signature

```om
path(points: List<Vec2>, closed: Bool = false) -> Sketch
```

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `points` | `List<Vec2>` | mm | required | at least 2 points, no duplicate consecutive points | polyline vertices |
| `closed` | `Bool` | bool | `false` | none | connect the last point to the first |

### Example

```om
// @om 1
let slot = path(
    points = [[0mm, 0mm], [40mm, 0mm], [40mm, 10mm], [0mm, 10mm]],
    closed = true,
);
let plate = rect(80mm, 30mm, center = true);
export(difference(plate, slot.translate([0mm, -5mm])), "slot.dxf");
```

### Result

The closed path is a 40 x 10 mm rectangle, area `400 mm2`; `difference` cuts it from the 80 x 30 mm plate, leaving
`2400 - 400 = 2000 mm2`. With `closed = false` the same points produce three line segments and area `0`.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0304` | an open path is used by extrude, revolve, offset, or a boolean | set `closed = true` or use `polygon` |
| `E0207` | fewer than 2 points | add a point |
| `E0305` | two consecutive points coincide | remove the duplicate |

### See also

- [polygon](#polygon)
- [Sweep](07-2d-to-3d.md#sweep)
- [Laser panel](../recipes/laser-panel.md)

## offset

Expands or shrinks a closed sketch, with rounded or sharp corners. The full signature is in
[2D to 3D](07-2d-to-3d.md#offset); this section covers the 2D behavior used by the examples above.

```om
offset(sketch: Sketch, r: Length = 0mm, delta: Length = 0mm, join: String = "round",
       segments: Number = 8) -> Sketch
```

`r` offsets with rounded corners and adds `segments` points per corner. `delta` offsets with sharp corners;
`join = "round" | "miter" | "square"` controls the corner shape. Exactly one of `r` and `delta` must be non-zero
(`E0207`). A negative value shrinks the sketch; if the offset collapses the region, the result is `E0315`.

```om
// @om 1
let rounded = rect(40mm, 20mm).offset(r = 5mm);
export(rounded, "rounded.svg");
```

The rounded rectangle has bounding box `50 x 30 mm`, area `1478.54 mm2`, and 36 vertices with the default
`segments = 8` per corner.

## Next

- [3D primitives](03-primitives-3d.md)
- [2D to 3D](07-2d-to-3d.md)
- [Laser panel recipe](../recipes/laser-panel.md)
