# Installation

> **Status: released.** OpenMesh 0.1.0 is available as a portable Windows x64 archive. The compiler is pre-1.0; the
> language and the CLI may still change.

This page installs OpenMesh from the portable archive and verifies that the build runs. The flow takes two minutes and
needs no administrator rights.

## Requirements

| Item | Requirement |
|---|---|
| OS | Windows 10/11 x64, or Linux x64 with glibc 2.31 or newer |
| CPU | x86-64 with SSE4.2 |
| RAM | 512 MiB minimum, 2 GiB for comfortable editing |
| Disk | 120 MiB for the binary and documentation |
| Display | none for `build`, `check`, `render`, and `mcp`; the editor needs a desktop session |
| GPU | none; the viewport uses a CPU rasterizer |
| Runtime | none; the archive contains a native binary |

OpenMesh does not install Python, .NET, Java, or a browser engine. The CLI works on headless Linux without X11 or
Wayland, which is the supported configuration for CI and for an MCP server.

## Windows

1. Download `openmesh-0.1.0-windows-x64.zip` from the release page.
2. Verify the checksum against `SHA256SUMS.txt`:

```powershell
Get-FileHash .\openmesh-0.1.0-windows-x64.zip -Algorithm SHA256
```

3. Extract to a per-user directory:

```powershell
New-Item -ItemType Directory -Force "$env:LOCALAPPDATA\OpenMesh" | Out-Null
Expand-Archive .\openmesh-0.1.0-windows-x64.zip -DestinationPath "$env:LOCALAPPDATA\OpenMesh" -Force
```

4. Add the directory to the user `PATH` for new terminals:

```powershell
$dir = "$env:LOCALAPPDATA\OpenMesh"
$old = [Environment]::GetEnvironmentVariable("Path", "User")
[Environment]::SetEnvironmentVariable("Path", "$old;$dir", "User")
```

5. Open a new terminal and verify:

```powershell
openmesh version
```

Expected output:

```text
openmesh 0.1.0 (oml 1.0)
```

The archive layout is flat: `openmesh.exe`, `docs/`, `LICENSE`, and `README.md` at the root. If Windows SmartScreen
blocks the unsigned binary, choose "More info" and "Run anyway", or verify the checksum before running.

## Linux

This release ships Windows x64 only. The compiler also runs on Linux x64, but no Linux archive is published with 0.1.0.

## Portable layout

```text
openmesh.exe
docs/
  start/
  language/
  cli/
  mcp/
  ai/
  recipes/
  reference/
  llms.txt
assets/
  icon.png
LICENSE
README.md
```

The built-in documentation viewer reads these files from disk. The same files are the context for an MCP agent, so
the manual and the model see one source of truth.

## Verification

```bash
openmesh version
openmesh docs --list
openmesh check --help
```

`docs --list` prints the relative path of every documentation page. `check --help` prints the flags for parse and
typecheck.

Create a one-line model and compile it:

```om
// @om 1
export(box([20mm, 20mm, 20mm], center = true), "cube.glb");
```

```bash
openmesh check cube.om --json
openmesh build cube.om -o cube.glb
```

`check` returns `{"ok": true}` with no diagnostic. `build` writes `cube.glb` and prints the bounding box and volume.

## Live viewport

This release is command-line only. A live viewport is in development but is not part of the archive; `preview` and
`render` produce images headlessly.

## Uninstallation

Remove the install directory and the `PATH` entry. No registry keys, services, or global caches are created. Project
caches live in `.openmesh-cache/` next to the project root and can be deleted at any time.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `openmesh: command not found` | `PATH` not updated in the current shell | open a new terminal |
| SmartScreen warning on Windows | unsigned portable binary | verify the checksum, then allow the file |
| `version` prints an older release | another binary earlier in `PATH` | run `where openmesh` |
| `docs` prints nothing | `docs/` is not next to the executable | extract the whole archive, not only `openmesh.exe` |
| `om_search_docs` fails in MCP | same reason | keep `docs/` next to the executable |

## Next

- [First model](02-first-model.md)
- [Open in Blender](03-open-in-blender.md)
- [Live preview](05-preview.md)
- [CLI usage](../cli/01-usage.md)
