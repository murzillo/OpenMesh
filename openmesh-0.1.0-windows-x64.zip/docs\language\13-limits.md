# Limits

This page lists the default resource limits, the flags that change them, and the exact behavior when a limit is
reached. Read it before running a large boolean, a high-resolution revolve, or a CI build on a small runner.

## Defaults

| Resource | Default | Measured by | Diagnostic |
|---|---|---|---|
| CPU time | 10 s | evaluator and CSG | `E0901` |
| Memory | 512 MiB | peak resident set size | `E0902` |
| Triangles | 2,000,000 | final mesh, all exported solids combined | `E0903` |
| Recursion | 64 frames | function call depth | `E0904` |
| Import depth | 16 files | chain of `import` | `E0905` |
| Source size | 16 MiB | root plus imported `.om` files | `E0906` |

The limits are per build, not per model. A build that exports three files shares one CPU and one memory budget. The
triangle count is the sum of the triangles written to all artifacts; a boolean that creates an intermediate mesh
larger than the final mesh still counts against memory and CPU, not against the final triangle limit.

CPU time is process CPU, not wall-clock time. The CSG stage is single-threaded and deterministic, so the budget covers
the same work on every machine. A machine with fewer cores reaches the limit at roughly the same point in the model,
only later in wall-clock time.

## Limit behavior

A limit violation produces `E09xx`, reports the actual value and the limit, writes no artifact, and exits with
code 3 for the CLI. The compiler never truncates a mesh, never writes a partial file, and never returns an empty
artifact.

```json
{
  "code": "E0903",
  "severity": "error",
  "message": "triangle limit exceeded: 2341882 triangles (limit 2000000)",
  "span": { "start": 0, "end": 0, "line": 1, "col": 1 },
  "hint": "Lower sphere segments/rings or raise --triangle-limit; the message reports the actual count.",
  "doc": "docs/language/12-errors.md#e0903"
}
```

Artifacts are written atomically: the writer creates a temporary file next to the target, flushes it, then renames
it. A failed build leaves the previous artifact untouched. A successful build replaces the target in one rename.

## Flags

| Flag | Unit | Example | Effect |
|---|---|---|---|
| `--time-limit` | duration | `--time-limit 30s` | CPU budget; accepts `ms`, `s`, `m` |
| `--memory-limit` | size | `--memory-limit 1GiB` | peak memory; accepts `MiB`, `GiB` |
| `--triangle-limit` | count | `--triangle-limit 500000` | final triangle budget |
| `--max-recursion` | frames | `--max-recursion 32` | function call depth |
| `--max-import-depth` | files | `--max-import-depth 8` | import chain length |
| `--max-source-size` | size | `--max-source-size 4MiB` | root plus imports |
| `--max-artifact-size` | size | `--max-artifact-size 512MiB` | one artifact |

All flags apply to `build`, `check`, `preview`, `render`, and `mcp`. The MCP server passes its configured limits to
every tool call; an individual call cannot raise them. A duration without a suffix is seconds; a size without a
suffix is bytes, which is rarely useful.

```bash
openmesh build large.om -o large.glb --time-limit 60s --memory-limit 2GiB --triangle-limit 8000000
openmesh check model.om --json --triangle-limit 100000
```

## Determinism and limits

Successful output is byte-identical for a given source, parameter set, compiler version, and format. Limits do not
change bytes; they only decide whether a build completes. A time limit is the one exception to reproducibility
across machines: a slower runner can fail a build that succeeds on a fast workstation even though both would
produce identical bytes. For CI, set a generous `--time-limit` and a strict `--triangle-limit`, because the triangle
count is deterministic and the CPU time is not.

## Triangle budget

Use these formulas to predict the cost before compiling:

| Operation | Triangles | Example |
|---|---|---|
| `box` | 12 | 40 x 20 x 10 mm |
| `sphere(d, segments, rings)` | `2 * segments * (rings - 1)` | 32 x 16 = 960 |
| `cylinder(h, d, d2, segments)` | `4 * segments - 4` | 48 -> 188 |
| `cone(h, d, segments)` | `2 * segments - 2` | 48 -> 94 |
| `torus(D, d, segments, sides)` | `2 * segments * sides` | 64 x 24 = 3072 |
| `extrude(sketch, h, slices)` | `2 * n * slices + 2 * (n - 2)` | rectangle, 1 slice -> 12 |
| `revolve(sketch, angle, segments)` | proportional to `segments * profile edges` | 64 x 4 -> 512 |
| `subdivide(level)` | `input * 4^level` | 12 -> 48 at level 1 |
| `array(count)` | `input * count` before union | 12 x 4 -> 48 |
| `minkowski(a, b)` | approximately `triangles(a) * triangles(b)` | 12 x 960 -> 11520 |

Booleans do not have a simple formula. The output is bounded by the sum of the inputs plus the new intersection
curves; a cut through many faces can triple the count. `om_query_geometry` returns the exact final count before an
export.

## Memory budget

A useful estimate is `80 bytes * triangles + 32 bytes * vertices`, multiplied by 2 to 3 for the intermediate
copies that the engine keeps during a boolean. A 2-million-triangle model therefore needs roughly 350-500 MiB and sits
at the default limit. Reduce the triangle count before raising the memory limit: a mesh that fits in 512 MiB also
exports and previews faster.

## Cost reduction

| Symptom | Change |
|---|---|
| Sphere-dominated mesh | lower `rings` before `segments`; the triangle count is linear in both |
| Many holes | lower each hole's `segments` to 24-32; a 6 mm hole does not need 64 sides |
| Repeated fillets | lower `segments` to 2-3; each segment is a strip around the edge |
| Minkowski | replace with `fillet` or a rounded profile; the cost is multiplicative |
| Deep boolean tree | union cutters once, then a single `difference` |
| Large text or point tables | decimate the points before `polygon`; the compiler cannot simplify a sketch |
| Preview slow, export fast | lower `--size` or render only the top view; both are CPU-rendered |

## Geometry fidelity

The 0.1.0 engine is self-contained: 3D booleans use a BSP tree with T-junction repair, 2D booleans use `i_overlay`,
and rounded offsets use `cavalier_contours`. It does not link an external CAD kernel. Five operations are
approximations rather than exact constructions, and the approximation is visible in the result:

| Operation | What the compiler does | What you see |
|---|---|---|
| `fillet`, `chamfer` | ordered plane cuts, `segments` planes per edge | a faceted arc; raise `segments` for a smoother edge |

A closed circular rim is chamfered with one revolved cutter, so a cylinder, a flange, or a hole entrance gets a
symmetrical ring instead of a series of gaps. A `fillet` still cuts edge by edge.
| `fillet` on a concave edge | skipped | the edge stays sharp |
| `fillet` thinner than the wall | may leave a seam | `E0308` when the result is unusable |
| `shell` | inset cavity subtracted from the body | when the cavity cannot be inset cleanly, a box cavity is used instead |
| `minkowski` | exact for convex operands | a concave operand is replaced by its convex hull |

The watertight check is tolerant by design: boundary loops that enclose less than 1 mm² and up to 32 non-manifold
edges are accepted, so CSG output stays printable. A genuinely open shell or an uncapped sweep still fails with
`E0311`.

Every modifier is also checked for locality. After `fillet`, `chamfer`, and `shell` the compiler compares the result
with the input body: the bounding box may shrink by at most the operation's reach, the volume may not grow, and the
removed volume must be explainable by the selected edge length. A violation stops the build with
[`E0318`](12-errors.md#e0318) instead of writing a wrong mesh.

These are contract limits for 0.1.0, not bugs to report. A model that needs an exact concave fillet should use an
explicit profile, a larger radius, or a boolean with a rounded cutter.

## Preview and export limits

| Limit | Default | Flag |
|---|---|---|
| Contact sheet long edge | 1024 px | `--size` (max 2048) |
| Contact sheet views | 4 | `--views` (max 4) |
| Preview time | 20 s | `--time-limit` |
| Render p95 | 1.5 s at 1024 px | none |
| Export artifact size | 1 GiB | `--max-artifact-size` |
| SVG/DXF entities | 2,000,000 | `--triangle-limit` |

The viewport and the headless renderer use the CPU rasterizer; they need no GPU and no X11. A model with more than
500,000 triangles is slow at 1024 px; lower `--size` to 512 for iteration and render the final contact sheet at
1536. The `software` renderer produces byte-identical PNGs; `auto` may use a GPU and may change bytes.

## MCP limits

The MCP server enforces the same limits per call. `om_validate` and `om_query_geometry` use the triangle limit only
for geometry evaluation; `om_compile` and `om_export` also apply the artifact size limit; `om_preview` applies the
view count, size, and render time limits. A tool that exceeds a limit returns `{ok: false}` with an `E09xx`
diagnostic and no partial file. The MCP client should stop retrying after three attempts and ask the user, as
described in [Error contract](../mcp/04-error-contract.md).

## Example

```bash
openmesh build enclosure.om -o enclosure.glb --triangle-limit 300000 --json
```

If the result has 412,880 triangles, the response is:

```json
{
  "ok": false,
  "command": "build",
  "exit_code": 3,
  "diagnostics": [
    {
      "code": "E0903",
      "severity": "error",
      "message": "triangle limit exceeded: 412880 triangles (limit 300000)",
      "span": { "start": 0, "end": 0, "line": 1, "col": 1 },
      "hint": "Lower fillet segments or sphere rings, or raise --triangle-limit.",
      "doc": "docs/language/12-errors.md#e0903"
    }
  ]
}
```

The target file keeps its previous contents. Lower the fillet `segments` from 4 to 2 and rerun; the triangle count
drops by roughly 40% and the visual difference at 0.2 mm layer height is below the printer resolution.

## Next

- [Errors](12-errors.md)
- [CLI build and CI](../cli/02-build-and-ci.md)
- [Export formats](../cli/03-export-formats.md)
