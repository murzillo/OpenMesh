# Live preview

This page specifies the viewport: how fast it rebuilds, what happens when compilation fails, how sliders behave, and
what each display mode shows. Read it to interpret `up to date`, `stale`, and the red diagnostic banner correctly.

> **Status: prototype.** `openmesh-view` (CPU) and `openmesh-view-gpu` (wgpu) open one window, recompile on file
> change, and keep the last good mesh on error. Orbit works in the GPU build; the CPU build has fixed views.

## Behavior

The viewport is a second loop around the compiler, not a separate renderer of the source text.

| Behavior | Value |
|---|---|
| Rebuild debounce | 150 ms after the last keystroke |
| Immediate rebuild | `Ctrl+Enter` |
| Draft quality | 16 ms after a change |
| Full quality | 150 ms after the last change |
| Failed compile | keep the last good mesh, show a red banner with the first diagnostic |
| Slider update | real-time; lazy mode if a rebuild takes more than 100 ms |
| Stale indicator | `up to date` or `stale 340 ms` |
| Export | always rebuilds from the source; the cache is never the source of truth |

The first compile of a session can take longer than the steady-state budget because the viewport process loads the
compiler and builds the initial scene. The 150 ms target applies to a warm process.

## Timing budget

Measured at p95 on a 4-core machine with 16 GB RAM and no discrete GPU:

| Operation | Budget |
|---|---|
| Parse | 2 ms |
| Compile a typical model (10-50 primitives) | 300 ms |
| Frame while orbiting | 16 ms |
| Process memory | 512 MB |

A model that exceeds the compile budget still previews; the draft level keeps the viewport responsive. A model that
exceeds the memory budget fails with `E0902` and the viewport shows the last good mesh.

Measured on the 14-model corpus: compile p50 is 281 ms and p95 is 2.3 s; the slowest case is the RPi assembly
(54k triangles, 2.9 s). A frame at 900 px takes 14 ms for a 254-triangle part and 93 ms for that assembly. The 300 ms
compile target holds for models under roughly 10 primitives; boolean-heavy assemblies exceed it.

## Prototype

```bash
cargo run --release --features viewer --bin openmesh-view -- --root . model.om
```

Keys: `drag` orbit, `wheel` zoom, `1` iso, `2` front, `3` top, `4` right, `P` panel, `R` rebuild, `Esc` quit. The title
bar shows the last compile status. The window polls the file every frame with a 150 ms debounce, prints `ok <ms>` on
success, and keeps the previous geometry when a compile fails.

Every `@param` with `min` and `max` appears as a slider in the right panel. Drag it or use the wheel over it; the model
rebuilds 150 ms after the last change, and the camera keeps the model inside the free area left of the panel. Parameters
without a range are skipped.

There are two binaries:

```bash
# GPU: wgpu surface, orbit at the display refresh rate
cargo run --release --features viewer-gpu --bin openmesh-view-gpu -- --root . model.om

# CPU: minifb framebuffer, no GPU dependency
cargo run --release --features viewer --bin openmesh-view -- --root . model.om
```

`openmesh-view-gpu --once out.png` renders one frame offscreen and exits, which is how the pipeline is checked without
a screenshot. The GPU path draws shaded triangles plus feature edges and reaches 17 ms per frame for the
54k-triangle RPi assembly at 1000x800; the CPU path takes 93 ms at 900 px. Without a GPU adapter the GPU binary exits
with a message that points at the CPU viewer.

The GPU window draws a status bar over the scene. On a failed compile the bar turns red, names the first diagnostic,
keeps the last good mesh visible, and tints the background; the full message is also printed to the terminal and shown
in the title.

## Last good mesh

A failed compile never empties the viewport. The previous geometry stays visible, dimmed, with a red banner:

```text
E0203  missing unit suffix  line 5, col 20
hint: write 10mm instead of 10
```

The editor highlights the span and keeps the banner until the next successful compile. The stale indicator changes
to `stale` with the time since the last successful build. This behavior prevents a typo from looking like a deleted
model.

An export from a failed compile still fails. The last good mesh is a viewport aid, not a valid artifact; `openmesh
build` returns code 1 and leaves the previous file on disk untouched.

## Quality levels

| Level | Latency | What it rebuilds |
|---|---|---|
| Draft | 16 ms | reuses the last mesh topology; applies new transforms, colors, and parameter values |
| Full | 150 ms | parse, typecheck, CSG, validation, and mesh statistics |

The draft level is an approximation for display. A parameter that changes topology, such as the number of holes or a
boolean operand, appears at the full rebuild. The status line shows `draft` while the draft is on screen and
`up to date` after the full rebuild.

If a full rebuild takes more than 100 ms, a slider switches to lazy mode: the draft follows the drag, and the full
rebuild runs when the user releases the handle. A fast model keeps the real-time behavior.

## Stale indicator

| Text | Meaning |
|---|---|
| `up to date` | the viewport matches the current source and parameters |
| `stale 340 ms` | the source changed 340 ms ago and the full rebuild has not finished |
| `stale, error` | the latest compile failed; the viewport shows the last good mesh |
| `draft` | the 16 ms level is on screen |

The indicator is the only reliable way to know whether the image matches the file. A screenshot taken during
`stale` is not evidence that the current source compiles.

## Display modes

| Mode | Shows | Use |
|---|---|---|
| Shaded + edges | shaded faces plus feature edges | general modeling |
| Wireframe | triangle edges only | topology inspection |
| Section | a cut at a plane on X, Y, or Z with a slider | internal features, wall thickness |
| Thickness | a color map of local wall thickness | 3D printing |
| Bbox + dimensions | bounding box and labeled dimensions in mm | verifying size |
| 2D sheet | the sketch contour over a stock outline | laser and CNC setup |

Section mode keeps the cut plane at a slider position and draws the cut faces in a contrasting color. Thickness mode
samples the distance to the nearest opposite surface and colors it from red (below 1.6 mm) through yellow (1.6-2.4
mm) to green (above 2.4 mm). The legend shows the numeric range in millimetres. At a 0.4 mm nozzle, 1.6 mm is four
perimeters.

The 2D sheet mode is available when the model exports a `Sketch`. It draws the contour over a stock rectangle, with
the margin and the part dimensions labeled.

## Software rasterizer

The viewport and the headless renderer share a CPU rasterizer. On Linux without a display server, the renderer uses
llvmpipe or OSMesa; hardware acceleration is optional and never required. A CI job runs with no GPU and no X11.

A preview PNG is deterministic: the camera framing, sampling pattern and seed, and compression are fixed. A
screenshot test can compare bytes across runs and machines. The `auto` renderer may use a GPU and may produce
different bytes on different hardware; tests use the `software` renderer.

## Contact sheet

For a model with vision, a single isometric image hides three sides. `om_preview` and `openmesh render` produce a
contact sheet by default: isometric plus front, top, and right orthographic views, a scale bar, and labeled
dimensions in one PNG.

| Views | Layout |
|---|---|
| 1 | 1 x 1 |
| 2 | 1 x 2 |
| 3 or 4 | 2 x 2 |

The contact sheet is deterministic and fits the model bounding box with a 10% margin. See
[Headless render](../cli/04-render.md) for the command and the mode flags.

## Keyboard

| Key | Action |
|---|---|
| `Ctrl+Enter` | compile immediately, bypassing the 150 ms debounce |

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Viewport is empty | no successful build yet | fix the first diagnostic |
| Viewport does not update | the compile is still running | wait for `up to date` or press `Ctrl+Enter` |
| Slider jumps | lazy mode released the handle | expected for a rebuild over 100 ms |
| Section is empty | the plane lies outside the model | move the section slider into the bounding box |
| Thickness map is gray | the model is not watertight | check `watertight`; close the solid |
| Preview is slow on a server | software rasterization at a large size | lower `--size`; `render` defaults to 1024 |

## Next

- [Headless render](../cli/04-render.md)
- [MCP tools](../mcp/03-tools.md)
- [Open in Blender](03-open-in-blender.md)
