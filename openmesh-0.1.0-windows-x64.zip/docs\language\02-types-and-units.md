# Types and units

This page lists the OML type system, the unit rules, and the numeric behavior that decides whether a model
compiles. Read it when a diagnostic reports a type or unit error, or before generating code that mixes dimensions.

## Type system

OML is statically typed. Types are checked before geometry is evaluated, so a type error never produces a partial
mesh.

| Type | Description | Examples |
|---|---|---|
| `Number` | 64-bit float; also used for integer counts | `3`, `1.5`, `1e-3` |
| `Length` | length with a compile-time unit tag, stored in metres | `10mm`, `2cm`, `1in`, `0.5m` |
| `Angle` | angle with a compile-time unit tag, stored in radians | `90deg`, `1.5rad` |
| `Bool` | `true` or `false` | `true` |
| `String` | UTF-8 text; used for paths, labels, and options | `"body.glb"` |
| `Vec2` | two lengths; components `.x` and `.y` | `[10mm, 5mm]` |
| `Vec3` | three lengths; components `.x`, `.y`, `.z` | `[10mm, 5mm, 2mm]` |
| `Sketch` | 2D contour, open or closed | result of `rect`, `circle`, `polygon`, `path` |
| `Solid` | watertight 2-manifold triangle mesh | result of `box`, `extrude`, booleans |
| `Color` | RGB, 8 bits per channel | `rgb(200, 60, 40)` |
| `List<T>` | homogeneous ordered list | `[1, 2, 3]`, `[solidA, solidB]` |
| `EdgeSelector` | edge filter; not geometry | `body.edges.where(vertical)` |
| `FaceSelector` | face filter; not geometry | `body.faces.where(top)` |

There is no `Int` type. A parameter that requires a count, such as `segments`, declares `Number` and rejects
non-integer or out-of-range values with `E0207`. A function returning `Solid` cannot return `Sketch`; the mismatch
is `E0201`.

## Length

OML has one length dimension with four display units:

| Suffix | Millimetres | Metres | Example |
|---|---|---|---|
| `mm` | 1 | 0.001 | `12.5mm` |
| `cm` | 10 | 0.01 | `2.4cm` |
| `m` | 1000 | 1 | `0.15m` |
| `in` | 25.4 | 0.0254 | `0.25in` |

The unit tag is part of the type. These operations are valid:

```om
let a = 10mm + 5mm;          // Length, tag mm
let b = 2 * 10mm;            // Length, tag mm
let c = 10mm / 2;            // Length, tag mm
let d = 10mm / 2mm;          // Number, 5
let e = to_mm(1in);          // Length, tag mm, 25.4mm
```

These operations are rejected:

```om
let a = 10mm + 5;            // E0204: Length + Number
let b = 10mm + 1in;          // E0205: mixed tags
let c = 10mm * 10mm;         // E0201: Length * Length has no type
let d = sin(10mm);           // E0202: sin takes Angle
```

Explicit conversion is required before mixed-unit arithmetic: `10mm + to_mm(1in)`. The compiler never inserts a
silent conversion. A model that says `10mm` means ten millimetres on every platform.

The bare literals `0` and `0.0` are polymorphic zero: they are accepted as `Length`, `Angle`, or `Number`. This
allows `[0mm, 0mm, 0mm]` to be written as `[0, 0, 0]` without weakening unit checking. Any other bare number in a
length position is `E0202` or `E0203`.

## Angle

| Suffix | Radians | Example |
|---|---|---|
| `deg` | pi/180 | `90deg`, `45deg` |
| `rad` | 1 | `1.5708rad` |

`sin`, `cos`, and `tan` take an `Angle`. `asin`, `acos`, and `atan` take a `Number` and return an `Angle`. `atan2(y, x)`
takes two `Number`s or two `Length`s of the same kind and returns an `Angle` in radians.
`to_deg` and `to_rad` convert an angle when a report or metadata needs a specific unit. `90deg + 0.5rad` is `E0205`;
write `90deg + to_deg(0.5rad)`.

```om
let radius = 30mm;
let step = 360deg / 12;
let ring = for i in 0..12 {
    cylinder(d = 4mm, h = 10mm).translate([radius * cos(step * i), radius * sin(step * i), 0mm])
};
```

`step * i` multiplies an `Angle` by a `Number` and returns an `Angle`. `radius * cos(...)` multiplies a `Length` by
a `Number` and returns a `Length`.

## Vectors

`Vec2` and `Vec3` hold lengths. Construct them with a list literal in a vector position, or with the explicit
constructors:

```om
let p = vec3(10mm, 0mm, 5mm);
let q = [10mm, 0mm, 5mm];       // Vec3 by context
let a = p.x;                     // Length
let b = length(p);               // Length, sqrt(125) mm
let n = normalize(p);            // Vec3
let d = dot(p, q);               // Number, 125
let r = cross(X, Y);             // Vec3, equals Z
```

`translate`, `scale`, `mirror`, and `sweep` accept vectors. A `Vec2` cannot be passed where a `Vec3` is required;
the mismatch is `E0201`. Vector equality is component-wise and exact; do not compare computed vectors with `==`.

## Precision

Lengths are converted to metres at compile time and stored as float64. The DSL prints millimetres, but arithmetic
runs in SI metres. Float64 gives about 15 significant decimal digits; at the scale of a metre, the resolution is
about 1e-16 m.

Geometry uses a weld tolerance of 1e-9 m (1e-6 mm). Two vertices closer than this are treated as one. The CSG engine
has its own weld tolerance and assumes a valid manifold input. For a cutter that touches a face
without crossing it, move it inward by at least 0.01 mm; relying on exact contact produces `E0307`.

Reports in the CLI and MCP use millimetres for lengths, square millimetres for area, and cubic millimetres for
volume. glTF files store metres; STL files store millimetres. The [export formats](../cli/03-export-formats.md)
page lists the unit of every format.

## Sketch and Solid

`Sketch` is a 2D contour in the XY plane. It can be open (`path(..., closed = false)`) or closed (`rect`,
`circle`, `polygon`, or `path(..., closed = true)`). Closed sketches support booleans, `offset`, `extrude`,
`revolve`, and `sweep` as a profile. Open sketches support transforms and export to SVG or DXF as cut or engraving
paths. An open sketch passed to `extrude`, `revolve`, `offset`, `sweep`, or a boolean is `E0304`.

`Solid` is a closed 2-manifold triangle mesh. Every boolean result is validated before it becomes a `Solid`. A
`Solid` is watertight by definition; a mesh that fails validation is a compile error, never a `Solid` with a flag.
`shell` is a modifier that returns a new `Solid` with a wall thickness; the word does not denote a type.

## Color

```om
let red = rgb(200, 40, 30);
let gray = hex("#c8c8c8");
let body = box([20mm, 20mm, 20mm]).color(gray);
```

Channels are 0..255. Values outside the range are clamped. `Color` is metadata on a geometry value: transforms and
booleans preserve the color of the base operand. `union` takes the color of the first element. Formats without color
support drop it.

## Lists

```om
let xs = [1, 2, 3];
let first = xs[0];
let n = len(xs);                  // 3
let ys = for i in 0..3 { i * 2 }; // [0, 2, 4]
```

Lists are immutable and homogeneous. Indexing is zero-based; an out-of-range index is `E0211`. A list can hold
`Solid`, `Sketch`, or any other one type. `union` consumes a `List<Solid>` or `List<Sketch>`; `export` accepts a list
and writes one object per element. `flatten` turns a `List<List<T>>` into a `List<T>`.

## Complete example

```om
// @om 1
let width = to_mm(2in);
let height = 40mm;
let plate = box([width, height, 5mm], center = true);

let hole = cylinder(d = 6mm, h = 10mm, center = true);
let holes = for i in 0..2 {
    hole.translate([(i * 2 - 1) * 20mm, 0mm, 0mm])
};

export(difference(plate, union(holes)), "plate.glb");
```

`width` is `50.8mm`; the bounding box is `50.8 x 40 x 5 mm`; volume is `10160 - 282.74 = 9877.26 mm3`.

## Errors

| Code | Condition | Fix |
|---|---|---|
| `E0201` | value of the wrong type | match the declared type |
| `E0202` | bare number where a length is required | add a unit such as `mm` |
| `E0203` | length literal without a suffix | write `10mm` |
| `E0204` | `Length` combined with `Number` | multiply the number by a length, or use only lengths |
| `E0205` | mixed unit tags | convert one side with `to_mm` / `to_in` |
| `E0206` | angle without a unit | write `90deg` |
| `E0207` | value outside the allowed range | use a positive diameter and a valid count |
| `E0211` | list index out of range | index within `0 .. len(list) - 1` |

## Next

- [3D primitives](03-primitives-3d.md)
- [Transforms](05-transforms.md)
- [AI context pack](../ai/00-context-pack.md)
