# Export formats

This page lists what each writer preserves and what it drops. Read it before choosing a format for Blender, a
slicer, a laser cutter, or a CNC mill.

## Selection

| Goal | Format | Command |
|---|---|---|
| Blender, materials, object hierarchy | `.glb` | `openmesh build model.om -o model.glb` |
| Blender, text exchange | `.obj` + `.mtl` | `openmesh build model.om -o model.obj` |
| Slicer, single-color print | `.stl` | `openmesh build model.om -o model.stl` |
| Slicer, multi-object or color | `.3mf` | `openmesh build model.om -o model.3mf` |
| Laser, vector cut | `.svg` | `openmesh build panel.om -o panel.svg` |
| Laser or plasma, machine import | `.dxf` | `openmesh build panel.om -o panel.dxf` |

The extension chooses the writer. `.svg` and `.dxf` accept `Sketch` values only; `.glb`, `.obj`, `.stl`, and `.3mf`
accept `Solid` values only. A mismatch is `E0201`. A solid exported to SVG is not silently flattened.

## Comparison

| Feature | GLB | OBJ | STL | 3MF | SVG | DXF |
|---|---|---|---|---|---|---|
| 3D triangles | yes | yes | yes | yes | no | no |
| 2D paths | no | no | no | no | yes | yes |
| Declared units | metres | unitless | unitless | millimetres | millimetres | millimetres |
| Color | base color | MTL `Kd` | no | base color | fill/stroke | ACI index |
| Object separation | nodes | `o`/`g` groups | no | objects | paths | layers |
| Hierarchy | flat | no | no | flat | no | no |
| Materials | PBR base color | Lambert `Kd` | no | base color | solid fill | color index |
| Precision | float32 | decimal text | float32 | decimal text | decimal text | decimal text |
| Curves | tessellated | tessellated | tessellated | tessellated | tessellated | tessellated |
| Source or parameters | no | no | no | no | no | no |

Every writer tessellates curves before writing. OML stores triangles, not NURBS, so there is no analytic curve to
preserve. An arc that was a 64-gon circle stays a 64-gon.

## GLB

glTF 2.0 binary is the primary format. It preserves geometry, per-solid color, object separation, and normals, and
Blender imports it without a plugin.

| Property | Value |
|---|---|
| Container | binary glTF: JSON chunk plus BIN chunk |
| Coordinates | Y-up, right-handed; OML Z-up is converted with `(x, y, z) -> (x, z, -y)` |
| Units | metres; 1 mm is `0.001` |
| Positions | float32, vertex normals included |
| Indices | uint32 |
| Objects | one mesh node per exported solid, named `part_0`, `part_1`, ... |
| Materials | one PBR material per distinct color, base color only |
| Textures | none; no UV coordinates |
| Animation | none |
| Cameras and lights | none |
| Metadata | `asset.generator` is `OpenMesh 0.1.0`; no timestamps |

`rgb()` values are sRGB. The writer converts them to linear `baseColorFactor`, as glTF requires, so Blender shows the
intended color.

Losses: float64 positions become float32 (about 7 decimal digits); analytic circles become polygons; the OML source,
parameters, and constructors are not stored. A GLB is a delivery artifact, not a project file.

```bash
openmesh build enclosure.om -o enclosure.glb
```

## OBJ

Wavefront OBJ is a text format for exchange and inspection. The writer emits triangles, vertex normals, one `o`
group per exported solid, and a companion `.mtl` file with one `Kd` per color.

| Property | Value |
|---|---|
| Units | unitless; the writer uses metres, matching glTF |
| Geometry | `v`, `vn`, `f` with triangle faces |
| Objects | `o part_0`, `o part_1`, ... |
| Materials | `mtllib model.mtl`, `usemtl color_0` |
| Color | `Kd r g b` in the MTL sidecar |
| Precision | decimal text, 9 significant digits |
| Hierarchy | none |

OBJ has no unit declaration. A 30 mm part is written as `0.03`, so importing into a metre-based application keeps
the intended size. A slicer that assumes millimetres needs an explicit scale of 1000; use STL or 3MF for printing
instead.

```bash
openmesh build model.om -o model.obj
```

The command writes `model.obj` and `model.mtl`. Moving the OBJ without the MTL loses the color but keeps the
geometry.

## STL

Binary STL is the lowest common denominator for slicers.

| Property | Value |
|---|---|
| Container | binary STL, 84-byte header plus 50 bytes per triangle |
| Units | unitless; the writer uses millimetres |
| Geometry | one merged triangle soup |
| Objects | merged; object names are lost |
| Color | none |
| Precision | float32 |
| Normals | per-face normal written, recomputed from winding |

STL has no units. Writing millimetres matches the convention of every common slicer, so a 30 mm part imports as
30 mm. A `List<Solid>` export is merged into one mesh; use 3MF when object separation matters.

```bash
openmesh build model.om -o model.stl
```

A non-watertight solid is `E0311` and no STL is written. A slicer cannot repair a mesh that the compiler rejected;
fix the source instead.

## 3MF

3MF is an XML package in a ZIP container. It preserves millimetres, per-object separation, and base color, which
makes it the best choice for a multi-part print plate.

| Property | Value |
|---|---|
| Container | OPC ZIP with `3D/3dmodel.model` |
| Units | `unit="millimeter"` |
| Geometry | one object per exported solid |
| Objects | preserved as 3MF objects and build items |
| Color | `basematerials` with sRGB colors |
| Precision | decimal text |
| Hierarchy | flat; no assembly transforms |

```bash
openmesh build enclosure.om -o enclosure.3mf
```

A `List<Solid>` becomes several 3MF objects positioned in the same coordinate system. A union becomes one object.
The package timestamps are fixed at 1980-01-01, so repeated builds are byte-identical.

## SVG

SVG is the 2D format for laser cutters, vinyl cutters, and browser previews.

| Property | Value |
|---|---|
| Units | `width` and `height` in `mm`, `viewBox` in millimetres |
| Geometry | one `<path>` per sketch, holes with `fill-rule="evenodd"` |
| Coordinates | Y flipped: OML `+Y` becomes SVG `-Y` |
| Color | fill for closed sketches, stroke for open paths |
| Stroke width | `0.1mm` for open paths |
| Precision | decimal text, 4 decimal places |
| 3D | not supported |

```bash
openmesh build panel.om -o panel.svg
```

An open `path` is stroked and has no fill. A closed sketch is filled; the fill color comes from `.color(...)` or the
default gray. The SVG contains no text, no raster images, and no metadata beyond the root `svg` element.

## DXF

DXF R12 ASCII is the 2D format for CNC, plasma, and older laser software.

| Property | Value |
|---|---|
| Version | AutoCAD R12 ASCII |
| Units | `$INSUNITS 4` (millimetres), `$MEASUREMENT 1` |
| Geometry | `POLYLINE` entities with `VERTEX` and `SEQEND` |
| Closed loops | group code 70 bit 1 set |
| Layers | `OM_0`, `OM_1`, ... one per sketch |
| Color | nearest ACI index from the RGB color |
| Curves | tessellated into line segments |
| 3D | not supported |

```bash
openmesh build panel.om -o panel.dxf
```

DXF has no reliable true-color support in R12, so the writer maps each color to the nearest AutoCAD Color Index.
A hole is a separate closed polyline on the same layer, not a boolean hole; CAM software handles the nesting.

## Unit summary

| Format | OML 100 mm becomes | Importer assumption |
|---|---|---|
| GLB | `0.1` | metres |
| OBJ | `0.1` | application-defined; metres in Blender |
| STL | `100` | millimetres in slicers |
| 3MF | `100` with `unit="millimeter"` | millimetres from the file |
| SVG | `100` user units, width `100mm` | millimetres from the file |
| DXF | `100` with `$INSUNITS 4` | millimetres from the header |

## Loss matrix

| Feature | GLB | OBJ | STL | 3MF | SVG | DXF |
|---|---|---|---|---|---|---|
| Source code | lost | lost | lost | lost | lost | lost |
| Parameter values | lost | lost | lost | lost | lost | lost |
| Construction history | lost | lost | lost | lost | lost | lost |
| Exact circles | lost | lost | lost | lost | lost | lost |
| Double precision | lost | kept | lost | kept | kept | kept |
| Object names | placeholder | group | lost | object id | path id | layer |
| Per-solid color | kept | kept | lost | kept | kept | ACI |
| Textures and UVs | not supported | not supported | not supported | not supported | n/a | n/a |
| Animation | not supported | not supported | not supported | not supported | n/a | n/a |

Names are `part_0` style placeholders in GLB and 3MF; use a `List` export and separate files when a downstream tool
needs real names. "not supported" means the compiler does not produce the feature at all.

## Determinism

Every writer produces identical bytes for identical input. GLB fixes JSON key order and omits timestamps; OBJ writes
no date comments; STL fills the header with zeros; 3MF fixes ZIP entry order and timestamps; SVG and DXF use fixed
number formatting and no generator string.

```bash
openmesh build model.om -o a.3mf --no-cache
openmesh build model.om -o b.3mf
cmp a.3mf b.3mf
```

## Errors

| Code | Condition | Fix |
|---|---|---|
| `E0201` | a `Solid` is exported to SVG/DXF, or a `Sketch` to GLB/OBJ/STL/3MF | export the matching type |
| `E0311` | a 3D export is not watertight | close the mesh |
| `E0407` | the export path escapes the project root | use a path inside the root |
| `E0412` | the extension is not supported | use one of the six formats |
| `E0413` | two exports share a path | give each export a unique path |

## Next

- [CLI usage](01-usage.md)
- [Headless render](04-render.md)
- [Open in Blender](../start/03-open-in-blender.md)
- [Laser panel](../recipes/laser-panel.md)
