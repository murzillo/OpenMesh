# Changelog

> **Status: pre-alpha implementation.** The compiler source is in this repository; no tagged release or published
> archive exists yet. The entries below describe the implementation and the remaining plan.

This page defines the semantic versioning contract and the deprecation policy. The development build reports
`openmesh 0.1.0 (oml 1.0)`; the first tagged release adds a dated section here. Read it before upgrading a project or a
client that depends on diagnostic codes.

## Versioning

| Component | Format | Meaning |
|---|---|---|
| Compiler | `MAJOR.MINOR.PATCH` | behavior and bug fixes |
| OML | `MAJOR.MINOR` | source language and standard library |
| Tool schema | `MAJOR.MINOR` | MCP tool names and fields |
| File format | `MAJOR.MINOR.PATCH` | artifact bytes |

OML 1.0 is the language specification. The compiler that implements it is versioned independently and starts at
0.1.0, so "OML 1.0, compiler 0.1.0" is the expected pairing for the first build.

A patch release fixes bugs without changing valid source, diagnostics, or artifact bytes. A minor release adds
symbols and optional fields and may change bytes for a model that uses a new feature. A major release may remove
symbols, change diagnostics, or change the byte layout.

Below 1.0.0 the compiler may make a breaking change in a minor release. Every breaking change is announced one minor
release ahead in this file and names its replacement. The two-minor rule below applies from 1.0.0.

## [Unreleased] — 0.1.0

Development build, no tag yet. Implemented:

- OML compiler: `let`, `fn`, `if`, `for`, `0..n`, `import`.
- Primitives: `box`, `sphere`, `cylinder`, `cone`, `torus`, `polyhedron`, `rect`, `circle`, `polygon`, `path`.
- Booleans: `union(list)`, `difference`, `intersection`, `hull`, `minkowski` (convex path).
- Transforms: `translate`, `rotate`, `scale`, `mirror`.
- 2D to 3D: `extrude`, `revolve`, `sweep`, `offset`.
- Modifiers: `fillet`, `chamfer`, `shell`, `array`, `subdivide`.
- Edge and face selectors with presets and closures.
- `@param` metadata, `@preset`, `--param`, and `--preset`.
- Explicit `export` to GLB, OBJ+MTL, STL, 3MF, SVG, and DXF.
- Deterministic BSP CSG core and byte-identical writers for a fixed source and compiler version.
- CLI: `build`, `check`, `preview`, `render`, `params`, `docs`, `mcp`, `cache`, `version`.
- CPU rasterizer contact sheets (shaded, wire, section, thickness).
- MCP server over stdio and JSON POST HTTP with the eight documented tools.
- Diagnostic catalog and limits.

Remaining before 0.1.0:

- Full rolling-ball fillet/chamfer and exact concave-edge handling.
- Reuse of cache entries on a hit.
- GUI viewport from [Live preview](../start/05-preview.md).
- SSE notifications for Streamable HTTP.

## Deprecation policy

A symbol is deprecated in a minor release, emits `W0103` when used, and is removed no earlier than two minor
releases later. The entry that announces a deprecation also names its replacement.

A diagnostic code is never reused for a different condition. A code may change its message or hint in a patch
release. A code may be removed only in a major release, and the changelog lists the replacement.

The `// @om` header follows the same policy: a compiler accepts every minor version of its major line, warns on a
different major (`W0101`), and never silently changes the meaning of a construct.

## Compatibility table

No compiler has been released, so the table has a single placeholder row. It gains one row per release.

| Compiler | OML 1.0 | Tool schema 1.0 |
|---|---|---|
| `0.1.0-dev` (source build) | yes | 1.0 |
| _tagged release_ | — | — |

## Artifact stability

A patch release preserves artifact bytes for the same source and parameters. A minor release may change bytes when a
new feature changes triangulation, material output, or header fields; the changelog names the writer. A major release
may change the container layout.

The cache key includes the compiler version, so an upgrade never returns an artifact produced by an older compiler.

## Next

- [Architecture](architecture.md)
- [OML reference](../language/00-reference.md)
- [Errors](../language/12-errors.md)
