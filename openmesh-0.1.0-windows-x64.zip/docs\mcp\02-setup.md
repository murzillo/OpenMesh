# MCP setup

This page contains the exact client configurations for Claude Desktop, OpenCode, and any stdio client, plus the HTTP
transport. Copy the block for your client, change the binary path and the project root, and restart the client.

## Binary locations

| Platform | Typical path |
|---|---|
| Windows, per-user install | `C:\Users\<you>\AppData\Local\OpenMesh\openmesh.exe` |
| Windows, machine install | `C:\Program Files\OpenMesh\openmesh.exe` |
| Linux, per-user install | `/home/<you>/.local/openmesh/openmesh` |
| Linux, system install | `/usr/local/bin/openmesh` |

Use an absolute path in a client configuration. A GUI client may not inherit the shell `PATH`.

## Claude Desktop

Config file:

| OS | Path |
|---|---|
| Windows | `%APPDATA%\Claude\claude_desktop_config.json` |
| Linux | `~/.config/Claude/claude_desktop_config.json` |

Windows:

```json
{
  "mcpServers": {
    "openmesh": {
      "command": "C:\\Users\\you\\AppData\\Local\\OpenMesh\\openmesh.exe",
      "args": ["mcp", "--root", "C:\\Users\\you\\models"]
    }
  }
}
```

Linux:

```json
{
  "mcpServers": {
    "openmesh": {
      "command": "/home/you/.local/openmesh/openmesh",
      "args": ["mcp", "--root", "/home/you/models"]
    }
  }
}
```

For a read-only session that can validate and preview but not write artifacts:

```json
{
  "mcpServers": {
    "openmesh": {
      "command": "/home/you/.local/openmesh/openmesh",
      "args": ["mcp", "--root", "/home/you/models", "--read-only"]
    }
  }
}
```

Restart Claude Desktop completely. The server appears in the tools menu as `openmesh`. If it does not, open the
Claude Desktop log and look for the process exit code and stderr.

## OpenCode

The fastest path is the CLI, run from the directory that should become the project root:

```bash
opencode mcp add openmesh -- "C:\Users\you\AppData\Local\OpenMesh\openmesh.exe" mcp --root .
```

Add `--global` to make the server available in every project. Check the connection:

```bash
opencode mcp list
```

The equivalent project configuration uses `mcp.servers`, the V2 shape:

```jsonc
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "servers": {
      "openmesh": {
        "type": "local",
        "command": [
          "C:\\Users\\you\\AppData\\Local\\OpenMesh\\openmesh.exe",
          "mcp",
          "--root",
          "C:\\Users\\you\\models"
        ]
      }
    }
  }
}
```

V2 places servers under `mcp.servers`; a name directly under `mcp` is ignored. Use `disabled: true` to keep a
server configured without connecting it, and omit `--root` to use the workspace directory. Configuration changes
apply without restarting the client.

Tool names are prefixed with the server name and grouped under it in Code Mode: `tools.openmesh.om_validate`.

## Generic stdio client

Start the process and exchange JSON-RPC frames on stdin and stdout:

```bash
openmesh mcp --root /absolute/path/to/project
```

The first request is `initialize`:

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "initialize",
  "params": {
    "protocolVersion": "2025-06-18",
    "capabilities": {},
    "clientInfo": { "name": "example-client", "version": "1.0.0" }
  }
}
```

The server replies with its capabilities and `serverInfo`. Send `notifications/initialized`, then:

```json
{ "jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {} }
```

Call a tool:

```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "method": "tools/call",
  "params": {
    "name": "om_validate",
    "arguments": { "source": "export(box(10mm), \"box.glb\");" }
  }
}
```

Write one JSON object per line to stdin. Do not pretty-print frames; the transport is newline-delimited. Read
stdout as newline-delimited JSON and ignore stderr except for logs.

## HTTP transport

```bash
openmesh mcp --root /srv/models --http 127.0.0.1:7331
```

Endpoint: `http://127.0.0.1:7331/mcp`. Use the Streamable HTTP transport in the client. The first POST is
`initialize`; the response carries an `Mcp-Session-Id` header that subsequent requests must send.

```bash
curl -s http://127.0.0.1:7331/mcp \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{
    "jsonrpc": "2.0", "id": 1, "method": "initialize",
    "params": {
      "protocolVersion": "2025-06-18", "capabilities": {},
      "clientInfo": { "name": "curl", "version": "1" }
    }
  }'
```

HTTP mode has no authentication and no TLS. Bind to `127.0.0.1`, or expose it through an SSH tunnel or an
authenticated reverse proxy. A public bind lets anyone who can reach the port read the project and write artifacts
inside the root.

## Root and sandbox

`--root` sets the project directory. Without it, the root is the current directory. The root must exist and be a
directory, otherwise the server exits with code 2.

| Path | Resolution |
|---|---|
| `import "./parts/base.om"` | relative to the importing file, inside the root |
| `export(value, "out/model.glb")` | relative to the root |
| `om_export` `path` | relative to the root, or absolute inside the root |
| `om_compile` artifact | `<root>/.openmesh-out/compile-<sha8>.<format>` |

`..` cannot escape the root. A symlink that resolves outside the root is rejected with `E0407`.

## Limits

```bash
openmesh mcp --root . --time-limit 30s --memory-limit 1GiB --triangle-limit 500000
openmesh mcp --root . --max-artifact-size 2GiB
```

The server applies these limits to every call. A tool call cannot raise them. A client that needs a larger budget
must restart the server with different flags.

## Read-only mode

`--read-only` disables:

- `om_export`, which would write a user-specified path;
- `om_compile` with a `format`, which would write a cache artifact.

It keeps `om_search_docs`, `om_get_reference`, `om_validate`, `om_compile` without a format, `om_preview`, and
`om_query_geometry`. A blocked write returns a tool error with `isError: true` and
`data.reason = "read_only"`; it is not a model diagnostic.

## Verification

1. `openmesh version` prints 0.1.0.
2. The client starts the server without an immediate exit.
3. `tools/list` returns the eight tools.
4. `om_validate` with `export(box(10mm), "box.glb");` returns `{"ok": true}`.
5. `om_compile` without a format returns a triangle count of 12.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Server missing in Claude Desktop | invalid JSON or wrong config path | validate the JSON and reopen the app |
| `spawn ... ENOENT` | `command` is not an absolute path | use the full binary path |
| Server exits with code 2 | root does not exist or is not a directory | create the directory or fix `--root` |
| `E0407` on import | path escapes the root | move the file under the root |
| `E0407` on export | absolute path outside the root | export inside the root |
| `read-only mode` error | server started with `--read-only` | restart without the flag to write |
| HTTP 404 | wrong endpoint | use `/mcp`, not `/` |
| HTTP 401 from a proxy | proxy authentication | send the proxy token, not an OpenMesh token |
| Tool call times out | model above the CPU limit | lower segments or raise `--time-limit` |
| Windows path error | single backslashes in JSON | double every backslash |

## Next

- [Tools](03-tools.md)
- [Error contract](04-error-contract.md)
- [MCP recipes](05-recipes.md)
