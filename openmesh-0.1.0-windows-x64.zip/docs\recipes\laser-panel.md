# Laser panel

This recipe builds a 200 x 120 mm acrylic panel with rounded corners, four mounting holes, and a 6 x 3 grid of
8 mm holes. It exports SVG and DXF and reports the net area.

## Task

A front panel for a laser-cut enclosure. The outline is rounded for handling, the four corner holes take M5 screws,
and the grid vents heat. The panel is cut from 3 mm acrylic.

## Constraints

| Constraint | Value | Reason |
|---|---|---|
| Process | CO2 laser, 3 mm acrylic | kerf 0.1-0.2 mm |
| Outline | 200 x 120 mm, 8 mm corner radius | fits the enclosure |
| Mounting holes | 5.5 mm for M5 | 0.5 mm clearance |
| Vent holes | 8 mm, 6 x 3 grid, 28 mm pitch | airflow without weakening |
| Edge margin | at least 12 mm | crack resistance |
| Kerf compensation | none in the model | set at the cutter |

## Code

```om
// @om 1
@param w = 200mm { min = 100mm, max = 400mm, step = 1mm, desc = "Panel width" };
@param h = 120mm { min = 60mm, max = 300mm, step = 1mm, desc = "Panel height" };
@param corner_r = 8mm { min = 1mm, max = 20mm, step = 1mm, desc = "Corner radius" };
@param mount_d = 5.5mm { min = 3mm, max = 10mm, step = 0.5mm, desc = "Mounting hole diameter" };
@param vent_d = 8mm { min = 3mm, max = 20mm, step = 0.5mm, desc = "Vent hole diameter" };

let plate = rect(w, h)
    .offset(r = -corner_r)
    .offset(r = corner_r);

let vents = for i in 0..18 {
    let col = i % 6;
    let row = floor(i / 6);
    circle(d = vent_d)
        .translate([40mm + col * 28mm, 30mm + row * 30mm])
};

let mounts = for p in [
    [18mm, 18mm],
    [w - 18mm, 18mm],
    [18mm, h - 18mm],
    [w - 18mm, h - 18mm],
] {
    circle(d = mount_d).translate(p)
};

let holes = union([union(vents), union(mounts)]);
let panel = difference(plate, holes);

export(panel, "panel.svg");
export(panel, "panel.dxf");
```

The shrink-then-grow sequence rounds the corners without changing the outer size: the first offset shrinks the
rectangle by 8 mm, the second grows it back with a 8 mm radius. The result is exactly 200 x 120 mm.

## Verification

| Check | Expected |
|---|---|
| Bounding box | `200 x 120 mm` |
| Net area | `22945.2 mm2` |
| Corner holes | 5.5 mm at `(18, 18)`, `(182, 18)`, `(18, 102)`, `(182, 102)` |
| Vent holes | 18 holes, 8 mm, x = 40..180 step 28, y = 30, 60, 90 |
| Hole-to-edge clearance | at least 12 mm |
| Self-intersection | none |

Area calculation:

```text
rounded rectangle: 200 * 120 - (4 - PI) * 8^2 = 23945.0 mm2
18 vents:          18 * PI * 4^2             =  904.8 mm2
4 mounts:           4 * PI * 2.75^2          =   95.0 mm2
net:                23945.0 - 999.8          = 22945.2 mm2
```

`om_query_geometry` reports `22945.2 mm2` for the default parameters.

## Kerf

The model draws nominal dimensions. A laser removes 0.1-0.2 mm on each side of the cut:

| Feature | Nominal | Cut result | Fix for a press fit |
|---|---|---|---|
| 8 mm vent | 8.0 mm | 8.1-8.2 mm | draw 7.8 mm |
| 5.5 mm mount | 5.5 mm | 5.6-5.7 mm | draw 5.3 mm for M5 |
| Outline | 200 x 120 | 199.8 x 119.8 | offset the outline by +kerf/2 |

Do not compensate the model for a decorative panel; compensate when a bearing or a screw must fit without play.

## Variations

| Change | Effect |
|---|---|
| `--param w=300mm` | wider panel; the vent grid stays at the same origin |
| `--param vent_d=6mm` | finer vents, more cuts |
| Add slots | replace some circles with `rect(...)` |
| Add engraving | export an open `path` on a second layer |
| Different corner radius | `corner_r` up to 20 mm |

For a second engraving layer, export a separate SVG with only the open paths:

```om
let logo = path([
    [20mm, 100mm], [60mm, 100mm], [60mm, 80mm], [20mm, 80mm],
], closed = false);

export(logo, "panel-engrave.svg");
```

## Bounding box and area

```text
bbox:   200 x 120 mm
area:   22945.2 mm2
volume: n/a (2D sketch)
```

## Next

- [Logo extrusion](logo-extrusion.md)
- [Export formats](../cli/03-export-formats.md)
- [OML reference](../language/00-reference.md)
