# API index

Alphabetical index of every OML symbol, directive, CLI command, and MCP tool. Each row links to the page and
anchor that defines it.

## Language symbols

| Symbol | Kind | Page | Description |
|---|---|---|---|
| `abs` | function | [reference](../language/00-reference.md#math-vectors-lists) | absolute value of a number |
| `acos` | function | [reference](../language/00-reference.md#math-vectors-lists) | arc cosine, returns an angle |
| `all` | constant | [modifiers](../language/08-modifiers.md#selectors) | selector preset for every edge or face |
| `Angle` | type | [types](../language/02-types-and-units.md#angle) | angle with a unit tag, stored in radians |
| `array` | function | [modifiers](../language/08-modifiers.md#array) | repeat a shape along a constant offset |
| `as` | keyword | [syntax](../language/01-syntax.md#import) | import alias |
| `asin` | function | [reference](../language/00-reference.md#math-vectors-lists) | arc sine, returns an angle |
| `atan` | function | [reference](../language/00-reference.md#math-vectors-lists) | arc tangent, returns an angle |
| `atan2` | function | [reference](../language/00-reference.md#math-vectors-lists) | angle from two numbers or two lengths |
| `Bool` | type | [types](../language/02-types-and-units.md#type-system) | boolean |
| `bottom` | constant | [modifiers](../language/08-modifiers.md#selectors) | bottom face or edge preset |
| `box` | function | [3D primitives](../language/03-primitives-3d.md#box) | axis-aligned cuboid or cube |
| `ceil` | function | [reference](../language/00-reference.md#math-vectors-lists) | round up |
| `chamfer` | function | [modifiers](../language/08-modifiers.md#chamfer) | flat bevel on edges |
| `circle` | function | [2D primitives](../language/04-primitives-2d.md#circle) | circle as a regular polygon |
| `clamp` | function | [reference](../language/00-reference.md#math-vectors-lists) | constrain a number to a range |
| `Color` | type | [reference](../language/00-reference.md#color) | RGB color, 8 bits per channel |
| `color` | function / method | [reference](../language/00-reference.md#color) | attach a color to a shape |
| `concave` | constant | [modifiers](../language/08-modifiers.md#selectors) | selector preset for concave edges |
| `cone` | function | [3D primitives](../language/03-primitives-3d.md#cone) | circular cone |
| `convex` | constant | [modifiers](../language/08-modifiers.md#selectors) | selector preset for convex edges |
| `cos` | function | [reference](../language/00-reference.md#math-vectors-lists) | cosine of an angle |
| `count` | method | [modifiers](../language/08-modifiers.md#selectors) | number of elements in a selector |
| `cross` | function | [reference](../language/00-reference.md#math-vectors-lists) | vector cross product |
| `cylinder` | function | [3D primitives](../language/03-primitives-3d.md#cylinder) | cylinder or conical frustum |
| `difference` | function | [booleans](../language/06-booleans.md#difference) | subtract one solid from another |
| `dot` | function | [reference](../language/00-reference.md#math-vectors-lists) | vector dot product |
| `EdgeSelector` | type | [modifiers](../language/08-modifiers.md#selectors) | filtered set of edges |
| `edges` | property | [modifiers](../language/08-modifiers.md#selectors) | edge selector of a solid |
| `else` | keyword | [syntax](../language/01-syntax.md#control-flow) | alternative branch of `if` |
| `export` | directive | [syntax](../language/01-syntax.md#export) | register an artifact path |
| `extrude` | function | [2D to 3D](../language/07-2d-to-3d.md#extrude) | push a sketch along Z |
| `FaceSelector` | type | [modifiers](../language/08-modifiers.md#selectors) | filtered set of faces |
| `faces` | property | [modifiers](../language/08-modifiers.md#selectors) | face selector of a solid |
| `fillet` | function | [modifiers](../language/08-modifiers.md#fillet) | round convex edges |
| `flatten` | function | [control flow](../language/10-control-flow.md#lists) | remove one or more list nesting levels |
| `floor` | function | [reference](../language/00-reference.md#math-vectors-lists) | round down |
| `fn` | keyword | [functions](../language/09-variables-and-functions.md#fn) | declare a function |
| `for` | keyword | [control flow](../language/10-control-flow.md#for) | bounded list or range loop |
| `hex` | function | [reference](../language/00-reference.md#color) | color from a hex string |
| `horizontal` | constant | [modifiers](../language/08-modifiers.md#selectors) | horizontal preset |
| `hull` | function | [booleans](../language/06-booleans.md#hull) | convex hull of a list |
| `if` | keyword | [control flow](../language/10-control-flow.md#if) | conditional expression |
| `import` | keyword | [functions](../language/09-variables-and-functions.md#modules) | load a local module |
| `in` | keyword | [control flow](../language/10-control-flow.md#for) | loop binding |
| `intersection` | function | [booleans](../language/06-booleans.md#intersection) | common volume of two solids |
| `len` | function | [control flow](../language/10-control-flow.md#lists) | number of list elements |
| `Length` | type | [types](../language/02-types-and-units.md#length) | length with a unit tag, stored in metres |
| `length` | function | [reference](../language/00-reference.md#math-vectors-lists) | magnitude of a vector |
| `length` | method | [modifiers](../language/08-modifiers.md#selectors) | filter edges by length |
| `lerp` | function | [reference](../language/00-reference.md#math-vectors-lists) | linear interpolation |
| `let` | keyword | [functions](../language/09-variables-and-functions.md#let) | immutable binding |
| `List<T>` | type | [types](../language/02-types-and-units.md#lists) | homogeneous list |
| `max` | function | [reference](../language/00-reference.md#math-vectors-lists) | larger of two numbers |
| `min` | function | [reference](../language/00-reference.md#math-vectors-lists) | smaller of two numbers |
| `minkowski` | function | [booleans](../language/06-booleans.md#minkowski) | Minkowski sum of two solids |
| `mirror` | function | [transforms](../language/05-transforms.md#mirror) | reflect across a plane |
| `normalize` | function | [reference](../language/00-reference.md#math-vectors-lists) | unit vector |
| `Number` | type | [types](../language/02-types-and-units.md#type-system) | dimensionless float64 |
| `offset` | function | [2D to 3D](../language/07-2d-to-3d.md#offset) | expand or shrink a sketch |
| `ORIGIN` | constant | [reference](../language/00-reference.md#math-vectors-lists) | `[0, 0, 0]` |
| `path` | function | [2D primitives](../language/04-primitives-2d.md#path) | open or closed 2D polyline |
| `PI` | constant | [reference](../language/00-reference.md#math-vectors-lists) | 3.141592653589793 |
| `polygon` | function | [2D primitives](../language/04-primitives-2d.md#polygon) | closed sketch with optional holes |
| `polyhedron` | function | [3D primitives](../language/03-primitives-3d.md#polyhedron) | solid from points and faces |
| `pow` | function | [reference](../language/00-reference.md#math-vectors-lists) | exponentiation |
| `random` | function | [reference](../language/00-reference.md#math-vectors-lists) | deterministic value from a seed |
| `rect` | function | [2D primitives](../language/04-primitives-2d.md#rect) | axis-aligned rectangle |
| `return` | keyword | [functions](../language/09-variables-and-functions.md#fn) | early exit from a function |
| `revolve` | function | [2D to 3D](../language/07-2d-to-3d.md#revolve) | revolve a sketch around Z |
| `rgb` | function | [reference](../language/00-reference.md#color) | color from 0..255 channels |
| `rotate` | function | [transforms](../language/05-transforms.md#rotate) | 2D or 3D rotation |
| `round` | function | [reference](../language/00-reference.md#math-vectors-lists) | nearest integer |
| `scale` | function | [transforms](../language/05-transforms.md#scale) | uniform or per-axis scale |
| `shell` | function | [modifiers](../language/08-modifiers.md#shell) | hollow a solid with a wall thickness |
| `sin` | function | [reference](../language/00-reference.md#math-vectors-lists) | sine of an angle |
| `Sketch` | type | [types](../language/02-types-and-units.md#sketch-and-solid) | 2D contour |
| `Solid` | type | [types](../language/02-types-and-units.md#sketch-and-solid) | watertight 3D mesh |
| `sphere` | function | [3D primitives](../language/03-primitives-3d.md#sphere) | UV sphere |
| `sqrt` | function | [reference](../language/00-reference.md#math-vectors-lists) | square root |
| `String` | type | [types](../language/02-types-and-units.md#type-system) | UTF-8 text |
| `subdivide` | function | [modifiers](../language/08-modifiers.md#subdivide) | split triangles |
| `sweep` | function | [2D to 3D](../language/07-2d-to-3d.md#sweep) | move a profile along a path |
| `tan` | function | [reference](../language/00-reference.md#math-vectors-lists) | tangent of an angle |
| `to_cm` | function | [types](../language/02-types-and-units.md#length) | convert a length to centimetres |
| `to_deg` | function | [types](../language/02-types-and-units.md#angle) | convert an angle to degrees |
| `to_in` | function | [types](../language/02-types-and-units.md#length) | convert a length to inches |
| `to_m` | function | [types](../language/02-types-and-units.md#length) | convert a length to metres |
| `to_mm` | function | [types](../language/02-types-and-units.md#length) | convert a length to millimetres |
| `to_rad` | function | [types](../language/02-types-and-units.md#angle) | convert an angle to radians |
| `top` | constant | [modifiers](../language/08-modifiers.md#selectors) | selector preset for the top face or edges |
| `torus` | function | [3D primitives](../language/03-primitives-3d.md#torus) | torus |
| `total_length` | method | [modifiers](../language/08-modifiers.md#selectors) | sum of selected edge lengths |
| `translate` | function | [transforms](../language/05-transforms.md#translate) | move geometry |
| `union` | function | [booleans](../language/06-booleans.md#union) | combine a list of solids or sketches |
| `Vec2` | type | [types](../language/02-types-and-units.md#vectors) | two lengths |
| `Vec3` | type | [types](../language/02-types-and-units.md#vectors) | three lengths |
| `vertical` | constant | [modifiers](../language/08-modifiers.md#selectors) | selector preset for vertical edges |
| `where` | method | [modifiers](../language/08-modifiers.md#selectors) | filter a selector by preset or closure |
| `X` | constant | [reference](../language/00-reference.md#math-vectors-lists) | unit vector `[1, 0, 0]` |
| `Y` | constant | [reference](../language/00-reference.md#math-vectors-lists) | unit vector `[0, 1, 0]` |
| `Z` | constant | [reference](../language/00-reference.md#math-vectors-lists) | unit vector `[0, 0, 1]` |
| `@param` | directive | [parameters](../language/11-parameters.md#declaration) | typed parameter with slider metadata |
| `@preset` | directive | [parameters](../language/11-parameters.md#presets) | named parameter overrides |
| `// @om` | header | [syntax](../language/01-syntax.md#file-structure) | compiler version declaration |

## CLI commands

| Command | Page | Description |
|---|---|---|
| `openmesh build` | [CLI](../cli/01-usage.md#build) | compile and write every export |
| `openmesh cache` | [CLI](../cli/01-usage.md#cache) | inspect or clear the artifact cache |
| `openmesh check` | [CLI](../cli/01-usage.md#check) | parse and typecheck without geometry |
| `openmesh docs` | [CLI](../cli/01-usage.md#docs) | open or print the bundled documentation |
| `openmesh help` | [CLI](../cli/01-usage.md#invocation) | print command help |
| `openmesh mcp` | [CLI](../cli/01-usage.md#mcp) | start the MCP server |
| `openmesh params` | [CLI](../cli/01-usage.md#params) | print parameters and presets |
| `openmesh preview` | [CLI](../cli/01-usage.md#preview) | render a quick single-view PNG |
| `openmesh render` | [CLI](../cli/04-render.md) | render a deterministic contact sheet |
| `openmesh version` | [CLI](../cli/01-usage.md#version) | print compiler and library versions |

## MCP tools

| Tool | Page | Description |
|---|---|---|
| `om_compile` | [MCP](../mcp/03-tools.md#om_compile) | compile geometry and optionally write an artifact |
| `om_export` | [MCP](../mcp/03-tools.md#om_export) | write a file inside the project root |
| `om_get_examples` | [MCP](../mcp/03-tools.md#om_get_examples) | canonical snippets by tag |
| `om_get_reference` | [MCP](../mcp/03-tools.md#om_get_reference) | signature and parameters for one symbol |
| `om_preview` | [MCP](../mcp/03-tools.md#om_preview) | contact sheet as base64 PNG |
| `om_query_geometry` | [MCP](../mcp/03-tools.md#om_query_geometry) | bbox, volume, components, watertight |
| `om_search_docs` | [MCP](../mcp/03-tools.md#om_search_docs) | find documentation pages |
| `om_validate` | [MCP](../mcp/03-tools.md#om_validate) | parse and typecheck without geometry |

## Next

- [OML reference](../language/00-reference.md)
- [Errors](../language/12-errors.md)
- [llms.txt](../llms.txt)
