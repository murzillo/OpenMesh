# Headless render

This page specifies `openmesh render`: the deterministic PNG renderer for CI, documentation, and vision models. It
produces a contact sheet with an isometric view, three orthographic views, a scale bar, and labeled dimensions.

## Command

```text
openmesh render <input.om> [-o PATH] [flags]
```

| Flag | Unit | Default | Meaning |
|---|---|---|---|
| `-o, --output PATH` | path | `render.png` | output image |
| `--views LIST` | names | `iso,front,top,right` | comma-separated `iso`, `front`, `top`, `right`; 1-4 unique |
| `--mode MODE` | name | `shaded` | `shaded`, `wire`, `section`, `thickness` |
| `--size N` | pixels | `1024` | long edge of the contact sheet, 256..2048 |
| `--background COLOR` | hex | `#202020` | background color |
| `--renderer NAME` | name | `software` | `software` for byte-identical output, `auto` for optional GPU |
| `--no-cache` | — | off | bypass the compile cache |
| `--param name=value` | literal | — | parameter override; repeatable |
| `--preset name` | name | — | preset selection |
| `--json` | — | off | write a JSON result to stdout |
| `--time-limit` | duration | `20s` | render CPU budget |
| `--memory-limit` | size | `512MiB` | render memory budget |

`render` requires at least one `Solid` or `Sketch` export. It does not write mesh artifacts; it reads the model,
validates it, and rasterizes the exported values.

```bash
openmesh render model.om -o sheet.png
openmesh render model.om -o wire.png --mode wire --size 768
openmesh render model.om -o section.png --mode section --views front,top
openmesh render model.om -o thickness.png --mode thickness --views top
```

## Contact sheet

| Views | Layout |
|---|---|
| 1 | 1 x 1 |
| 2 | 1 x 2 |
| 3 or 4 | 2 x 2 |

The default is four views: isometric, front, top, and right. Each cell is framed from the combined bounding box with
a 10% margin. The sheet contains:

- a scale bar in millimetres;
- labeled bounding-box dimensions on the isometric cell;
- the model name and view name under each cell;
- a color legend for `thickness`, and a cut-plane label for `section`.

The orthographic presets use orthographic projection; `iso` uses an isometric direction. The isometric direction is
fixed at `(1, -1, 1)` in OML coordinates, so the same source produces the same framing.

## Modes

| Mode | Rendering |
|---|---|
| `shaded` | flat shading with feature edges; edges hidden behind a surface are removed by a depth test |
| `wire` | triangle edges, no fill |
| `section` | cut at the mid-plane of each view, cut faces highlighted |
| `thickness` | wall thickness color map with a numeric legend |

`section` cuts through the center of the bounding box, perpendicular to the view direction: the front view cuts on
the Y mid-plane, the top view on Z, and the right view on X. The isometric cell uses the Z mid-plane.

`thickness` samples the distance to the nearest opposite surface. Red is below 1.6 mm (four 0.4 mm perimeters),
yellow is 1.6-2.4 mm, and green is above 2.4 mm. The legend reports the actual minimum and maximum in millimetres.
The mode requires a watertight solid; a non-watertight source returns `E0311` and no image.

## Determinism

A `software` render is byte-identical for the same source, parameters, views, mode, size, and compiler version. The
renderer fixes:

- the camera position and the framing margin;
- the sampling pattern and the anti-aliasing seed;
- the palette and the legend layout;
- the PNG compression level and chunk order;
- the background and the font.

The writer omits timestamps, hostnames, and GPU identifiers. A test can compare the PNG bytes directly:

```bash
openmesh render model.om -o a.png --renderer software --no-cache
openmesh render model.om -o b.png --renderer software
cmp a.png b.png
```

`--renderer auto` may use a GPU and can produce different bytes on different hardware. Use it for interactive work,
not for screenshot tests.

## Software backend

`openmesh render` needs no display server. On Linux it uses llvmpipe or OSMesa; on Windows it uses the bundled
software rasterizer. A headless container runs the same command as a desktop.

| Resource | Budget |
|---|---|
| Compile | 300 ms p95 for a typical model |
| Frame | 16 ms p95 at the viewport size |
| Contact sheet | 1.5 s p95 at `--size 1024` on 4 cores |
| Memory | 512 MB |
| Maximum sheet | 2048 px long edge |

The renderer allocates one framebuffer per cell and reuses the compiled mesh across views. A 2 x 2 sheet at 1024 px
uses four 512 px cells.

## JSON output

```json
{
  "ok": true,
  "command": "render",
  "path": "sheet.png",
  "bytes": 184320,
  "sha256": "6a2f...",
  "views": ["iso", "front", "top", "right"],
  "mode": "shaded",
  "size": 1024,
  "layout": "2x2",
  "stats": { "triangles": 200, "watertight": true },
  "diagnostics": [],
  "duration_ms": 412
}
```

A failed render returns `ok: false`, the same `diagnostics` array as `build`, and exit code 1. A resource limit
returns exit code 3 with `E0901`, `E0902`, or `E0903`.

## Examples

### Default contact sheet

```bash
openmesh render enclosure.om -o enclosure.png
```

```text
enclosure.png  1024 px  2x2  iso,front,top,right  shaded  184320 bytes
```

### Wireframe for topology review

```bash
openmesh render bracket.om -o bracket-wire.png --mode wire --size 768 --views iso,right
```

### Section for internal features

```bash
openmesh render enclosure.om -o enclosure-section.png --mode section --views front,top
```

### Thickness map before printing

```bash
openmesh render enclosure.om -o thickness.png --mode thickness --views top,front
```

A red region below 1.6 mm is a warning, not an error. Increase the wall or reduce the feature size, then rerender.

### CI artifact

```bash
openmesh render model.om -o build/preview.png --renderer software --json > render.json
```

Upload `preview.png` next to `model.glb`; a reviewer can inspect the geometry without opening Blender.

## Errors

| Code | Condition | Fix |
|---|---|---|
| `E0201` | a `Solid` is required for `thickness` but the export is a `Sketch` | export a solid or use `shaded` |
| `E0311` | `thickness` or `section` received a non-watertight solid | fix the mesh |
| `E0409` | the model has no export | add `export(...)` |
| `E0901` | the render exceeded the CPU budget | lower `--size` or simplify the model |
| `E0902` | the render exceeded the memory budget | lower `--size` |
| `E0903` | the mesh exceeded the triangle limit | reduce density |

## Next

- [Live preview](../start/05-preview.md)
- [CLI usage](01-usage.md)
- [Export formats](03-export-formats.md)
