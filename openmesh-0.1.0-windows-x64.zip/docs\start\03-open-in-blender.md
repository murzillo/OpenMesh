# Open in Blender

This page imports an OpenMesh artifact into Blender, explains the Z-up to Y-up conversion, sets the scene to
millimetres, and checks the result. It is the second half of the empty-folder-to-Blender path.

## Import

1. Start Blender 3.6 or newer.
2. Choose `File > Import > glTF 2.0 (.glb, .gltf)`.
3. Select the `.glb` file written by `openmesh build`.
4. Keep the default import settings: `Guess Original Bind Pose` off, `Bone Dir` unchanged, `Y Up` on.

The object appears at the world origin. For the cable clip from [First model](02-first-model.md), the dimensions in
`N > Item > Dimensions` are `0.03 x 0.018 x 0.012 m`.

## Coordinate conversion

OpenMesh stores geometry in a right-handed Z-up frame, with the front view looking along `+Y` from `-Y`. glTF 2.0
stores a right-handed Y-up frame. The exporter rotates the model by `-90deg` about X when it writes the file:

```text
OpenMesh (Z-up)                       glTF (Y-up)
      Z                                    Y
      |   Y                                |   -Z
      |  /                                 |  /
      +------ X                            +------ X
     /                                    /
    X                                    Z
```

The mapping is:

```text
(x, y, z)  ->  (x, z, -y)
```

A point at `(0, 0, 12)` mm in OML becomes `(0, 12, 0)` mm in the file. A point at `(0, 18, 0)` becomes `(0, 0, -18)`.
The `+Y` axis of OML becomes `-Z` in glTF, so the front of the model faces `-Z`, which is the glTF camera forward
direction.

Blender's glTF importer performs the inverse conversion and displays the object in Blender's Z-up frame. The object
therefore stands upright in Blender even though the file coordinates are Y-up. The conversion happens exactly once
on export and once on import; the OML source never changes.

## Scale

The exporter writes glTF lengths in metres, as the specification requires. A 30 mm clip is written as `0.03` in the
file and Blender displays `0.03 m`:

| OML | glTF / Blender | Display |
|---|---|---|
| `1mm` | `0.001` | 1 mm |
| `30mm` | `0.03` | 30 mm |
| `100mm` | `0.1` | 100 mm |

This is correct. Do not scale the object by 1000 after import. To make Blender's interface show millimetres:

1. Open `Scene Properties > Units`.
2. Set `Unit System` to `Metric`.
3. Set `Unit Scale` to `0.001`.
4. Set `Length` to `Millimeters`.

The object dimensions then read `30 mm x 18 mm x 12 mm`, while the underlying Blender units remain metres.

If the dimensions read `30 m` instead of `0.03 m`, the file was imported with a scale factor of 1000 or the model was
exported by an older tool. Check the exporter version with `openmesh version` and the file with `openmesh build
model.om -o model.glb --json`.

## Materials

Each `Solid` carries one color. The glTF writer creates one material per distinct color, with a Principled BSDF:

| OML | glTF material | Blender result |
|---|---|---|
| no `.color(...)` | base color `#c8c8c8`, metallic 0, roughness 0.6 | light gray |
| `.color(rgb(200, 60, 40))` | base color `#c83c28`, metallic 0, roughness 0.6 | red plastic |
| `.color(hex("#2f6f4e"))` | base color `#2f6f4e` | dark green |

Materials use no textures and no UV maps. The exporter writes vertex normals for smooth shading on curved surfaces
and flat normals on planar faces. A boolean result keeps the color of the base operand.

## Objects and hierarchy

| Export form | glTF structure | Blender result |
|---|---|---|
| one `Solid` | one mesh node named `part_0` | one object |
| `List<Solid>` | one mesh node per element, `part_0`, `part_1`, ... | several objects in a collection |
| one `Sketch` | one mesh node with the sketch as a flat face | one object with no thickness |
| `List<Sketch>` | one node per sketch | several flat objects |

A `List<Solid>` export preserves each element's color. To export an assembly as one solid, use `union([...])` first;
the result becomes a single mesh and keeps the color of the first element.

## Post-import checks

| Check | Expected | Fix if wrong |
|---|---|---|
| Dimensions | 0.03 x 0.018 x 0.012 m for a 30 x 18 x 12 mm model | re-export with the current compiler; check the scene unit scale |
| Orientation | height along Blender Z, front toward -Y | verify the OML axes; do not rotate manually |
| Origin | at the OML origin, not the bounding-box center | move the object in OML with `translate` |
| Normals | outward, no black faces in solid view | re-export; inward normals indicate an invalid input |
| Materials | one material per color | check `.color(...)` and the glTF import settings |
| Watertight | `watertight: true` in the build stats | fix the model before printing |

Use `N > Item > Dimensions` for the bounding box and `N > Item > Transform` for the location. In Edit Mode, select
all and use `Mesh > Normals > Recalculate Outside` only if the file came from another tool; an OpenMesh artifact
already has consistent winding.

## STL and 3MF

For a slicer, export STL or 3MF instead of glTF:

```bash
openmesh build model.om -o model.stl
openmesh build model.om -o model.3mf
```

STL is unitless; OpenMesh writes millimetres, which is what slicers assume. 3MF declares millimetres in the file
header and preserves per-object color. Neither format preserves the OML source or the parameter metadata; keep the
`.om` file next to the artifact.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Object is 1000x too large | source was millimetres, imported as metres | keep the default scale; do not multiply |
| Object lies on its side | manually rotated after import | undo, re-import, and check the axis diagram |
| Object is below the floor | the OML model is centered on Z | translate it so its minimum Z is 0 |
| Black or missing faces | inward winding or a non-manifold input | check `watertight` in the build stats |
| Several disconnected objects | a `List` export or multi-component union | export a `union` |
| No material | the format drops color, or the object uses the default gray | use GLB or 3MF for color |

## Next

- [Concepts and glossary](04-concepts.md)
- [Live preview](05-preview.md)
- [Export formats](../cli/03-export-formats.md)
