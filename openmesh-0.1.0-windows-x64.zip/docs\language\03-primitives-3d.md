# 3D primitives

This page specifies the six solid constructors: parameters, defaults, triangle counts, and the exact dimensions they
produce. Every `Solid` starts here or from a 2D sketch converted by `extrude`, `revolve`, or `sweep`.

All primitives return a watertight, consistently wound `Solid`. With `center = false` they extend along `+X`, `+Y`,
and `+Z` from the origin. With `center = true` they are centered on the origin in the axes named in each section.
Angles and lengths follow the rules in [Types and units](02-types-and-units.md).

## box

Creates an axis-aligned rectangular solid (cuboid) from three edge lengths, or a cube from one edge length.

### Signature

```om
box(size: Length | Vec3, center: Bool = false) -> Solid
```

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `size` | `Length \| Vec3` | mm | required | every component > 0 | edge lengths along X, Y, Z |
| `center` | `Bool` | bool | `false` | none | center on the origin instead of starting at it |

### Example

```om
// @om 1
let plate = box([40mm, 20mm, 10mm], center = true);
export(plate, "plate.glb");
```

### Result

Bounding box `40 x 20 x 10 mm` centered on the origin (`x` from -20 to 20, `y` from -10 to 10, `z` from -5 to 5).
Volume `8000 mm3`, surface area `2800 mm2`, 12 triangles, 8 vertices. With `center = false` the box spans `0..40`,
`0..20`, `0..10`.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0202` | a bare number is passed as a size | add `mm` to every component |
| `E0207` | an edge is zero or negative | use a positive length |
| `E0208` | a vector with two components is passed | pass `[w, h, d]` or one length for a cube |

### See also

- [Transforms](05-transforms.md)
- [Booleans](06-booleans.md)

## sphere

Creates a UV sphere from a diameter, with latitude rings and longitude segments.

### Signature

```om
sphere(d: Length, segments: Number = 32, rings: Number = 16) -> Solid
```

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `d` | `Length` | mm | required | `0 < d <= 1e6 mm` | diameter |
| `segments` | `Number` | count | `32` | integer, 4..1024 | longitude divisions |
| `rings` | `Number` | count | `16` | integer, 2..512 | latitude divisions, including both poles |
| `center` | — | — | — | — | always centered on the origin |

### Example

```om
// @om 1
let ball = sphere(d = 20mm, segments = 32, rings = 16);
export(ball, "ball.glb");
```

### Result

Bounding box `20 x 20 x 20 mm`, centered on the origin. Ideal volume `4188.79 mm3`, ideal area `1256.64 mm2`.
Triangle count `2 * segments * (rings - 1) = 960`; vertex count `segments * (rings - 1) + 2 = 482`. The faceted mesh
is within 0.5% of the ideal volume at these settings.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0207` | `d <= 0` | use a positive diameter |
| `E0207` | `segments < 4` or `rings < 2` | raise the count |
| `E0207` | `segments` or `rings` is not an integer | pass an integer-valued number |
| `E0903` | the mesh exceeds the triangle limit | lower `segments` or `rings` |

### See also

- [Modifiers](08-modifiers.md)
- [Limits](13-limits.md)

## cylinder

Creates a circular cylinder or a conical frustum between `z = 0` and `z = h`.

### Signature

```om
cylinder(h: Length, d: Length, d2: Length = d, segments: Number = 48, center: Bool = false) -> Solid
```

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `h` | `Length` | mm | required | `h > 0` | height along Z |
| `d` | `Length` | mm | required | `d > 0` | bottom diameter |
| `d2` | `Length` | mm | `d` | `d2 >= 0` | top diameter; `0` produces a cone |
| `segments` | `Number` | count | `48` | integer, 3..1024 | radial divisions |
| `center` | `Bool` | bool | `false` | none | center the height on the origin |

### Example

```om
// @om 1
let post = cylinder(h = 20mm, d = 10mm, segments = 48);
export(post, "post.glb");
```

### Result

Bounding box `10 x 10 x 20 mm` with the bottom at `z = 0`. Volume `1570.80 mm3`, area `785.40 mm2`, 188 triangles,
96 vertices. A frustum with `d2 = 6mm` has volume `1026.25 mm3` and the same triangle count.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0207` | `h <= 0`, `d <= 0`, or `d2 < 0` | use positive dimensions |
| `E0207` | `segments < 3` | raise the count |
| `E0305` | `d2` and `d` produce a degenerate cap | keep both diameters distinct or use `cone` |

### See also

- [2D to 3D](07-2d-to-3d.md)
- [3D printing recipes](../recipes/printable-bracket.md)

## cone

Creates a circular cone with a base at `z = 0` and an apex at `z = h`. It is a cylinder with a zero top diameter,
with its own signature and explicit constraints.

### Signature

```om
cone(h: Length, d: Length, segments: Number = 48, center: Bool = false) -> Solid
```

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `h` | `Length` | mm | required | `h > 0` | height along Z |
| `d` | `Length` | mm | required | `d > 0` | base diameter |
| `segments` | `Number` | count | `48` | integer, 3..1024 | radial divisions |
| `center` | `Bool` | bool | `false` | none | center the height on the origin |

### Example

```om
// @om 1
let tip = cone(h = 20mm, d = 10mm);
export(tip, "cone.glb");
```

### Result

Bounding box `10 x 10 x 20 mm` with the base at `z = 0`. Volume `523.60 mm3`, area `402.37 mm2`, 94 triangles,
49 vertices. With `center = true` the base moves to `z = -10` and the apex to `z = 10`; the bounding box is
unchanged.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0207` | `h <= 0` or `d <= 0` | use positive dimensions |
| `E0207` | `segments < 3` | raise the count |

### See also

- [cylinder](#cylinder)
- [2D to 3D](07-2d-to-3d.md)

## torus

Creates a torus from a major diameter and a tube diameter, lying in the XY plane and centered on the origin.

### Signature

```om
torus(D: Length, d: Length, segments: Number = 64, sides: Number = 24) -> Solid
```

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `D` | `Length` | mm | required | `D > d`, `D > 0` | major diameter, center of tube to center of tube |
| `d` | `Length` | mm | required | `0 < d < D` | tube diameter |
| `segments` | `Number` | count | `64` | integer, 3..1024 | divisions around the major circle |
| `sides` | `Number` | count | `24` | integer, 3..512 | divisions around the tube |

### Example

```om
// @om 1
let ring = torus(D = 40mm, d = 10mm, segments = 64, sides = 24);
export(ring, "ring.glb");
```

### Result

Bounding box `50 x 50 x 10 mm`, centered on the origin. Volume `9869.60 mm3`, area `3947.84 mm2`,
`2 * segments * sides = 3072` triangles, `segments * sides = 1536` vertices. The torus axis is Z.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0207` | `d <= 0` or `D <= d` | make the major diameter larger than the tube |
| `E0207` | `segments < 3` or `sides < 3` | raise the count |
| `E0305` | self-intersection from an invalid diameter pair | keep `D > d` |

### See also

- [Array modifier](08-modifiers.md)
- [Transforms](05-transforms.md)

## polyhedron

Creates a solid from an explicit vertex list and polygon faces. Use it for shapes that no primitive or boolean can
produce, such as a tetrahedron or a custom bracket profile with known vertices.

### Signature

```om
polyhedron(points: List<Vec3>, faces: List<List<Number>>) -> Solid
```

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `points` | `List<Vec3>` | mm | required | at least 4 points, duplicates rejected | vertex coordinates |
| `faces` | `List<List<Number>>` | index | required | at least 4, each 3+ indices | zero-based vertex indices |

Faces must be planar within `1e-6 mm` (`E0316`), counter-clockwise when viewed from outside the solid, and form a
closed 2-manifold surface (`E0302`). Each undirected edge must appear in exactly two faces. The compiler
triangulates each face as a fan; a concave face is `E0302`.

### Example

```om
// @om 1
let tetra = polyhedron(
    points = [
        [0mm, 0mm, 0mm],
        [20mm, 0mm, 0mm],
        [0mm, 20mm, 0mm],
        [0mm, 0mm, 20mm],
    ],
    faces = [
        [0, 2, 1],
        [0, 1, 3],
        [0, 3, 2],
        [1, 2, 3],
    ],
);

export(tetra, "tetra.glb");
```

### Result

Bounding box `20 x 20 x 20 mm` with the corner at the origin. Volume `1333.33 mm3`, area `946.41 mm2`, 4 triangles,
4 vertices. Reversing a face winding makes the normal point inward and produces `E0302`.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0207` | fewer than 4 points or fewer than 4 faces | supply a closed solid |
| `E0302` | open surface, edge used once, or inward winding | close the surface; order faces CCW from outside |
| `E0316` | a face is not planar | split the face into planar triangles |
| `E0305` | two points coincide or a face has zero area | remove duplicate points |

### See also

- [Booleans](06-booleans.md)
- [Modifiers](08-modifiers.md)
- [Formal grammar](../reference/grammar.ebnf)

## Next

- [2D primitives](04-primitives-2d.md)
- [Transforms](05-transforms.md)
- [OML reference](00-reference.md)
