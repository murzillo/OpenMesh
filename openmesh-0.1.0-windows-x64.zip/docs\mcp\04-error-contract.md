# MCP error contract

This page defines the diagnostic object, the difference between protocol and model errors, the token budgets, and
the self-repair loop. It is the contract an agent implements; every other MCP page refers to it.

## Diagnostic schema

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["code", "severity", "message", "span", "hint", "doc"],
  "properties": {
    "code": {
      "type": "string",
      "pattern": "^[EW][0-9]{4}$"
    },
    "severity": {
      "type": "string",
      "enum": ["error", "warning"]
    },
    "message": {
      "type": "string",
      "minLength": 1,
      "maxLength": 240
    },
    "span": {
      "type": "object",
      "additionalProperties": false,
      "required": ["start", "end", "line", "col"],
      "properties": {
        "start": { "type": "integer", "minimum": 0 },
        "end": { "type": "integer", "minimum": 0 },
        "line": { "type": "integer", "minimum": 1 },
        "col": { "type": "integer", "minimum": 1 }
      }
    },
    "hint": {
      "type": "string",
      "minLength": 1,
      "maxLength": 320
    },
    "suggestion": {
      "type": "string",
      "maxLength": 2000
    },
    "doc": {
      "type": "string",
      "pattern": "^docs/[a-z0-9/_-]+\\.md#[a-z0-9-]+$"
    }
  }
}
```

`span.start` and `span.end` are 0-based UTF-8 byte offsets, `end` exclusive. `span.line` and `span.col` are 1-based;
`col` counts Unicode code points. For a whole-file error, start and end are `0` and line and col are `1`.

## Example

```json
{
  "code": "E0307",
  "severity": "error",
  "message": "difference() produced a non-manifold result",
  "span": { "start": 142, "end": 168, "line": 7, "col": 5 },
  "hint": "The cutter is flush with a face or touches only an edge. Overlap the target by 0.01mm.",
  "suggestion": "cylinder(d = 10mm, h = 2.02mm).translate([0mm, 0mm, -0.01mm])",
  "doc": "docs/language/12-errors.md#e0307"
}
```

## Guarantees

| Guarantee | Meaning |
|---|---|
| Stable code | the code for a condition does not change within a major version |
| Exact span | the span covers the expression that caused the error, not the whole file |
| Actionable hint | `hint` starts with a verb and names the change to make |
| Valid suggestion | `suggestion` is OML that typechecks after replacing the span |
| Existing doc anchor | `doc` points to a heading in the bundled documentation |
| Bounded list | at most 5 diagnostics, errors before warnings |
| No silent failure | a failed compile returns `ok: false`; it never returns empty geometry with `ok: true` |

A diagnostic without `hint` is a compiler bug. Report it with the source, the version, and the JSON response.

## Protocol errors

| Layer | Shape | Example |
|---|---|---|
| Transport | JSON-RPC error, no `result` | malformed frame, unknown method |
| Invalid arguments | JSON-RPC error `-32602`, `isError: true` | `query` missing, `format` not in the enum |
| Policy | JSON-RPC error `-32000`, `isError: true`, `data.reason` | read-only mode blocks a write |
| Model | `result.structuredContent.ok = false`, `isError: false` | `E0307` non-manifold difference |
| Success | `result.structuredContent.ok = true`, `isError: false` | 12 triangles, watertight |

A model error is a normal tool result. An agent must inspect `ok` and `diagnostics`, not only `isError`. A tool that
returns `isError: false` with `ok: false` did its job.

## Token budgets

| Response | Budget | Behavior over budget |
|---|---|---|
| `om_search_docs` | 400 tokens | snippet truncated at 320 characters |
| `om_get_reference` | 800 tokens | example truncated first, then params |
| each diagnostic | 300 tokens | message, hint, and suggestion are capped |
| diagnostics per call | 5 | remaining errors counted in `stats.suppressed` |
| `om_query_geometry` | 400 tokens | fixed fields, no free text |
| `om_preview` text | 300 tokens | image excluded from the text budget |
| `om_get_examples` | 2000 tokens | at most 5 examples |

If a response exceeds its budget, the cause is a documentation page or an example that is too long. Report the page
and the query; do not assume the model failed.

## Self-repair loop

```text
1. Understand the request.
   om_search_docs(query) or om_get_reference(symbol)
2. Generate OML with units and at least one export.
3. om_validate(source)
   - ok: go to 4.
   - error: apply the hint, replace at most the diagnostic span, go to 3.
   - stop after 3 edits or 2 repeats of the same code and span.
4. om_compile(source, format = null)
   - ok: go to 5.
   - error: apply the hint, go to 3.
5. om_query_geometry(source)
   - compare bbox and volume with the request.
   - stop if watertight is false or components is unexpected.
6. om_preview(source, views, mode, size) if the client supports images; the default contact sheet is
   `["iso", "front", "top", "right"]`.
7. om_export(source, format, path) or om_compile(source, format).
```

The loop modifies source text, not the diagnostics. Each iteration changes one cause. If two diagnostics share a
cause, fix the earlier span first; the later one may disappear.

## Stop conditions

An agent must stop and ask the user when any condition holds:

| Condition | Why |
|---|---|
| Three failed repair iterations | the model is guessing, not converging |
| The same `code` and `span` appear twice | the hint is not being applied correctly |
| `watertight: false` before STL or 3MF export | a slicer cannot print an open mesh |
| `components > 1` when the request describes one part | the union is missing or a cut split the body |
| `volume == 0` | the geometry collapsed; a preview would be empty |
| A limit remains exceeded after two reductions | the request needs a different design or a higher limit |
| The requested path is outside `--root` | the sandbox cannot satisfy it |
| The request needs NURBS, animation, rigging, or sculpting | OpenMesh does not implement it |
| Dimensions or tolerances are missing and the result depends on them | guessing produces a wrong part |
| The user asks for a print-ready file but `watertight` is false | safety and material waste |

Stopping is a success of the loop, not a failure. Return the source, the diagnostics, and the specific question.

## Retry policy

| Failure | Retry |
|---|---|
| Model diagnostic (`ok: false`) | fix the source; do not retry unchanged |
| `E0901` CPU | lower density or raise the limit once; retry |
| `E0902` memory | lower density; retry once |
| `E0903` triangles | lower density; retry once |
| Transport timeout | retry once with the same arguments; then stop |
| Invalid arguments | fix the call; do not retry |
| Read-only policy | stop; ask the user to restart without `--read-only` |
| Internal error `-32000` | stop; report the version and response |

`om_compile`, `om_validate`, `om_preview`, and `om_query_geometry` are idempotent: the same source returns the same
stats. `om_export` is idempotent for the same path and source; it replaces the file atomically. Do not run
`om_export` in a retry loop without checking `ok`.

## Example session

```text
user: Make a 60 x 40 x 5 mm plate with two 8 mm holes, 20 mm apart, export GLB.

agent: om_search_docs("plate holes difference")
agent: om_validate(source) -> E0203 at line 4: missing unit
agent: om_validate(fixed source) -> ok
agent: om_compile(source, null) -> ok, bbox [60,40,5], volume 11497.35
agent: om_query_geometry(source) -> watertight true, components 1
agent: om_preview(source, ["iso", "front", "top", "right"], "shaded", 1024) -> contact sheet
agent: om_export(source, "glb", "plate.glb") -> path, bytes, sha256
```

A failing branch:

```text
agent: om_compile(source, null) -> E0307, cutter touches the top face
agent: om_compile(source with 0.01mm overlap) -> ok, watertight true
```

A stop:

```text
agent: om_export(source, "stl", "part.stl") -> ok false, watertight false
agent: stop, return: "The mesh is not watertight; the preview shows an open bottom.
       Should I close the shell or keep it as a surface?"
```

## Timeouts

| Tool | Transport timeout | Server limit |
|---|---|---|
| `om_search_docs` | 10 s | 5 s |
| `om_get_reference` | 10 s | 5 s |
| `om_validate` | 20 s | 10 s |
| `om_compile` | 45 s | 30 s |
| `om_preview` | 45 s | 30 s |
| `om_export` | 90 s | 60 s |
| `om_query_geometry` | 30 s | 20 s |
| `om_get_examples` | 10 s | 5 s |

A server that hits its own limit returns `E0901` before the transport timeout. A client that abandons a call must
not assume a file was written; the server cancels and removes the temporary artifact.

## Next

- [Tools](03-tools.md)
- [MCP recipes](05-recipes.md)
- [Errors](../language/12-errors.md)
