# Concepts and glossary

This page defines the terms used across the documentation. One term has one meaning; when a page uses a word from
this list, it means exactly what is written here. Read it once before the language section.

## Model

A **model** is one OML source file and the artifacts it declares. The source is the model; the `.glb` or `.stl` is an
artifact. A model may describe one part or an assembly of several parts.

A **module** is any `.om` file imported by another file. The root file is the model; imported files are modules.

A **project** is the directory tree rooted at the project root. `--root` sets the root; without it, the root is the
directory of the root `.om` file. Imports and export paths must stay inside the project.

## Part and assembly

A **part** is one named piece of geometry in a model. OML has no `part` keyword: a part is a `Solid` value that is
passed to `export`, or one element of a `List<Solid>` passed to `export`. A part becomes one node, object, or mesh in
the artifact.

An **assembly** is a `List<Solid>` exported together. The elements keep their own colors and positions; the file
contains one object per element. An assembly is not a union: the elements may touch, overlap, or float apart. Use
`union` when the result must be one watertight solid.

## Sketch

A **sketch** is a 2D value of type `Sketch` in the XY plane. It is either **closed** (has an interior) or **open** (a
polyline).

A **contour** is the boundary of a closed sketch: one outer loop plus zero or more hole loops. The word contour refers
to the geometry; `Sketch` is the type.

A **path** is an open sketch, or the `List<Vec3>` centerline passed to `sweep`. The context decides which; the type is
printed in every signature.

A **hole** is an inner loop of a contour. It is not a separate sketch; `polygon(points, holes = [...])` stores it
inside one `Sketch`, and `difference` produces holes by subtraction.

## Mesh and solid

A **mesh** is a triangle surface: vertices, edges, and triangular faces. A mesh can be open, self-intersecting, or
inside-out.

A **solid** is a `Solid`: a closed 2-manifold triangle mesh with consistent outward winding. The compiler validates
the mesh before a value becomes a `Solid`. A mesh that fails validation is an error, not a `Solid` with a warning.

A **manifold** surface has a neighborhood around every point that is homeomorphic to a disk. In practice: every edge
is shared by exactly two faces, no edge is used once, and no vertex has two disconnected fans. A solid is
**watertight** when it has no boundary and encloses a volume.

**Winding** is the order of a face's vertices. Counter-clockwise when seen from outside gives an outward normal. The
compiler normalizes sketch winding and validates solid winding; a reversed `polyhedron` face is `E0302`.

A **normal** is a unit vector perpendicular to a face or surface, pointing outward for a valid solid. Normals drive
shading in Blender and the sign of the volume.

A **shell** is a solid with a wall thickness, produced by `shell`. The word describes the shape, not a type. A shell
is still a `Solid`; it is watertight even when one face is open, because the opening is closed by the inner wall.

## CSG

**CSG** (constructive solid geometry) builds a shape by combining solids with `union`, `difference`, and
`intersection`. OpenMesh uses a self-contained CSG engine. It operates on triangle meshes, not on NURBS, and aims to
return a manifold result for manifold inputs.

A **boolean** is one CSG operation. A **cutter** is the second operand of `difference`, the volume that is removed.

## Parameters

A **parameter** is a typed, immutable value declared with `@param`. Its metadata drives a slider or field in the
editor and a validation range in the compiler.

A **preset** is a named set of parameter overrides declared with `@preset`. A preset does not change the parameter
types or the model structure.

A **unit** is the physical dimension attached to a number by a suffix: `mm`, `cm`, `m`, `in`, `deg`, `rad`. The DSL
uses millimetres for lengths and degrees for angles by convention; lengths are stored in metres internally. There is
no implicit conversion between unit tags.

## Determinism

**Deterministic** means the same source, parameter set, compiler version, and export format produce byte-identical
output. OpenMesh achieves this by forbidding time, unseeded randomness, environment variables, and hash-order
iteration in the evaluator. `random(seed)` is a pure function of its seed.

A **cache** stores an artifact under a content hash of the source, imports, parameters, compiler version, and format.
A cache hit returns the same bytes as a rebuild. `--no-cache` bypasses the cache.

## Compile and export

**Compile** means parse, typecheck, evaluate geometry, validate the mesh, and produce statistics. `openmesh check`
stops after typechecking; `openmesh build` runs the full pipeline.

**Export** means write an artifact to a path declared by `export(value, "path")`. The extension selects the writer.
The writer runs after a successful compile and writes atomically.

An **artifact** is a file written by an export: `.glb`, `.obj`, `.stl`, `.3mf`, `.svg`, or `.dxf`. Artifacts never
contain a hidden project state.

## MCP

**MCP** (Model Context Protocol) is the JSON-RPC interface used by an external model to read documentation, validate
source, compile geometry, render a contact sheet, and export a file. The server runs the same compiler as the CLI and
reads the same `docs/` files.

A **tool** is one MCP method, for example `om_compile`. A **diagnostic** is the structured error object returned by
the compiler and by every tool. A **self-repair loop** is the cycle generate, validate, fix by `hint`, preview,
export.

## Non-goals

| Not supported | Consequence |
|---|---|
| Sculpting | no brush tools; every shape is code |
| Rigging and animation | no armatures, no keyframes, no skinning |
| Cinematic rendering | no path tracer, no lights, no camera animation |
| NURBS and class-A surfaces | no control cages, no continuity analysis |
| Simulation | no FEA, no collision, no fluid |
| Brush texturing | no texture painting, no UV unwrap |
| GUI sketching | no mouse constraints; the source is the sketch |

The tool is mesh-first parametric and technical modeling. A model that needs these features belongs in another
application; OpenMesh produces the mesh that application imports.

**Preview** is a CPU-rendered image of validated geometry. The live viewport shows a fast draft and then a full
build; the headless `render` command writes a deterministic contact sheet with four views, a scale bar, and
dimensions. A preview never evaluates source text that failed to compile.

## Pipeline

```text
.om source
   |
   v
lexer -> parser -> AST
   |
   v
typecheck (types, units, names, scopes)
   |
   v
evaluate (parameters, functions, loops, CSG on meshes)
   |
   v
validate (manifold, watertight, triangle limit)
   |                         |
   v                         v
mesh -> writer            renderer
(.glb / .obj / .stl /     (contact sheet PNG)
 .3mf / .svg / .dxf)
```

`check` stops after typecheck. `build` runs every stage. `preview` and `render` stop after validation and rasterize
the mesh; `render` writes the deterministic contact sheet. `om_query_geometry` stops after validation and reports
numbers without writing a file.

## Next

- [Live preview](05-preview.md)
- [OML reference](../language/00-reference.md)
- [Architecture](../reference/architecture.md)
