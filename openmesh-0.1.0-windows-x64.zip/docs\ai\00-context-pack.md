# AI context pack

> **Status: pre-alpha.** The compiler is unreleased and still changing. Every example here targets the current tree;
> the contract may shift before 0.1.0.

Read this page to write OML code. It contains the surface needed for a compiling model, five canonical examples,
and the diagnostics that matter most. It is self-contained: no other page is required. OML 1.0, compiler 0.1.0
(unreleased).

## 1. File and export

- UTF-8 text, extension `.om`, LF. Comments: `//` or `/* */`. Semicolons are optional.
- Optional first line `// @om 1` (major) or `// @om 1.0` (major and minor).
- Top-level names may be used before their declaration. `let` is immutable.
- Every model must call `export(value, "path")` at top level. Without it the compiler reports `E0409` and writes
  nothing. There is no `part` keyword and no implicit output.
- `export` accepts a `Solid`, a `Sketch`, or a `List` of either. The path is relative to the project root and its
  extension selects the format: `.glb`, `.obj`, `.stl`, `.3mf`, `.svg`, `.dxf`.
- Union is explicit. `union(list)` takes exactly one list; separate expressions are never merged implicitly.

## 2. Units and types

Every length and angle carries a unit suffix:

| Written | Meaning |
|---|---|
| `10mm` | 10 millimetres |
| `2cm` | 20 millimetres |
| `0.5m` | 500 millimetres |
| `1in` | 25.4 millimetres |
| `90deg` | right angle |
| `1.5rad` | radians |

The bare literals `0` and `0.0` are the only unitless numbers accepted as `Length` or `Angle`. `10` is a `Number`,
not a length. Mixing units in one operation requires conversion:

```om
let a = 10mm + 5mm;          // ok, same unit
let b = to_mm(1in) + 10mm;   // ok, explicit
let c = 1in + 10mm;          // E0205 mixed units
```

Types: `Number`, `Length`, `Angle`, `Bool`, `String`, `Vec2`, `Vec3`, `Sketch` (2D), `Solid` (3D), `Color`,
`List<T>`. Selector types `EdgeSelector` and `FaceSelector` exist only for the modifier API.

Coordinates: right-handed, Z up, metres internally, millimetres in OML. Front view looks along `+Y` from `-Y`.
glTF export converts to Y-up: `(x, y, z)` becomes `(x, z, -y)`.

## 3. Declarations

```om
// @om 1
import "./parts/base.om" as base;

@param width = 60mm { min = 20mm, max = 120mm, step = 1mm, desc = "Width" };
@param count = 3 { min = 1, max = 8, step = 1 };
@preset compact { width = 30mm; count = 2 };

let wall: Length = 3mm;

fn plate(w: Length, h: Length = 40mm) -> Solid {
    box([w, h, wall]);
}

export(plate(width), "plate.glb");
```

- `fn` arguments support defaults and named calls: `plate(w = 50mm)`. The last expression of the body is the
  result; `return expr` exits early. Recursion and closures are allowed; recursion depth is 64.
- Arrow closures: `e => e.length > 5mm`.
- `if cond { a } else { b }` is an expression; both branches need the same type.
- `for i in 0..n { value }` returns a `List`; the range is end-exclusive. `for x in xs { value }` iterates a list.
- There is no `while`, `break`, or `continue`.
- `import "x.om" as x` loads a local module. Names starting with `_` are private. Packages and network imports do
  not exist.

## 4. Primitive signatures

```om
box(size: Length | Vec3, center: Bool = false) -> Solid
sphere(d: Length, segments: Number = 32, rings: Number = 16) -> Solid
cylinder(h: Length, d: Length, d2: Length = d, segments: Number = 48, center: Bool = false) -> Solid
cone(h: Length, d: Length, segments: Number = 48, center: Bool = false) -> Solid
torus(D: Length, d: Length, segments: Number = 64, sides: Number = 24) -> Solid
polyhedron(points: List<Vec3>, faces: List<List<Number>>) -> Solid

rect(w: Length, h: Length, center: Bool = false) -> Sketch
circle(d: Length, segments: Number = 64) -> Sketch
polygon(points: List<Vec2>, holes: List<List<Vec2>> = []) -> Sketch
path(points: List<Vec2>, closed: Bool = false) -> Sketch
```

`center = false` means the primitive starts at the origin and grows along `+X`, `+Y`, `+Z`. Round primitives take
diameters. `cylinder` with `d2 != d` is a frustum; `cone` has `d2 = 0`. `polyhedron` faces are index lists,
counter-clockwise seen from outside; the surface must be closed and manifold.

## 5. Transforms, booleans, 2D to 3D, modifiers

```om
translate(v: Vec2 | Vec3, child) -> same type
rotate(angle: Angle, child: Sketch) -> Sketch
rotate(axis: Vec3, angle: Angle, child: Solid) -> Solid
scale(s: Number | Vec2 | Vec3, child) -> same type
mirror(normal: Vec3, child) -> same type

union(items: List<Solid>) -> Solid
union(items: List<Sketch>) -> Sketch
difference(base: Solid, cut: Solid) -> Solid
difference(base: Sketch, cut: Sketch) -> Sketch
intersection(a: Solid, b: Solid) -> Solid
intersection(a: Sketch, b: Sketch) -> Sketch
hull(items: List<Solid>) -> Solid
hull(items: List<Sketch>) -> Sketch
minkowski(a: Solid, b: Solid) -> Solid

extrude(sketch: Sketch, h: Length, twist: Angle = 0deg, slices: Number = 1, scale_top: Number = 1,
        center: Bool = false) -> Solid
revolve(sketch: Sketch, angle: Angle = 360deg, segments: Number = 64) -> Solid
sweep(profile: Sketch, path: List<Vec3>, twist: Angle = 0deg, scale: Number = 1, cap: Bool = true) -> Solid
offset(sketch: Sketch, r: Length = 0mm, delta: Length = 0mm, join: String = "round",
       segments: Number = 8) -> Sketch

fillet(solid: Solid, r: Length, edges: EdgeSelector | String = "all", segments: Number = 4) -> Solid
chamfer(solid: Solid, d: Length, edges: EdgeSelector | String = "all") -> Solid
shell(solid: Solid, thickness: Length, open: FaceSelector | String = "none") -> Solid
array(shape, count: Number, offset: Vec2 | Vec3) -> same type
subdivide(solid: Solid, level: Number = 1) -> Solid
```

Every function whose first argument is geometry is also a method: `box(...).translate([0mm, 0mm, 5mm])` equals
`translate([0mm, 0mm, 5mm], box(...))`. Transforms apply right to left: the inner call runs first. `difference`
subtracts one solid; combine several cutters with `union([...])` first. Booleans on solids that touch only along an
edge or face can fail with `E0307`; overlap by at least 0.01 mm. `fillet` handles convex edges and skips concave
and knife edges; if none qualify it returns `E0309`. `shell` needs a thickness below half the smallest bounding-box
dimension. `minkowski` is expensive.

## 6. Selectors

```om
body.edges                                  // EdgeSelector
body.faces                                  // FaceSelector
body.edges.where(vertical)                  // preset constant
body.edges.where("vertical")                // preset string
body.edges.where(e => e.length > 5mm)       // closure
body.edges.length(min = 5mm, max = 50mm)    // filter by edge length
body.edges.count()                          // Number
body.faces.where(top)                       // FaceSelector
```

Edge presets: `"vertical"`, `"horizontal"`, `"top"`, `"bottom"`, `"convex"`, `"concave"`, `"all"`. Face presets:
`"top"`, `"bottom"`, `"vertical"`, `"horizontal"`, `"all"`. Closure fields: edge `length`, `angle`, `direction`,
`center`; face `normal`, `area`, `center`. Pass a selector to `fillet(edges = ...)`, `chamfer(edges = ...)`, or
`shell(open = ...)`. The string `"vertical"` is accepted as a shortcut.

## 7. Math, lists, color

```om
PI, X, Y, Z, ORIGIN
abs, min, max, clamp, floor, ceil, round, sqrt, pow, sin, cos, tan, atan2, lerp, random
vec2, vec3, dot, cross, length, normalize
len, flatten
to_mm, to_cm, to_m, to_in, to_deg, to_rad
rgb, hex
```

`sin`, `cos`, `tan` take an `Angle`. `atan2` returns an `Angle` in radians. `random(seed)` returns a deterministic
value in `[0, 1)` and is the only randomness. `length(v)` returns a `Length`. `flatten(list)` removes one nesting
level from a `List<List<T>>`. `solid.color(rgb(200, 60, 40))` sets the material color; transforms and booleans
preserve it.

## 8. Five complete examples

### 8.1 Plate with two holes

```om
// @om 1
let plate = box([60mm, 40mm, 5mm], center = true);
let hole = cylinder(d = 8mm, h = 10mm, center = true);
let holes = for i in 0..2 {
    hole.translate([(i * 2 - 1) * 25mm, 0mm, 0mm])
};

export(difference(plate, union(holes)), "plate.glb");
```

Bounding box `60 x 40 x 5 mm`, volume `11497.35 mm3`.

### 8.2 Parametric L-bracket

```om
// @om 1
@param width = 60mm { min = 30mm, max = 120mm, step = 1mm };
@param height = 40mm { min = 20mm, max = 80mm, step = 1mm };
@param thickness = 6mm { min = 3mm, max = 10mm, step = 0.5mm };
@param hole_d = 4.5mm { min = 2mm, max = 8mm, step = 0.5mm };

let base = box([width, 30mm, thickness]);
let wall = box([width, thickness, height]).translate([0mm, 24mm, 0mm]);
let hole_z = cylinder(d = hole_d, h = thickness + 2mm)
    .translate([width / 2, 15mm, -1mm]);
let hole_y = cylinder(d = hole_d, h = thickness + 2mm, center = true)
    .rotate(X, 90deg)
    .translate([width / 2, 30mm - thickness / 2, height / 2]);

let body = union([base, wall]);
export(difference(body, union([hole_z, hole_y])), "bracket.glb");
```

### 8.3 Laser panel, exported as SVG or DXF

```om
// @om 1
@param w = 200mm { min = 50mm, max = 400mm, step = 1mm };
@param h = 120mm { min = 50mm, max = 300mm, step = 1mm };

let plate = rect(w, h).offset(r = -8mm).offset(r = 8mm);
let grid = for i in 0..18 {
    let col = i % 6;
    let row = floor(i / 6);
    circle(d = 8mm).translate([40mm + col * 28mm, 30mm + row * 30mm])
};
let corners = for p in [[18mm, 18mm], [w - 18mm, 18mm], [18mm, h - 18mm], [w - 18mm, h - 18mm]] {
    circle(d = 6mm).translate(p)
};
let holes = union([union(grid), union(corners)]);

export(difference(plate, holes), "panel.svg");
export(difference(plate, holes), "panel.dxf");
```

### 8.4 Revolved knob

```om
// @om 1
@param r = 30mm { min = 10mm, max = 80mm, step = 1mm };
@param h = 18mm { min = 5mm, max = 50mm, step = 1mm };

let profile = polygon([
    [0mm, 0mm], [r, 0mm], [r, h * 0.55], [r * 0.82, h], [0mm, h],
]);
let knob = profile.revolve(segments = 64);
let bore = cylinder(d = 6mm, h = 8mm).translate([0mm, 0mm, -1mm]);

export(difference(knob, bore), "knob.glb");
```

### 8.5 Enclosure with fillets and color

```om
// @om 1
@param width = 80mm { min = 40mm, max = 160mm, step = 1mm };
@param depth = 48mm { min = 30mm, max = 120mm, step = 1mm };
@param height = 40mm { min = 20mm, max = 100mm, step = 1mm };
@param wall = 2mm { min = 1.2mm, max = 5mm, step = 0.2mm };
@param radius = 3mm { min = 1mm, max = 10mm, step = 0.5mm };

let outer = box([width, depth, height], center = true);
let inner = box([width - 2 * wall, depth - 2 * wall, height - wall + 1mm], center = true)
    .translate([0mm, 0mm, wall / 2]);
let holes = [
    cylinder(d = 3.4mm, h = 10mm, center = true).translate([-(width / 2 - 8mm), -(depth / 2 - 8mm), -height / 2]),
    cylinder(d = 3.4mm, h = 10mm, center = true).translate([ (width / 2 - 8mm), -(depth / 2 - 8mm), -height / 2]),
];

let body = difference(outer, inner)
    .fillet(edges = "vertical", r = radius)
    .color(rgb(210, 210, 210));

export(difference(body, union(holes)), "enclosure.glb");
```

## 9. Diagnostic codes to expect

| Code | Meaning | Fix |
|---|---|---|
| `E0202` | expected `Length`, got `Number` | add `mm` to the literal |
| `E0203` | missing unit suffix | write `10mm`, not `10` |
| `E0204` | `Length` combined with `Number` by `+` or `-` | add only lengths, or multiply a number by a length |
| `E0205` | mixed units | wrap one side in `to_mm()` or `to_in()` |
| `E0304` | open sketch passed to `extrude` | close the `polygon` or set `closed = true` |
| `E0307` | boolean produced a non-manifold result | overlap the cutter by 0.01 mm |
| `E0309` | fillet found no supported edge | select convex edges; use `chamfer` for knife edges |
| `E0311` | result is not watertight | close the sketch, remove self-intersections |
| `E0409` | no `export` | add `export(value, "file.glb")` at top level |
| `E0903` | triangle limit exceeded | lower `segments`/`rings`, simplify booleans |

Every error returns `{code, severity, message, span, hint, suggestion?, doc}`. `hint` is an action. Read `doc` for
the full entry. Do not retry the same source unchanged.

## 10. Build path

```bash
openmesh check model.om --json
openmesh build model.om -o model.glb
openmesh render model.om -o sheet.png
```

- `check` parses and typechecks without geometry.
- `build` compiles and writes every `export` in the source. `-o` overrides the path when the model has exactly one
  export.
- `render` validates and writes a deterministic contact sheet: isometric, front, top, and right, with a scale bar and
  dimensions. Use it for visual review; the MCP `om_preview` tool returns the same contact sheet as base64.
- Exit code 0 means success; 1 diagnostics; 2 usage; 3 limit; 4 I/O.
- Output is deterministic for a given source, parameter set, compiler version, and format.
- `openmesh build model.om -o panel.svg` requires an exported `Sketch`.

## 11. Checklist before returning code

1. Every length has `mm`, `cm`, `m`, or `in`; every angle has `deg` or `rad`.
2. At least one top-level `export(value, "file.ext")` exists.
3. Separate solids are combined with `union([...])`; no implicit union is assumed.
4. Every `difference` cutter overlaps the target by at least 0.01 mm.
5. `extrude` receives a closed `Sketch`, not an open `path`.
6. Transform order is read right to left.
7. `for` produces a `List`; pass it to `union` or index it.
8. `fillet` is applied to convex edges; 90-degree box edges need an explicit `"vertical"` or `"all"` selector.
9. `shell` thickness is below half the smallest dimension.
10. No `while`, no unseeded `random`, no file or network access.

## Next

- [Full OML reference](../language/00-reference.md)
- [Prompting guide](01-prompting-guide.md)
- [Common failures](02-common-failures.md)
