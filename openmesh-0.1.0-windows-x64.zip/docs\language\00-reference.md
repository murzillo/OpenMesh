# OML reference

> **Status: 0.1.0.** OML 1.0 is the specification, implemented by compiler 0.1.0. Known limits are listed in
> [Limits](13-limits.md).

One dense page for OpenMesh Language (OML) 1.0, the specification implemented by compiler 0.1.0. Read the
[AI context pack](../ai/00-context-pack.md) for a task-oriented subset and [Syntax](01-syntax.md) for the formal
grammar. OML is not Python, not JavaScript, and not OpenSCAD.

## File and export

- UTF-8, LF, extension `.om`. Statements end at a newline; a semicolon is optional.
- `// line comment`, `/* block comment */`. Comments do not nest.
- Optional header `// @om 1` (major only) or `// @om 1.0` (major and minor). A different major version produces
  warning `W0101`; a different minor version is accepted without a warning.
- Top-level declarations are immutable and order-independent. A model must contain at least one `export`, otherwise
  `E0409`. `export(value, "path")` is the only output declaration; there is no `part` keyword.
- Export paths are relative to the project root, stay inside it, and end in `.glb`, `.obj`, `.stl`, `.3mf`, `.svg`,
  or `.dxf`. The extension selects the format. Multiple `export` calls are allowed and are written in path order.
- `export` accepts one `Solid`, one `Sketch`, or a `List` of either. A list exports one node, object, or path per
  element and preserves per-element color.

```om
// @om 1
@param size = 40mm { min = 10mm, max = 100mm, step = 1mm, desc = "Cube edge" }

export(box([size, size, size], center = true), "cube.glb");
```

## Types

| Type | Meaning | Literal or constructor |
|---|---|---|
| `Number` | float64 scalar; counts are integer-valued numbers | `3`, `1.5`, `1e-3` |
| `Length` | length, unit-tagged at compile time, stored in metres | `10mm`, `2cm`, `1in`, `0.5m` |
| `Angle` | angle, unit-tagged, stored in radians | `90deg`, `1.5rad` |
| `Bool` | boolean | `true`, `false` |
| `String` | UTF-8 text | `"body"` |
| `Vec2` | two lengths | `[10mm, 5mm]` or `vec2(10mm, 5mm)` |
| `Vec3` | three lengths | `[10mm, 5mm, 2mm]` or `vec3(10mm, 5mm, 2mm)` |
| `Sketch` | 2D contour, closed or open | `rect`, `circle`, `polygon`, `path` |
| `Solid` | watertight 2-manifold triangle mesh | `box`, `extrude`, booleans |
| `Color` | RGB color with 8 bits per channel | `rgb(200, 200, 200)`, `hex("#c8c8c8")` |
| `List<T>` | ordered list | `[a, b, c]` |
| `EdgeSelector` | edge filter, not geometry | `solid.edges.where(vertical)` |
| `FaceSelector` | face filter, not geometry | `solid.faces.where(top)` |

The bare literals `0` and `0.0` are accepted where `Length` or `Angle` is expected and mean zero of that unit. No
other unitless number converts implicitly: `10 + 5mm` is `E0204`, and `10` passed to a `Length` parameter is
`E0202`.

## Units

| Suffix | Factor | Example |
|---|---|---|
| `mm` | 1 mm | `12.5mm` |
| `cm` | 10 mm | `2.4cm` |
| `m` | 1000 mm | `0.15m` |
| `in` | 25.4 mm | `0.25in` |
| `deg` | pi/180 rad | `90deg` |
| `rad` | 1 rad | `0.7854rad` |

`+`, `-`, and comparisons require the same unit tag. `to_mm(x)`, `to_cm(x)`, `to_m(x)`, `to_in(x)` convert a
`Length`; `to_deg(x)`, `to_rad(x)` convert an `Angle`. `Length * Number`, `Length / Number`, and `Length / Length`
are valid. `Length * Length` has no type. Angles support `+`, `-`, `* Number`, `/ Number`.

## Declarations

```om
import "./parts/base.om" as base;

@param width = 60mm { min = 20mm, max = 200mm, step = 1mm, desc = "Outer width" };
@param style = "round" { options = ["round", "square"], desc = "Corner style" };
@preset narrow { width = 30mm; style = "square" };

let wall: Length = 3mm;

fn plate(w: Length, h: Length = 40mm) -> Solid {
    box([w, h, wall]);
}

let body = plate(width);
export(body, "body.glb");
```

- `let` is immutable. Reassignment is `E0403`. Inner blocks may shadow an outer name (`W0102`).
- `fn name(arg: Type, arg: Type = default) -> Type { block }`: the last expression is the result; `return expr`
  exits early. Functions and arrow closures capture immutable bindings. Recursion depth is 64 (`E0904`).
- `import "./x.om" as x` loads a local module. Paths are relative to the importing file, stay inside the project
  root, and end in `.om`. Names starting with `_` are private (`E0406`).
- Top-level names are visible in the whole file regardless of order; cycles are `E0411`.
- `@param` declares an immutable typed binding: the type is inferred from the default (`Length`, `Angle`, `Number`,
  `Bool`, `String`). Metadata: `min`, `max`, `step`, `unit`, `desc`, `group`, `options`.
- `@preset name { key = value; }` overrides parameter defaults; select it with `openmesh build --preset name`.

## Expressions and control flow

| Form | Example |
|---|---|
| Number | `42`, `3.5`, `2.5e-3` |
| Length | `10mm`, `2in` |
| Angle | `45deg`, `0.5rad` |
| Vector | `[10mm, 0mm, 2mm]`, `vec3(10mm, 0mm, 2mm)` |
| List | `[1, 2, 3]`, trailing comma allowed |
| Range | `0..4` (end-exclusive, step 1) |
| If | `if wall > 2mm { 40mm } else { 30mm }` |
| For | `for i in 0..4 { cylinder(h = 5mm, d = 2mm).translate([i * 10mm, 0mm, 0mm]) }` |
| Index | `parts[0]`, `points[len(points) - 1]` |
| Member | `base.plate(20mm)`, `body.edges` |
| Closure | `e => e.length > 5mm` |
| Method | `box([10mm, 10mm, 10mm]).translate([0mm, 0mm, 5mm])` |

`if` is an expression and requires both branches with the same type. `for` is an expression: `for x in xs { value }`
returns a `List` with one value per element. `0..n` produces `[0, 1, ..., n - 1]`. There is no `while`, `break`, or
`continue`; every loop is bounded by its input. `%` is the remainder operator.

## Operators

| Priority | Operators |
|---|---|
| 1 | `()` `[]` `.` call, index, member |
| 2 | unary `-`, `!` |
| 3 | `*`, `/`, `%` |
| 4 | `+`, `-` |
| 5 | `..` |
| 6 | `<`, `<=`, `>`, `>=` |
| 7 | `==`, `!=` |
| 8 | `&&` |
| 9 | `\|\|` |
| 10 | `=>` (closure) |

`==` compares numbers, booleans, strings, and vectors component-wise with exact float equality. Do not compare
computed lengths for equality; compare with a tolerance.

## Primitives

```om
box(size: Length | Vec3, center: Bool = false) -> Solid
sphere(d: Length, segments: Number = 32, rings: Number = 16) -> Solid
cylinder(h: Length, d: Length, d2: Length = d, segments: Number = 48, center: Bool = false) -> Solid
cone(h: Length, d: Length, segments: Number = 48, center: Bool = false) -> Solid
torus(D: Length, d: Length, segments: Number = 64, sides: Number = 24) -> Solid
polyhedron(points: List<Vec3>, faces: List<List<Number>>) -> Solid

rect(w: Length, h: Length, center: Bool = false) -> Sketch
circle(d: Length, segments: Number = 64) -> Sketch
polygon(points: List<Vec2>, holes: List<List<Vec2>> = []) -> Sketch
path(points: List<Vec2>, closed: Bool = false) -> Sketch
```

`box` accepts one length for a cube. `cylinder` with `d2 != d` is a frustum; `cone` is a cylinder with `d2 = 0`.
Round primitives take diameters. Primitives with `center = false` start at the origin and extend along `+X`, `+Y`,
`+Z`.

## Transforms

```om
translate(v: Vec2 | Vec3, child) -> same geometry type
rotate(angle: Angle, child: Sketch) -> Sketch
rotate(axis: Vec3, angle: Angle, child: Solid) -> Solid
scale(s: Number | Vec2 | Vec3, child) -> same type
mirror(normal: Vec3, child) -> same type
```

Every function whose first argument is geometry is also a method: `translate(v, box(...))` equals
`box(...).translate(v)`. Transforms compose right to left. `translate([0mm, 0mm, 5mm],
rotate(Z, 90deg, box([10mm, 2mm, 2mm])))` rotates first, then translates. `scale` with a negative component is
rejected (`E0207`); use `mirror`.

## Booleans

```om
union(items: List<Solid>) -> Solid
union(items: List<Sketch>) -> Sketch
difference(base: Solid, cut: Solid) -> Solid
difference(base: Sketch, cut: Sketch) -> Sketch
intersection(a: Solid, b: Solid) -> Solid
intersection(a: Sketch, b: Sketch) -> Sketch
hull(items: List<Solid>) -> Solid
hull(items: List<Sketch>) -> Sketch
minkowski(a: Solid, b: Solid) -> Solid
```

Union is explicit: there is no implicit union of separate expressions. `difference` subtracts one solid; to
subtract several, combine them first with `union([a, b, c])`. Booleans require operands of the same type. A union of
disjoint solids is a valid multi-component solid. Solids that touch only along an edge or face can produce a
non-manifold result (`E0307`); overlap by at least 0.01 mm. `minkowski` costs
O(triangles(a) * triangles(b)) and is bounded by `E0903`.

## 2D to 3D

```om
extrude(sketch: Sketch, h: Length, twist: Angle = 0deg, slices: Number = 1, scale_top: Number = 1,
        center: Bool = false) -> Solid
revolve(sketch: Sketch, angle: Angle = 360deg, segments: Number = 64) -> Solid
sweep(profile: Sketch, path: List<Vec3>, twist: Angle = 0deg, scale: Number = 1, cap: Bool = true) -> Solid
offset(sketch: Sketch, r: Length = 0mm, delta: Length = 0mm, join: String = "round",
       segments: Number = 8) -> Sketch
```

`extrude` requires a closed sketch; an open `path` is `E0304`. `twist` rotates the top face; `slices` controls
intermediate layers and must be at least 1. `scale_top` tapers the top (1 = no taper). `revolve` rotates around the
Z axis; the profile must lie at `x >= 0` (`E0314`). `sweep` moves the profile along a polyline; sharp corners can
self-intersect (`E0313`). `offset` requires exactly one of `r` and `delta` to be non-zero; `r` produces rounded
corners, `delta` produces sharp corners with `join = "round" | "miter" | "square"`.

## Modifiers and selectors

```om
fillet(solid: Solid, r: Length, edges: EdgeSelector | String = "all", segments: Number = 4) -> Solid
chamfer(solid: Solid, d: Length, edges: EdgeSelector | String = "all") -> Solid
shell(solid: Solid, thickness: Length, open: FaceSelector | String = "none") -> Solid
array(shape, count: Number, offset: Vec2 | Vec3) -> same type
subdivide(solid: Solid, level: Number = 1) -> Solid

solid.edges -> EdgeSelector
solid.faces -> FaceSelector
selector.where(predicate: Predicate | String) -> same selector
selector.length(min: Length = 0mm, max: Length = 1m) -> EdgeSelector
selector.count() -> Number
selector.total_length() -> Length
```

Edge presets: `"vertical"`, `"horizontal"`, `"top"`, `"bottom"`, `"convex"`, `"concave"`, `"all"`. Face presets:
`"top"`, `"bottom"`, `"vertical"`, `"horizontal"`, `"all"`. Predicate constants `vertical`, `horizontal`, `top`,
`bottom`, `convex`, `concave`, `all` are also accepted by `.where`. A closure receives an edge with `length`,
`angle`, `direction`, `center`, or a face with `normal`, `area`, `center`.

- `fillet` rounds convex edges. It skips concave edges and edges sharper than 90 degrees; if no selected edge
  qualifies, `E0309`. A radius that does not fit the adjacent faces is `E0308`. Use `edges = "vertical"` for the
  four vertical edges of an extrusion.
- `chamfer` cuts every selected edge, convex or concave, at distance `d`.
- `shell` hollows a solid. `open = "top"` removes the top face. Thickness must be below half the smallest
  bounding-box dimension (`E0310`); self-intersecting walls fail with `E0310`.
- `array` returns the union of `count` copies translated by `offset * i`, `i = 0..count - 1`.
- `subdivide` splits each triangle into four without moving vertices. Triangles multiply by `4^level`.

## Color

```om
rgb(r: Number, g: Number, b: Number) -> Color
hex(value: String) -> Color
color(shape, c: Color) -> same type
```

Channels are 0..255. `solid.color(rgb(200, 60, 40))` sets the material color for that solid. Booleans and transforms
preserve the base color. `union` keeps the color of the first element. A `List` export preserves each element's
color. Formats without color support ignore it; see [Export formats](../cli/03-export-formats.md).

## Math, vectors, lists

```om
PI, X, Y, Z, ORIGIN
abs, min, max, clamp, floor, ceil, round, sqrt, pow, sin, cos, tan, asin, acos, atan, atan2, lerp, random
vec2, vec3, dot, cross, length, normalize
len, flatten
to_mm, to_cm, to_m, to_in, to_deg, to_rad
```

`sin`, `cos`, and `tan` take an `Angle`. `asin`, `acos`, and `atan` take a `Number` and return an `Angle`. `atan2`
accepts two `Number`s or two `Length`s of the same kind and returns an `Angle` in radians; a mixed pair is `E0202`.
`random(seed)` returns a deterministic value in `[0, 1)` and is the only source of pseudo-randomness. `length(v)`
returns a `Length`.

A `Vec2` or `Vec3` component is readable by name (`p.x`, `p.y`, `p.z`) or by index (`p[0]`, `p[1]`, `p[2]`); both
return a `Length`. Indexing a `List` returns its element type.
`len(list)` returns a `Number`. `flatten(list)` removes one nesting level from a `List<List<T>>`; `flatten(list, n)`
removes `n` levels, and `flatten(list, 0)` removes every level. The depth must be a constant literal. Nested `for`
loops add one level per loop.

## Parameters

```om
@param width = 40mm {
    min = 10mm, max = 100mm, step = 1mm,
    unit = "mm", desc = "Outer width", group = "Body"
};
@param pattern = "grid" { options = ["grid", "hex"], desc = "Pattern" };
@preset small { width = 25mm; pattern = "hex" };
```

The default literal determines the type. A default outside `[min, max]` is `E0410`; `step` must be positive and
compatible with the type. The desktop editor builds sliders from this metadata. `--param width=50mm` overrides one
value; `--preset small` applies a preset. MCP clients change the default in the source because the tools accept
only source text.

## Diagnostics

| Range | Area | Examples |
|---|---|---|
| `E01xx` | lexer and parser | `E0101` unexpected character, `E0105` unclosed delimiter |
| `E02xx` | types and units | `E0202` expected Length, `E0205` mixed units |
| `E03xx` | geometry and CSG | `E0307` non-manifold difference, `E0311` not watertight |
| `E04xx` | names and scopes | `E0401` undefined name, `E0409` no export |
| `E09xx` | limits | `E0901` CPU, `E0903` triangles |
| `W01xx` | warnings | `W0101` compiler major mismatch, `W0102` shadowing |

Every error carries a `hint` with an action, an optional `suggestion`, and a `doc` link to an anchor in
[Errors](12-errors.md). The full catalog with bad and good examples is on that page. Limits are in
[Limits](13-limits.md).

## Complete model

```om
// @om 1
@param width  = 80mm { min = 20mm, max = 300mm, step = 1mm, desc = "Enclosure width" };
@param depth  = 48mm { min = 20mm, max = 200mm, step = 1mm, desc = "Enclosure depth" };
@param wall   = 2mm  { min = 0.8mm, max = 6mm, step = 0.2mm, desc = "Wall thickness" };
@param radius = 3mm  { min = 1mm, max = 15mm, step = 0.5mm, desc = "Corner radius" };

fn shell(w: Length, h: Length, t: Length) -> Solid {
    let outer = box([w, h, 40mm], center = true);
    let inner = box([w - 2 * t, h - 2 * t, 40mm - t + 1mm], center = true)
        .translate([0mm, 0mm, t / 2]);
    difference(outer, inner)
}

let holes = [
    cylinder(d = 3.4mm, h = 10mm, center = true).translate([-(width / 2 - 8mm), -(depth / 2 - 8mm), -20mm]),
    cylinder(d = 3.4mm, h = 10mm, center = true).translate([ (width / 2 - 8mm), -(depth / 2 - 8mm), -20mm]),
    cylinder(d = 3.4mm, h = 10mm, center = true).translate([-(width / 2 - 8mm),  (depth / 2 - 8mm), -20mm]),
    cylinder(d = 3.4mm, h = 10mm, center = true).translate([ (width / 2 - 8mm),  (depth / 2 - 8mm), -20mm]),
];

let body = shell(width, depth, wall)
    .fillet(edges = "vertical", r = radius);

export(difference(body, union(holes)), "enclosure.glb");
```

For `width = 80mm`, `depth = 48mm`: bounding box `80 x 48 x 40 mm`; volume is approximately `26.3 cm3` after the
four 3.4 mm mounting holes and the 3 mm vertical fillets.

## Next

- [Syntax and grammar](01-syntax.md)
- [AI context pack](../ai/00-context-pack.md)
- [Full error catalog](12-errors.md)
