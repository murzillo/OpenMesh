# Variables and functions

This page specifies `let`, `fn`, closures, recursion, modules, and scope. Read it before splitting a model across
files or building a reusable part library.

## let

`let` binds an immutable value. The type is inferred from the expression; an optional annotation is checked.

```om
let wall: Length = 2mm;
let width = 60mm;
let label = "body";
let holes = [8mm, 10mm, 12mm];
```

There is no assignment statement. `wall = 3mm;` is `E0403`; the compiler does not treat it as a mutation. A new
binding with the same name in an inner block shadows the outer one and produces `W0102`.

```om
// @om 1
let size = 20mm;

fn make(scale: Number) -> Solid {
    let size = 20mm * scale;      // shadows the outer size, W0102
    box([size, size, size])
}

export([make(1), make(2)], "cubes.glb");
```

Shadowing is legal but a model with many shadows is harder for a reader and for a model to edit. Prefer distinct
names such as `outer_size` and `inner_size`.

## fn

```om
fn name(a: Type, b: Type = default) -> Type {
    // statements
    result
}
```

- Parameter types are required; defaults are optional and must match the parameter type.
- Calls accept positional and named arguments: `plate(60mm, thickness = 8mm)`. Positional arguments precede named
  ones (`E0209` otherwise).
- The last expression of the body is the result. `return expr` exits early; `return` outside a function is `E0415`.
- Functions may recurse; the depth limit is 64 (`E0904`).
- Functions may be declared inside a block and capture immutable bindings from the enclosing scope.
- Functions are not values: a function name cannot be passed as an argument or stored in a list. Use a closure for
  a predicate.

```om
// @om 1
fn plate(w: Length, h: Length = 40mm, thickness: Length = 5mm) -> Solid {
    box([w, h, thickness], center = true)
}

let small = plate(40mm);
let thick = plate(w = 60mm, h = 30mm, thickness = 10mm);

export([small, thick], "plates.glb");
```

`small` is `40 x 40 x 5 mm`; `thick` is `60 x 30 x 10 mm`.

## Recursion

A recursive function must have a terminating branch. The compiler enforces a depth of 64 but cannot prove
termination; a non-terminating recursion fails with `E0904`, not with a hang.

```om
// @om 1
fn tower(level: Number, size: Length) -> Solid {
    if level == 0 {
        box([size, size, size], center = true)
    } else {
        union([
            box([size, size, size], center = true),
            tower(level - 1, size * 0.8).translate([0mm, 0mm, size / 2]),
        ])
    }
}

export(tower(2, 20mm), "tower.glb");
```

For `level = 2`, `size = 20mm`, the result is three overlapping boxes with edge lengths 20, 16, and 12.8 mm.
Bounding box `20 x 20 x 34.4 mm`; volume approximately `14193 mm3`; 36 triangles before the unions, roughly 60
after.

## Closures and lambdas

A lambda is an inline function. Two forms exist:

```om
let double = (x: Number) => x * 2;                       // return type inferred
let scale = fn(w: Length, k: Number) -> Length { w * k } // annotated, block body
let pad = (w: Length) => w + 5mm;                        // captures visible bindings
```

The arrow form infers the return type from the body; the `fn` form with `-> T` checks the body against the
annotation. Parameters are positional and typed; a lambda is stored in a `let` and called like a function:
`double(3)`, `scale(10mm, 2)`.

A one-parameter closure without annotations is a selector predicate; `where` supplies the element type:

```om
// @om 1
let body = box([60mm, 40mm, 20mm], center = true);
let long_edges = body.edges.where(e => e.length > 10mm);
let top_faces = body.faces.where(f => f.normal.z > 0.9);

export([
    body.fillet(edges = long_edges, r = 2mm),
    body.chamfer(edges = long_edges, d = 1mm),
], "variants.glb");
```

A closure captures the immutable bindings visible where it is written. There is no mutable state to capture.

A lambda cannot yet be passed as an argument to another function: there is no `Fn` type annotation, and `Any` does not
accept a function value.

## Scope

| Scope | Visible names | Order |
|---|---|---|
| Top level | all top-level `let`, `fn`, `@param`, modules | order-independent; cycles are `E0411` |
| Function body | parameters, local `let`/`fn`, captured outer names | sequential |
| `if` block | own locals, captured outer names | sequential |
| `for` block | own locals, captured outer names, loop variable | sequential per iteration |

Top-level order independence means a function may call a function declared below it:

```om
let result = double(10mm);

fn double(x: Length) -> Length {
    x * 2
}

export(box([result, 10mm, 10mm]), "box.glb");
```

A cycle is rejected:

```om
// bad: E0411
let a = b + 1mm;
let b = a + 1mm;
```

## Modules

Every `.om` file is a module. `import "./path/file.om" as alias` loads it:

```om
// parts/fasteners.om
// @om 1
fn _clearance(d: Length, c: Length) -> Length {
    d + 2 * c
}

fn m3_screw(length: Length) -> Solid {
    cylinder(h = length, d = 3mm, segments = 32)
}

fn m3_hole(depth: Length) -> Solid {
    cylinder(h = depth, d = _clearance(3mm, 0.2mm), segments = 32)
}
```

```om
// model.om
// @om 1
import "./parts/fasteners.om" as fast;

let hole = fast.m3_hole(10mm).translate([0mm, 0mm, -1mm]);
export(hole, "m3-hole.glb");
```

`m3_hole` resolves to a 3.4 mm diameter hole. `_clearance` is private: `fast._clearance` is `E0406`.

Rules:

- The path is relative to the importing file and ends in `.om`.
- The path must resolve inside the project root (`E0407`); `../` outside the root is rejected.
- Imports are acyclic (`E0405`) and limited to 16 levels (`E0905`).
- A module's top-level `export` calls are ignored when it is imported. Only functions and values are imported.
  Exports run only in the root file.
- All top-level names not starting with `_` are public. There is no export list.

## Complete example

```om
// @om 1
fn bracket(width: Length, height: Length, thickness: Length, hole_d: Length) -> Solid {
    let base = box([width, 30mm, thickness]);
    let wall = box([width, thickness, height]).translate([0mm, 30mm - thickness, 0mm]);

    let hole_z = cylinder(d = hole_d, h = thickness + 2mm, center = true)
        .translate([width / 2, 15mm, thickness / 2]);
    let hole_y = cylinder(d = hole_d, h = thickness + 2mm, center = true)
        .rotate(X, 90deg)
        .translate([width / 2, 30mm - thickness / 2, height / 2]);

    let body = union([base, wall]);
    difference(body, union([hole_z, hole_y]))
}

export(bracket(60mm, 40mm, 6mm, 4.5mm), "bracket.glb");
```

## Errors

| Code | Condition | Fix |
|---|---|---|
| `E0401` | name is not declared | check spelling and imports |
| `E0402` | two declarations with the same name in one scope | rename one |
| `E0403` | assignment to a `let` binding | create a new `let` |
| `E0404` | imported file does not exist | fix the path |
| `E0405` | import cycle | move shared code into a third module |
| `E0406` | access to a `_`-prefixed module symbol | use a public symbol |
| `E0407` | path escapes the project root | use a path inside `--root` |
| `E0408` | unknown type name | use a type from the type table |
| `E0411` | circular top-level value reference | break the cycle with a parameter |

## Next

- [Control flow](10-control-flow.md)
- [Parameters](11-parameters.md)
- [Architecture](../reference/architecture.md)
