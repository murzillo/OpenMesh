# First model

> **Status: 0.1.0.** The commands below use the `openmesh` executable from the release archive. If you build from
> source, add `target/release` to `PATH` first.

This page builds a parametric cable clip from an empty folder to a `.glb` file in about ten minutes. It uses one
primitive, one transform, one boolean, four parameters, and one export.

## 1. Project setup

```powershell
# Windows
New-Item -ItemType Directory -Force "$HOME\OpenMesh\cable-clip" | Out-Null
Set-Location "$HOME\OpenMesh\cable-clip"
```

```bash
# Linux
mkdir -p "$HOME/openmesh/cable-clip"
cd "$HOME/openmesh/cable-clip"
```

Create a file named `cable-clip.om` with the following content.

```om
// @om 1
@param width = 30mm { min = 20mm, max = 60mm, step = 1mm, desc = "Clip width" };
@param depth = 18mm { min = 12mm, max = 30mm, step = 1mm, desc = "Clip depth" };
@param height = 12mm { min = 12mm, max = 20mm, step = 1mm, desc = "Clip height" };
@param cable_d = 8mm { min = 3mm, max = 10mm, step = 0.5mm, desc = "Cable diameter" };

let body = box([width, depth, height], center = true);
let hole = cylinder(d = cable_d, h = depth + 2mm, center = true)
    .rotate(X, 90deg);

let clip = difference(body, hole)
    .translate([0mm, 0mm, height / 2]);

export(clip, "cable-clip.glb");
```

## 2. Syntax and type check

```bash
openmesh check cable-clip.om
```

Expected output:

```text
cable-clip.om: ok
parameters: width=30mm, depth=18mm, height=12mm, cable_d=8mm
exports: cable-clip.glb (glb)
```

`check` parses and typechecks without evaluating geometry. It prints the resolved parameters and the export paths.
A failure prints a diagnostic with a code, a line, a column, and a hint:

```text
cable-clip.om:5:20: E0203 missing unit suffix
  hint: write 10mm instead of 10
  doc: docs/language/12-errors.md#e0203
```

## 3. Artifact build

```bash
openmesh build cable-clip.om
```

The model declares one export, so the command writes one file in the current directory:

```text
cable-clip.glb  30 x 18 x 12 mm  5575.22 mm3  glb
```

`build` writes the artifact atomically. A failed build does not leave a truncated file and does not replace the
previous artifact.

The model declares exactly one export, so `-o` overrides its path:

```bash
openmesh build cable-clip.om -o clip.glb
```

To also produce a binary STL for a slicer, add a second export:

```om
// add next to the existing export
export(clip, "cable-clip.stl");
```

With two exports, `build` writes both; `-o` is then rejected because it cannot choose between them.

## 4. Model walkthrough

| Line | Meaning |
|---|---|
| `// @om 1` | accepts any 1.x compiler |
| `@param width = 30mm` | declares a slider from 20 to 60 mm in 1 mm steps |
| `box([width, depth, height], center = true)` | a cuboid centered on the origin |
| `cylinder(...).rotate(X, 90deg)` | a cylinder along Z, rotated to run along Y |
| `difference(body, hole)` | cuts the cable channel through the depth |
| `.translate([0mm, 0mm, height / 2])` | moves the clip so it sits on the print bed at `z = 0` |
| `export(..., "cable-clip.glb")` | writes glTF for Blender |

The hole is longer than the body (`depth + 2mm`) and centered, so it passes fully through both faces. A cutter that
stops exactly at a face triggers `E0307`; the 2 mm overshoot avoids that.

## 5. Result import

Start Blender, choose `File > Import > glTF 2.0 (.glb, .gltf)`, and select `cable-clip.glb`. The object
dimensions should read `0.03 x 0.018 x 0.012 m`, which is 30 x 18 x 12 mm. The
[Blender page](03-open-in-blender.md) explains why the numbers are in metres and how to set the scene to
millimetres.

For a contact sheet without Blender:

```bash
openmesh render cable-clip.om -o clip.png --views iso,front,top,right --size 1024
```

The sheet contains an isometric view, three orthographic views, a scale bar, and labeled dimensions. A single view
is available with `openmesh preview`; the [preview page](05-preview.md) explains the viewport and the render modes.

## 6. Parameter override

```bash
openmesh build cable-clip.om -o wide.glb --param width=45mm --param cable_d=10mm
```

The bounding box becomes `45 x 18 x 12 mm`; the 10 mm channel leaves a 1 mm wall above and below. The model file is
unchanged; the overrides apply to this build only.

To bake a variation into the file, add a preset:

```om
@preset wide {
    width = 45mm;
    cable_d = 10mm;
}
```

```bash
openmesh build cable-clip.om -o wide.glb --preset wide
```

## 7. Geometry inspection

```bash
openmesh build cable-clip.om -o clip.glb --json
```

```json
{
  "ok": true,
  "command": "build",
  "outputs": [
    {
      "path": "clip.glb",
      "format": "glb",
      "bytes": 12840,
      "stats": {
        "triangles": 200,
        "vertices": 102,
        "bbox": { "min": [-15, -9, 0], "max": [15, 9, 12] },
        "volume": 5575.22,
        "area": 2583.86,
        "watertight": true,
        "components": 1
      }
    }
  ],
  "diagnostics": [],
  "duration_ms": 38
}
```

The exact triangle count can differ by a few triangles after the boolean; the bounding box and volume are stable.
`watertight: true` is the precondition for a 3D print.

## Common mistakes

| Mistake | Diagnostic | Fix |
|---|---|---|
| Writing `width = 30` | `E0203` | add `mm` |
| Passing `diameter = 8mm` | `E0209` | the name is `d` |
| Cutting a channel that exactly touches the top | `E0307` | make the cutter longer or overlap by 0.01 mm |
| Forgetting `export` | `E0409` | add `export(clip, "cable-clip.glb")` |
| Setting `cable_d` larger than `height` | `E0301` or a split solid | keep the cable diameter below the height |

## Next

- [Open in Blender](03-open-in-blender.md)
- [Live preview](05-preview.md)
- [Concepts and glossary](04-concepts.md)
