# Build and CI

This page defines exit codes, the JSON envelope, reproducibility, and the cache, and gives a working CI recipe. Read
it when a script needs to decide whether a build succeeded without parsing human text.

## Exit codes

| Code | Meaning | Retry |
|---|---|---|
| 0 | success | no |
| 1 | model diagnostics | fix the source; do not retry unchanged |
| 2 | usage or configuration | fix the command line |
| 3 | resource limit | reduce the model or raise the limit deliberately |
| 4 | I/O error | fix permissions or disk space; retry after the cause is removed |
| 5 | internal error | report with the version and JSON output |
| 130 | interrupted | no |

A successful `build` exits 0 only after every artifact is written and fsynced. A failed export does not change the
previous artifact because writes are atomic: temporary file, flush, rename.

## JSON envelope

`--json` writes exactly one JSON object to stdout. Logs and progress go to stderr, so a pipe captures only the
envelope. `render` uses the same envelope with `command: "render"` and an image path instead of mesh outputs.

Success:

```json
{
  "ok": true,
  "command": "build",
  "outputs": [
    {
      "path": "model.glb",
      "format": "glb",
      "bytes": 12840,
      "sha256": "8f0c...",
      "stats": {
        "triangles": 200,
        "vertices": 102,
        "bbox": { "min": [-15, -9, 0], "max": [15, 9, 12] },
        "volume": 5575.22,
        "area": 2583.86,
        "watertight": true,
        "components": 1,
        "degenerate_triangles": 0
      }
    }
  ],
  "diagnostics": [],
  "duration_ms": 38
}
```

Failure:

```json
{
  "ok": false,
  "command": "build",
  "exit_code": 1,
  "diagnostics": [
    {
      "code": "E0203",
      "severity": "error",
      "message": "missing unit suffix",
      "span": { "start": 84, "end": 86, "line": 5, "col": 20 },
      "hint": "Write 10mm instead of 10.",
      "doc": "docs/language/12-errors.md#e0203"
    }
  ],
  "duration_ms": 4
}
```

Fields:

| Field | Type | Present | Meaning |
|---|---|---|---|
| `ok` | bool | always | success of the whole command |
| `command` | string | always | `build`, `check`, `preview`, `render`, `params` |
| `outputs` | array | success | one entry per artifact |
| `diagnostics` | array | always | up to five diagnostics, errors first |
| `exit_code` | number | failure | same value as the process exit code |
| `duration_ms` | number | always | wall-clock duration |
| `stats` | object | per output | mesh statistics |

The diagnostic object is specified in [Errors](../language/12-errors.md#diagnostic-object). A consumer should read
`code`, `hint`, and `doc`; `message` is for humans.

## Reproducibility

For a fixed source tree, parameter set, compiler version, and format, the output bytes are identical across runs,
machines, and cache states. The writer omits timestamps, hostnames, absolute paths, and random identifiers.

```bash
openmesh build model.om -o a.glb --no-cache
openmesh build model.om -o b.glb
sha256sum a.glb b.glb
cmp a.glb b.glb
```

Both hashes match and `cmp` prints nothing. The same check works for STL and 3MF; OBJ includes the MTL file name in
the header, so compare the pair or normalize the path.

A deterministic build still depends on the compiler version. Record it next to the artifact:

```bash
openmesh version --json > build-info.json
```

## Cache

The cache stores successful artifacts under a content key:

```text
BLAKE3(
  root and imported source bytes,
  resolved parameter values and CLI overrides,
  compiler version,
  export paths, formats, and writer version,
  resource limits
)
```

The cache lives in `<root>/.openmesh-cache/` and can be moved with `--cache-dir`. It stores artifact bytes plus the
stats, not the AST. A hit loads and typechecks the project, copies the cached artifacts, reports `"cached": true`, and
skips geometry evaluation. The cached SHA-256 is rechecked on every hit, so a damaged entry falls back to a full build.
Invalid sources are never cached, so diagnostics always come from the compiler.

```bash
openmesh build model.om --verbose        # prints "cache hit <key>" or "cache miss"
openmesh build model.om --no-cache      # force a full build
openmesh cache clear                    # delete all entries
```

Do not commit `.openmesh-cache/`. Add it to `.gitignore`.

## CI workflow

```yaml
name: build-model
on:
  push:
    branches: [main]
  pull_request:

jobs:
  model:
    runs-on: ubuntu-24.04
    env:
      OPENMESH_VERSION: "0.1.0"
      OPENMESH_URL: "https://example.com/openmesh-0.1.0-linux-x64.tar.gz"  # your mirror; no public release exists yet
    steps:
      - uses: actions/checkout@v4

      - name: Install OpenMesh
        run: |
          curl -fsSL "$OPENMESH_URL" -o openmesh.tar.gz
          mkdir -p "$HOME/.local/openmesh"
          tar -xzf openmesh.tar.gz -C "$HOME/.local/openmesh" --strip-components=1
          echo "$HOME/.local/openmesh" >> "$GITHUB_PATH"

      - name: Check
        run: openmesh check model.om --json > check.json

      - name: Build
        run: |
          mkdir -p build
          openmesh build model.om -o build/model.glb \
            --triangle-limit 500000 --time-limit 120s --json > build.json

      - name: Render
        run: |
          openmesh render model.om -o build/preview.png \
            --renderer software --size 1024 --json > render.json

      - name: Upload
        uses: actions/upload-artifact@v4
        with:
          name: model
          path: |
            build/model.glb
            build/preview.png
            build.json
            render.json
            check.json
```

The CI runner needs no X11, GPU, or desktop packages. `build` links the CPU rasterizer but does not initialize it.

## JSON parsing

```bash
openmesh build model.om -o model.glb --json > result.json
status=$?

if [ "$status" -eq 0 ]; then
  jq -r '.outputs[0].stats | "\(.triangles) triangles, \(.volume) mm3"' result.json
elif [ "$status" -eq 1 ]; then
  jq -r '.diagnostics[] | "\(.code): \(.hint)"' result.json
elif [ "$status" -eq 3 ]; then
  jq -r '.diagnostics[] | "\(.code): \(.message)"' result.json
else
  echo "build failed with exit code $status" >&2
fi
```

Do not parse the human output. Its column widths and ordering are not part of the contract.

## Limits in CI

| Limit | CI recommendation | Reason |
|---|---|---|
| `--time-limit` | `120s` on hosted runners | CPU time varies with runner load |
| `--memory-limit` | `1GiB` | hosted runners have enough headroom |
| `--triangle-limit` | project-specific, strict | deterministic and catches accidental density |
| `--max-recursion` | `64` | deterministic guard against runaway recursion |
| `--max-source-size` | `16MiB` | catches generated point tables committed by mistake |

A time limit is the only limit that can fail on a slow machine while passing on a fast one. Set it generously in CI
and enforce the triangle limit for reproducibility.

## Concurrency

Two builds of the same model can run at once. The cache is content-addressed: both builds produce the same entry and
the same bytes, so the last writer wins. Artifacts use unique temporary names, so two processes writing the same target
produce one complete file, not an interleaving. Do not run more builds than the runner has memory for; each build can use its full
`--memory-limit`.

## Docker

```dockerfile
FROM ubuntu:24.04
COPY openmesh /usr/local/bin/openmesh
RUN chmod +x /usr/local/bin/openmesh
WORKDIR /work
COPY model.om .
RUN openmesh build model.om -o model.glb --json
```

The image needs only `libstdc++6`; no display libraries. Mount the project at `/work` in a real build and write
artifacts to a mounted output directory.

## Next

- [Export formats](03-export-formats.md)
- [Headless render](04-render.md)
- [CLI usage](01-usage.md)
- [Limits](../language/13-limits.md)
