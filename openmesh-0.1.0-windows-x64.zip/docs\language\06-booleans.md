# Booleans

This page specifies `union`, `difference`, `intersection`, `hull`, and `minkowski`, and explains when the CSG engine
returns a valid solid, when it returns a multi-component solid, and when it reports `E0307`.

## Signature

```om
union(items: List<Solid>) -> Solid
union(items: List<Sketch>) -> Sketch
difference(base: Solid, cut: Solid) -> Solid
difference(base: Sketch, cut: Sketch) -> Sketch
intersection(a: Solid, b: Solid) -> Solid
intersection(a: Sketch, b: Sketch) -> Sketch
hull(items: List<Solid>) -> Solid
hull(items: List<Sketch>) -> Sketch
minkowski(a: Solid, b: Solid) -> Solid
```

Every function is also a method where the first argument is geometry:

```om
let body = difference(box([40mm, 40mm, 10mm]), cylinder(h = 20mm, d = 8mm, center = true));
let same = box([40mm, 40mm, 10mm]).difference(cylinder(h = 20mm, d = 8mm, center = true));
```

## No implicit union

OML does not merge separate expressions. Two solids that are merely declared next to each other are two values;
only an explicit `union` combines them.

```om
// Wrong: the two boxes are never combined and only `b` is exported.
let a = box([10mm, 10mm, 10mm]);
let b = box([10mm, 10mm, 10mm]).translate([20mm, 0mm, 0mm]);
export(b, "two.glb");

// Right: one solid with two components.
export(union([a, b]), "two.glb");
```

This rule is the largest source of surprising output for generated models. If a model describes several pieces,
combine them with `union([...])` before `difference`, `export`, or a modifier.

`union` takes exactly one list. `union(a, b)` is `E0208`; write `union([a, b])`.

## union

Combines every solid in the list. The result is the set union of the volumes.

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `items` | `List<Solid>` or `List<Sketch>` | — | required | at least 1 element, all same type | operands |

- Disjoint operands produce a multi-component solid. This is valid and exports as one mesh with several shells.
- Overlapping operands merge into one shell.
- Operands that share a full face without volume overlap are rejected with `E0312`; overlap by at least 0.01 mm.
- Operands that touch only along an edge or at a vertex can produce a non-manifold result (`E0307`).
- Color: the result takes the color of the first element.

```om
// @om 1
let base = box([60mm, 40mm, 5mm], center = true);
let boss = cylinder(h = 12mm, d = 16mm);
export(union([base, boss]), "boss.glb");
```

The boss starts at `z = 0` and overlaps the plate from `z = 0` to `z = 2.5`, so the union is one watertight solid.
Bounding box `60 x 40 x 14.5 mm`; volume `12000 + π * 64 * 12 - π * 64 * 2.5 = 13910.09 mm3` (the 2.5 mm of overlap
is counted once).

## difference

Subtracts one solid from another. `difference` has exactly two operands; to subtract several cutters, union them
first.

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `base` | `Solid` or `Sketch` | — | required | non-empty | target |
| `cut` | `Solid` or `Sketch` | — | required | same type as `base`, non-empty | removed volume |

```om
// @om 1
let plate = box([60mm, 40mm, 5mm], center = true);
let hole = cylinder(d = 8mm, h = 10mm, center = true);
let holes = [
    hole.translate([-20mm, 0mm, 0mm]),
    hole.translate([ 20mm, 0mm, 0mm]),
];

export(difference(plate, union(holes)), "plate.glb");
```

Bounding box `60 x 40 x 5 mm`; volume `12000 - 2 * π * 16 * 5 = 11497.35 mm3`. The cutters pass fully through the
plate, so the result is watertight.

A cutter that does not intersect the base is valid and returns the base unchanged. A cutter that removes everything
is `E0301`. A cutter that is flush with a face or touches the base only along an edge is `E0307`; move it inward by at
least 0.01 mm. A `union` of two solids that share a full face is `E0312`.

## intersection

Keeps only the common volume of two solids.

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `a` | `Solid` or `Sketch` | — | required | non-empty | first operand |
| `b` | `Solid` or `Sketch` | — | required | same type as `a` | second operand |

```om
// @om 1
let a = box([40mm, 40mm, 40mm]);
let b = box([40mm, 40mm, 40mm]).translate([20mm, 0mm, 0mm]);
export(intersection(a, b), "overlap.glb");
```

The common volume spans `x = 20..40`, `y = 0..40`, `z = 0..40`: bounding box `20 x 40 x 40 mm`, volume
`32000 mm3`. Disjoint operands produce an empty result and `E0301`.

## hull

Returns the convex hull of a list of solids or sketches. The result is the smallest convex shape that contains every
operand.

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `items` | `List<Solid>` or `List<Sketch>` | — | required | at least 1 element | operands |

```om
// @om 1
let a = box([20mm, 20mm, 20mm]);
let b = box([20mm, 20mm, 20mm]).translate([40mm, 0mm, 0mm]);
export(hull([a, b]), "bridge.glb");
```

The hull of two aligned 20 mm cubes 40 mm apart is a `60 x 20 x 20 mm` box with volume `24000 mm3`. Hulls remove
concavities: a hull of a bracket is not the bracket.

## minkowski

Returns the Minkowski sum of two solids: every point of `a` swept by every point of `b`. It rounds and inflates a
shape, and it is expensive.

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `a` | `Solid` | — | required | non-empty, manifold | base solid |
| `b` | `Solid` | — | required | non-empty, manifold, small triangle count | swept solid |

> [!WARNING]
> `minkowski` cost is O(triangles(a) * triangles(b)). A sphere with the default 960 triangles swept over a 12-triangle
> box produces roughly 11,520 output triangles before simplification, plus boolean work. Keep the second operand at
> 16-64 triangles and raise `--triangle-limit` only when the result is required. The modifier page's `fillet` is
> cheaper for edge rounding.

```om
// @om 1
let core = box([20mm, 20mm, 20mm], center = true);
let round = sphere(d = 10mm, segments = 16, rings = 8);
export(minkowski(core, round), "rounded.glb");
```

The result is a rounded cube with bounding box `30 x 30 x 30 mm` and ideal volume
`8000 + 2400 * 5 + (4 / 3) * PI * 125 = 20523.60 mm3`. The faceted sphere produces slightly less.

## Boolean failure modes

The CSG engine operates on triangle meshes and aims to produce a manifold result for manifold inputs. The guarantee does not
cover inputs that are already invalid or configurations where the result has no well-defined neighborhood:

| Input | Result | Error |
|---|---|---|
| Two solids overlap by a volume | valid union | none |
| A union of two solids shares a full face | zero-volume contact | `E0312` |
| Two solids touch along one edge | non-manifold neighborhood | `E0307` |
| Two solids touch at one vertex | non-manifold neighborhood | `E0307` |
| Cutter exactly tangent to a face | zero-thickness contact | `E0307` |
| Cutter leaves an open shell | not watertight | `E0311` |
| Operand is an open or self-intersecting mesh | invalid input | `E0302` |

The fix is geometric, not syntactic: overlap the operands by at least 0.01 mm, or separate them so they do not
touch. The compiler reports the operation and the span instead of writing a broken file.

## Complete example

```om
// @om 1
let plate = box([80mm, 50mm, 6mm], center = true);
let corner = cylinder(d = 8mm, h = 12mm, center = true);
let corners = [
    corner.translate([-30mm, -15mm, 0mm]),
    corner.translate([ 30mm, -15mm, 0mm]),
    corner.translate([-30mm,  15mm, 0mm]),
    corner.translate([ 30mm,  15mm, 0mm]),
];
let pocket = box([40mm, 24mm, 4mm], center = true).translate([0mm, 0mm, 3mm]);

let cutters = union([union(corners), pocket]);
let body = difference(plate, cutters);
export(body, "mount.glb");
```

Bounding box `80 x 50 x 6 mm`; volume `24000 - 4 * π * 16 * 6 - 40 * 24 * 4 = 24000 - 1206.37 - 3840 =
18953.63 mm3`. The corner holes pass through the plate; the pocket removes 4 mm from the top, leaving a 2 mm floor.

## Errors

| Code | Condition | Fix |
|---|---|---|
| `E0201` | mixed `Solid` and `Sketch` operands | convert one side or use matching types |
| `E0208` | `union(a, b)` instead of `union([a, b])` | pass one list |
| `E0301` | `intersection` or `difference` produced an empty solid | check that the operands overlap |
| `E0302` | input is not a closed manifold | close the input mesh |
| `E0307` | result is non-manifold | overlap by 0.01 mm or separate the operands |
| `E0312` | coplanar faces with inconsistent orientation | overlap or offset one operand |
| `E0903` | the boolean exceeds the triangle limit | reduce segments or simplify before the boolean |

## Next

- [2D to 3D](07-2d-to-3d.md)
- [Modifiers](08-modifiers.md)
- [Errors](12-errors.md)
