# Printable bracket

This recipe builds a parametric L-bracket for FDM printing: 60 x 30 x 40 mm, 6 mm thick, two M4 clearance holes in
the base and one in the wall. It compiles as written and reports the bounding box and volume at the end.

## Task

A shelf bracket that carries a light load, mounts with three M4 screws, and prints without supports. The wall is
vertical, the base sits on the bed, and the wall hole is a short bridge.

## Constraints

| Constraint | Value | Reason |
|---|---|---|
| Process | FDM PLA, 0.4 mm nozzle, 0.2 mm layers | common desktop printer |
| Minimum wall | 6 mm | 3 perimeters plus infill, strong screw bearing |
| Hole fit | 4.5 mm for M4 | 0.5 mm diametral clearance |
| Overhang | wall is vertical; wall hole is a 4.5 mm bridge | printable without supports |
| Orientation | base on the bed, wall up | maximum layer adhesion along the load |
| Mass target | under 35 g | 28.2 g solid-equivalent |

## Code

```om
// @om 1
@param width = 60mm { min = 30mm, max = 120mm, step = 1mm, desc = "Overall width" };
@param depth = 30mm { min = 20mm, max = 60mm, step = 1mm, desc = "Base depth" };
@param height = 40mm { min = 20mm, max = 80mm, step = 1mm, desc = "Wall height" };
@param thickness = 6mm { min = 3mm, max = 12mm, step = 0.5mm, desc = "Plate thickness" };
@param hole_d = 4.5mm { min = 2mm, max = 8mm, step = 0.5mm, desc = "M4 clearance diameter" };
@param hole_inset = 12mm { min = 8mm, max = 20mm, step = 1mm, desc = "Hole inset from the edge" };

let base = box([width, depth, thickness]);
let wall = box([width, thickness, height])
    .translate([0mm, depth - thickness, 0mm]);

let base_holes = [
    cylinder(d = hole_d, h = thickness + 2mm, center = true)
        .translate([hole_inset, depth / 2, thickness / 2]),
    cylinder(d = hole_d, h = thickness + 2mm, center = true)
        .translate([width - hole_inset, depth / 2, thickness / 2]),
];

let wall_hole = cylinder(d = hole_d, h = thickness + 2mm, center = true)
    .rotate(X, 90deg)
    .translate([width / 2, depth - thickness / 2, height / 2]);

let body = union([base, wall]);
let cutters = union([union(base_holes), wall_hole]);
let bracket = difference(body, cutters);

export(bracket, "bracket.glb");
export(bracket, "bracket.stl");
```

## Verification

| Check | Expected |
|---|---|
| Bounding box | `60 x 30 x 40 mm` |
| Volume | `22753.72 mm3` |
| Watertight | `true` |
| Components | `1` |
| Base hole centers | `x = 12` and `x = 48`, `y = 15`, through `z = 0..6` |
| Wall hole center | `x = 30`, `y = 27`, `z = 20`, through the 6 mm wall |
| Triangle count | approximately 600 |

The base and wall overlap in `y = 24..30`, `z = 0..6`, so the union is watertight. The hole cutters are 2 mm longer
than the material and centered, so they pass fully through both faces and avoid `E0307`.

## Print settings

| Setting | Value |
|---|---|
| Orientation | base on the bed, wall vertical |
| Perimeters | 4 |
| Infill | 40% gyroid |
| Layer height | 0.2 mm |
| Supports | none |
| Mass | 28.2 g solid-equivalent; about 22 g at 40% gyroid |

The wall hole is a 4.5 mm bridge over 6 mm of material. A well-tuned PLA profile bridges this without supports. If
the top of the hole sags, add a 0.4 mm chamfer with `chamfer(d = 0.4mm, edges = "top")` or drill it after printing.

## Variations

| Change | Effect |
|---|---|
| `--param width=90mm` | wider shelf, same depth and height |
| `--param hole_d=5.5mm` | M5 clearance |
| `--param thickness=9mm` | stronger screw bearing, more material |
| Add a gusset | union a triangular prism between base and wall |
| `fillet(edges = "vertical", r = 2mm)` | round the two outer vertical corners of the wall |

A gusset is a triangular prism that overlaps both the base and the wall. Build it from a `polyhedron` or a closed
triangular sketch extruded across the width, then add it to `union([base, wall, gusset])` before cutting the holes.
Keep the gusset at least 4 mm thick at the root, and do not place it over a base hole.

## Bounding box and volume

```text
bbox:   60 x 30 x 40 mm
volume: 22753.72 mm3  (22.75 cm3)
mass:   28.2 g solid-equivalent (about 22 g at 40% gyroid)
```

## Next

- [Parametric enclosure](parametric-enclosure.md)
- [Laser panel](laser-panel.md)
- [First model](../start/02-first-model.md)
