# Prompting guide

This page shows how to phrase a modeling task so an LLM produces OML that compiles on the first or second attempt.
It applies to a human writing a prompt and to an agent that delegates to another model.

## Prompt anatomy

A useful prompt has seven parts. Missing dimensions and tolerances are the main reason a model guesses.

| Part | What to write | Example |
|---|---|---|
| Object | one sentence, no marketing | "an L-bracket for a shelf" |
| Dimensions | every overall size with a unit | "60 mm wide, 30 mm deep, 40 mm tall" |
| Features | holes, pockets, ribs, with positions and diameters | "two 4.5 mm holes, 12 mm from each edge" |
| Process | manufacturing method and constraints | "FDM PLA, 0.4 mm nozzle, 0.2 mm layers" |
| Tolerances | fits, clearances, minimum wall | "0.2 mm radial clearance for M3, 2.4 mm walls" |
| Parameters | which values must become sliders | "width, height, hole diameter" |
| Output | formats and verification | "GLB and STL; report bbox and volume" |

A prompt that omits the process and the tolerances produces a model that compiles but does not fit. A prompt that
omits units produces `E0203` or, worse, a model that silently uses the wrong scale.

## Template

```text
Write OML 1.0 for <object>.

Geometry:
- overall: <w> x <d> x <h> mm
- features: <holes, pockets, ribs> at <positions>
- symmetry: <none / mirror across X / pattern>

Process:
- FDM PLA, 0.4 mm nozzle, 0.2 mm layers
- minimum wall <t> mm
- fit: <clearance> mm

Parameters:
- <name> = <default> mm, range <min>..<max>, step <step>

Output:
- export GLB and STL
- report bounding box and volume

Constraints:
- use only symbols from docs/ai/00-context-pack.md
- every length and angle has a unit
- combine separate solids with union([...]); no implicit union
- overlap boolean cutters by at least 0.01 mm
- include export(value, "file.ext") at top level
- no while, no unseeded random, no file or network access
```

## Prompt quality

| Bad | Why | Better |
|---|---|---|
| "Make a bracket." | no size or process | "60 x 30 x 40 mm L-bracket, 6 mm thick, FDM PLA." |
| "Make it strong." | no measurable property | "Use 2.4 mm walls, a 6 mm gusset, and 4 perimeters." |
| "Use a 3 mm screw hole." | diameter vs radius | "3.4 mm hole for M3, 0.2 mm radial clearance." |
| "Make it smooth." | no target | "Fillet the four vertical edges with r = 3 mm, 4 segments." |
| "Export it." | no format or path | "Export `bracket.glb` and `bracket.stl`; report bbox and volume." |
| "Use a cube." | `cube` does not exist | "Use `box([w, h, d])`." |

## Parameters

Ask for parameters when the object is a family, not a one-off:

```text
Make width, depth, height, wall, and hole_d parameters with ranges and steps.
Use @param with min, max, step, and desc. Add a @preset small and a @preset large.
```

A parameter default must sit inside its range, otherwise `E0410`. The metadata key is `desc`, not `label`. A
parameter's type comes from its default literal, so `width = 60mm` is a `Length`.

## Repair prompts

When a build fails, send the source, the diagnostic, and the instruction to change one cause:

```text
The build fails with:
  E0307 difference() produced a non-manifold result
  span: line 7, col 5
  hint: overlap the second solid by at least 0.01mm

Return the complete corrected file. Change only the cutter position and height.
Do not rewrite the dimensions or the parameters.
```

A repair prompt that asks for a full rewrite often introduces a second error. Ask for a minimal diff and require
`om_validate` to pass before returning.

## Vision prompts

```text
Render the default contact sheet at 1024 px: isometric, front, top, and right, with the scale bar
and dimensions. The boss should be on the left and the handle should be 12 mm thick. If the
thickness is the question, render mode="thickness"; if an internal feature is hidden, render
mode="section". If a cell disagrees, change the translation or the parameter, then render again.
Stop after three contact sheets.
```

A model with vision can compare the four cells with the request; a text-only model should rely on
`om_query_geometry` and the `section` or `thickness` render for a human reviewer.

## Agent policy

```text
Before writing code, read docs/ai/00-context-pack.md.
Use om_search_docs and om_get_reference instead of guessing signatures.
Run om_validate after every edit. Fix at most three iterations.
Run om_compile without a format to check watertight and volume.
Use om_preview with the default contact sheet only if you can inspect images.
Use om_export only after watertight is true.
Stop and ask the user if the same diagnostic appears twice.
```

This policy keeps the context small and makes the failure mode visible: a model that loops without applying the
hint stops after three iterations instead of consuming the budget.

## Output contract

Ask for:

1. The complete `.om` file as one code block, with `// @om 1`.
2. A short table of parameters and defaults.
3. The expected bounding box and volume.
4. The diagnostics that were fixed, if any.

Do not accept a fragment. A model that returns only the changed function forces the reader to reconstruct the file,
and the next compile fails on a missing `export`.

## Unsupported requests

OpenMesh has no NURBS, sculpting, rigging, animation, cinematic rendering, simulation, or brush texturing. A prompt
that asks for a "smooth class-A surface" or a "rigged character" cannot be satisfied. The model should say so and
offer a mesh-first approximation: a lofted or swept solid, a decimated outline, or a static pose.

## Next

- [Common failures](02-common-failures.md)
- [AI context pack](00-context-pack.md)
- [MCP recipes](../mcp/05-recipes.md)
