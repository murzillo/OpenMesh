# Parametric enclosure

This recipe builds a two-part enclosure with a friction lid, a lid lip, two snap detents, and a cable port. It
reports the assembled bounding box, the volume of both parts, and the print orientation.

## Task

A desktop enclosure for a 100 x 60 mm PCB, printed in PLA. The body has a 2.4 mm wall, a 0.3 mm lid clearance, two
side snap detents, and a 20 x 12 mm cable port. The lid carries a 4 mm lip.

## Constraints

| Constraint | Value | Reason |
|---|---|---|
| Process | FDM PLA, 0.4 mm nozzle, 0.2 mm layers | common desktop printer |
| Wall | 2.4 mm | 6 perimeters at 0.4 mm |
| Lid clearance | 0.3 mm per side | slides without binding |
| Snap engagement | 0.2 mm interference, 2 mm travel | holds without screws |
| Minimum feature | 0.6 mm | printable at 0.4 mm nozzle |
| Port | 20 x 12 mm | cable and connector clearance |

## Code

```om
// @om 1
@param width = 120mm { min = 60mm, max = 240mm, step = 1mm, desc = "Body width" };
@param depth = 80mm { min = 40mm, max = 160mm, step = 1mm, desc = "Body depth" };
@param height = 40mm { min = 20mm, max = 100mm, step = 1mm, desc = "Body height" };
@param wall = 2.4mm { min = 1.2mm, max = 5mm, step = 0.2mm, desc = "Wall thickness" };
@param clearance = 0.3mm { min = 0.1mm, max = 0.6mm, step = 0.05mm, desc = "Lid clearance per side" };
@param lid_h = 8mm { min = 4mm, max = 20mm, step = 1mm, desc = "Lid plate height" };
@param lip_h = 4mm { min = 2mm, max = 10mm, step = 0.5mm, desc = "Lid lip height" };
@param port_w = 20mm { min = 5mm, max = 60mm, step = 1mm, desc = "Cable port width" };
@param port_h = 12mm { min = 5mm, max = 30mm, step = 1mm, desc = "Cable port height" };

let cw = width - 2 * wall;
let cd = depth - 2 * wall;

let outer = box([width, depth, height]);
let cavity = box([cw, cd, height - wall + 1mm])
    .translate([wall, wall, wall]);
let port = box([port_w, 5mm, port_h])
    .translate([width / 2 - port_w / 2, -1mm, height / 2 - port_h / 2]);

let win_l = box([wall + 2mm, 8mm, 3mm])
    .translate([-1mm, depth / 2 - 4mm, height - 5mm]);
let win_r = box([wall + 2mm, 8mm, 3mm])
    .translate([width - wall - 1mm, depth / 2 - 4mm, height - 5mm]);

let body = difference(outer, union([cavity, port, win_l, win_r]));

let plate = box([width, depth, lid_h])
    .translate([0mm, 0mm, height]);
let lip_outer = box([cw - 2 * clearance, cd - 2 * clearance, lip_h + 0.1mm])
    .translate([wall + clearance, wall + clearance, height - lip_h]);
let lip_inner = box([
        cw - 2 * clearance - 2 * wall,
        cd - 2 * clearance - 2 * wall,
        lip_h + 0.1mm,
    ])
    .translate([wall + clearance + wall, wall + clearance + wall, height - lip_h]);
let lip = difference(lip_outer, lip_inner);

let bump_l = box([0.6mm, 6mm, 3mm])
    .translate([wall + clearance - 0.5mm, depth / 2 - 3mm, height - 5mm]);
let bump_r = box([0.6mm, 6mm, 3mm])
    .translate([width - wall - clearance - 0.1mm, depth / 2 - 3mm, height - 5mm]);

let lid = union([plate, lip, bump_l, bump_r])
    .color(rgb(70, 120, 180));
let housing = body.color(rgb(210, 210, 210));

export([housing, lid], "enclosure.glb");
export([housing, lid], "enclosure.3mf");
```

The cavity cutter ends 1 mm above the top face, so the body is open at the top and the cutter never coincides with
the outer top plane. The lid plate overlaps the lip by 0.1 mm, and each bump overlaps the lip by 0.1 mm, so both
unions have a positive volume overlap instead of touching faces.

## Verification

| Check | Expected |
|---|---|
| Assembled bounding box | `120 x 80 x 48 mm` |
| Body bounding box | `120 x 80 x 40 mm` |
| Lid bounding box | `120 x 80 x 13 mm` (z = 35..48) |
| Body volume | `57578.5 mm3` |
| Lid volume | `80359.7 mm3` |
| Total volume | `137938.2 mm3` (137.9 cm3) |
| Watertight | `true` for both |
| Components | `1` per part, `2` objects in the list |
| Lid clearance | `0.3 mm` per side |
| Snap travel | `3 mm` window, `2 mm` engagement |
| Wall thickness | `2.4 mm` |

The snap window is 3 mm tall (`z = 35..38`), the bump is 3 mm tall in the same range, and the lip starts at
`z = 36`. The bump therefore engages the window over 2 mm and can be released by lifting the lid 2-3 mm.

## Print orientation

| Part | Orientation | Supports |
|---|---|---|
| Body | as modeled, floor on the bed | none |
| Lid | flip 180deg about X, plate on the bed, lip up | none |

For a print plate, create a flipped copy of the lid:

```om
let lid_print = lid.rotate(X, 180deg).translate([0mm, 0mm, height + lid_h]);
export([housing, lid_print], "enclosure-print.3mf");
```

The flipped lid spans `z = 0..13`; the lip and bumps print upward without supports. The body prints with the cable
port as a bridge over 12 mm; a 12 mm bridge is printable at 0.2 mm layers with cooling, but add a 0.4 mm chamfer
around the port if the top edge sags.

## Variations

| Change | Effect |
|---|---|
| `--param wall=3mm` | stronger wall, smaller cavity |
| `--param clearance=0.45mm` | looser lid for rough printers |
| `--param port_w=30mm` | wider cable opening |
| Add a second port | duplicate `port` and union it into the cutters |
| Add bosses | union four cylinders at the corners, then drill M3 holes |
| Add a gasket groove | subtract a 1.5 mm wide, 1 mm deep ring from the lid lip |

For a gasket groove, subtract a thin frame from `lip_outer` before the lip difference. Keep the remaining lip wall
at least 1.2 mm so it does not break during insertion.

## Bounding box and volume

```text
assembled bbox: 120 x 80 x 48 mm
body volume:     57578.5 mm3
lid volume:      80359.7 mm3
total:          137938.2 mm3  (137.9 cm3)
solid mass:      171.0 g at PLA 1.24 g/cm3
```

## Next

- [Printable bracket](printable-bracket.md)
- [Laser panel](laser-panel.md)
- [Modifiers](../language/08-modifiers.md)
