# Modifiers

This page specifies `fillet`, `chamfer`, `shell`, `array`, and `subdivide`, plus the edge and face selector API.
Read the limits before the examples: a modifier that is applied to the wrong topology fails with a specific error
instead of guessing.

## Signature

```om
fillet(solid: Solid, r: Length, edges: EdgeSelector | String = "all", segments: Number = 4) -> Solid
chamfer(solid: Solid, d: Length, edges: EdgeSelector | String = "all") -> Solid
shell(solid: Solid, thickness: Length, open: FaceSelector | String = "none") -> Solid
array(shape: Sketch | Solid, count: Number, offset: Vec2 | Vec3) -> Sketch | Solid
subdivide(solid: Solid, level: Number = 1) -> Solid
```

All five are methods on their first geometry argument: `body.fillet(r = 3mm)`, `body.shell(thickness = 2mm)`.
`array` and `subdivide` follow the same rule.

## Applicability limits

| Modifier | Works on | Rejects or skips |
|---|---|---|
| `fillet` | convex edges of a closed `Solid`, <=90deg | concave and >90deg edges are skipped; open meshes rejected |
| `chamfer` | any edge of a closed `Solid` | edges shorter than `2d`, open meshes |
| `shell` | a closed `Solid` without self-intersection | walls that collide, narrow slots, internal voids |
| `array` | any `Sketch` or `Solid` | `count < 1`, zero offset |
| `subdivide` | any `Solid` | `level > 3`, results above the triangle limit |

`fillet` is not a general rounding operator. It does not round a concave internal corner, it does not repair a
non-manifold solid, and it does not blend two separate bodies. `shell` breaks when the inward offset of two walls
meets: the compiler detects the collapse and reports `E0310` rather than emitting an inverted mesh.

## Selectors

Selectors filter edges or faces before a modifier uses them. They are values of type `EdgeSelector` or
`FaceSelector`; they are not geometry.

```om
body.edges                                      // every edge
body.edges.where(vertical)                      // preset constant
body.edges.where("vertical")                    // preset string
body.edges.where(e => e.length > 5mm)           // closure
body.edges.length(min = 5mm, max = 50mm)        // second filter
body.edges.count()                              // Number
body.edges.total_length()                       // Length
body.faces.where(top)                           // face preset
body.faces.where(f => f.normal.z > 0.9)         // closure
```

Edge presets: `"vertical"`, `"horizontal"`, `"top"`, `"bottom"`, `"convex"`, `"concave"`, `"all"`. Face presets:
`"top"`, `"bottom"`, `"vertical"`, `"horizontal"`, `"all"`. The constants `vertical`, `horizontal`, `top`,
`bottom`, `convex`, `concave`, and `all` are accepted by `.where`.

| Selector field | Type | Meaning |
|---|---|---|
| `edge.length` | `Length` | edge length |
| `edge.angle` | `Angle` | dihedral angle between adjacent faces |
| `edge.direction` | `Vec3` | unit direction from the lower vertex to the higher vertex |
| `edge.center` | `Vec3` | midpoint |
| `face.normal` | `Vec3` | outward unit normal |
| `face.area` | `Number` | face area in mm2 |
| `face.center` | `Vec3` | centroid |

`vertical` selects edges whose direction is parallel to Z within 1e-6. `horizontal` selects edges in a plane of
constant Z. `top` selects edges or faces on the maximum-Z plane of the current solid's bounding box. A selector that
matches no element is `E0317` when passed to a modifier.

```om
// @om 1
let body = box([60mm, 40mm, 20mm], center = true);
let vertical_edges = body.edges.where("vertical");
let long_edges = body.edges.where(e => e.length > 10mm);

export([
    body.fillet(r = 2mm, edges = vertical_edges),
    body.chamfer(d = 1mm, edges = long_edges),
], "edges.glb");
```

The example exports two variants of the same box. `body` is immutable, so each modifier returns a new solid.

## fillet

Rounds convex edges with a circular arc of radius `r`. Concave edges in the selection are skipped. If no selected
edge is convex with a dihedral angle at most 90 degrees, the modifier fails with `E0309`.

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `solid` | `Solid` | — | required | closed, manifold | input body |
| `r` | `Length` | mm | required | `0 < r < half of the shortest adjacent edge` | fillet radius |
| `edges` | `EdgeSelector \| String` | — | `"all"` | matches at least one convex edge | edges to round |
| `segments` | `Number` | count | `4` | integer, 1..32 | arc segments per edge |

### Example

```om
// @om 1
let body = box([40mm, 40mm, 20mm], center = true)
    .fillet(edges = "vertical", r = 3mm, segments = 4);
export(body, "rounded-block.glb");
```

### Result

Bounding box stays `40 x 40 x 20 mm`. The four vertical edges gain a 3 mm radius; volume drops from `32000 mm3` to
approximately `31845 mm3` (four corners each remove `(1 - PI / 4) * 9 * 20 = 38.63 mm3`). Triangle count grows from
12 to roughly 100 because each rounded edge adds a four-segment strip and each corner adds a patch.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0308` | `r` is too large for an adjacent edge or face | lower `r` or split the edge |
| `E0309` | no selected edge is convex with an angle at most 90deg | use `chamfer`, or select the correct edges |
| `E0302` | the input is not a closed manifold | fix the input first |
| `E0317` | the selector matches no edge | widen the selector |

## chamfer

Cuts a flat bevel at distance `d` along the selected convex edges. A concave rim is left sharp: cutting it with a
half-space can remove the wall.

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `solid` | `Solid` | — | required | closed, manifold | input body |
| `d` | `Length` | mm | required | `0 < d < half of the shortest adjacent edge` | bevel distance |
| `edges` | `EdgeSelector \| String` | — | `"all"` | matches at least one convex edge | convex edges to bevel |

### Example

```om
// @om 1
let body = box([40mm, 40mm, 10mm], center = true)
    .chamfer(d = 2mm, edges = "vertical");
export(body, "beveled-block.glb");
```

### Result

Bounding box stays `40 x 40 x 10 mm`; the four vertical edges are cut by 2 mm. Volume is approximately
`32000 - 4 * 0.5 * 2 * 2 * 10 = 31920 mm3`. Triangle count rises from 12 to about 44.

### Circular rims

A closed circular rim is cut as one revolved wedge instead of one plane per segment. A cylinder, a flange, or a hole
entrance therefore gets a true ring chamfer:

```om
let disc = cylinder(d = 40mm, h = 10mm);
export(disc.chamfer(edges = "top", d = 2mm), "disc.glb");
```

The result stays `40 x 40 x 10 mm`, is watertight, and loses about 240 mm³. The facet count follows the rim: 48 side
quads produce a 48-sided cone. Edges whose faces are almost coplanar (interior angle above about 160°) are ignored, so
`edges = "all"` does not bevel the flat seams between side quads.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0308` | `d` is too large for an adjacent face | lower `d` |
| `E0317` | the selector matches no edge | widen the selector |

## shell

Hollows a solid, leaving a wall of `thickness`. The `open` argument removes one or more faces, turning the hollow
into a tray or an enclosure.

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `solid` | `Solid` | — | required | closed, manifold, no self-intersection | input body |
| `thickness` | `Length` | mm | required | `0 < thickness < half the smallest bbox dimension` | wall thickness |
| `open` | `FaceSelector \| String` | — | `"none"` | face preset or selector | faces to remove |

### Example

```om
// @om 1
let tray = box([40mm, 40mm, 20mm], center = true)
    .shell(thickness = 2mm, open = "top");
export(tray, "tray.glb");
```

### Result

Bounding box `40 x 40 x 20 mm`. The wall is 2 mm, the floor is 2 mm, and the top is open. Volume
`32000 - 36 * 36 * 18 = 8672 mm3`; 32 triangles.

> [!WARNING]
> `shell` offsets faces inward. When two inward offsets meet, the wall closes on itself and the result is not a
> valid solid. The compiler detects the collapse (`E0310`) for thickness values at or above half the smallest
> bounding-box dimension and for narrow slots. Split the body into simpler pieces or reduce the thickness.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0310` | the wall collapses or self-intersects | lower `thickness`, remove the narrow feature, or split the body |
| `E0317` | the face selector matches no face | use `"top"`, `"bottom"`, or a valid selector |
| `E0302` | the input is not a closed manifold | fix the input |

## array

Repeats a shape along a constant offset and unions the copies.

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `shape` | `Sketch \| Solid` | — | required | non-empty | prototype |
| `count` | `Number` | count | required | integer, 1..10000 | number of copies |
| `offset` | `Vec2 \| Vec3` | mm | required | non-zero, matches the shape dimension | translation per copy |

### Example

```om
// @om 1
let cell = box([10mm, 10mm, 10mm]);
let row = cell.array(count = 4, offset = [15mm, 0mm, 0mm]);
export(row, "row.glb");
```

### Result

Four 10 mm cubes at `x = 0, 15, 30, 45 mm`. Bounding box `55 x 10 x 10 mm`, volume `4000 mm3`, 48 triangles. The
copies are disjoint and the union keeps four shells. `count = 0` is `E0207`; a zero offset is `E0207`.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0207` | `count < 1` or non-integer | use an integer count |
| `E0207` | zero offset | pass a non-zero vector |
| `E0201` | `Vec2` offset on a `Solid` | match the dimension |
| `E0903` | the array exceeds the triangle limit | lower `count` or `segments` |

## subdivide

Splits each triangle into four without moving vertices. The operation increases mesh density and does not smooth
the shape.

### Parameters

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `solid` | `Solid` | — | required | non-empty | input body |
| `level` | `Number` | count | `1` | integer, 0..3 | subdivision levels |

### Example

```om
// @om 1
let cube = box(20mm, center = true).subdivide(level = 1);
export(cube, "subdivided.glb");
```

### Result

Bounding box and volume are unchanged: `20 x 20 x 20 mm`, `8000 mm3`. Triangles go from 12 to `12 * 4 = 48`;
vertices go from 8 to 26 because edge midpoints are shared. `level = 2` produces 192 triangles, `level = 3` produces
768. Subdivision does not round corners; use `fillet` or `minkowski` for that.

### Errors

| Code | Condition | Fix |
|---|---|---|
| `E0207` | `level < 0`, `level > 3`, or non-integer | use 0..3 |
| `E0903` | the result exceeds the triangle limit | lower the level |

## Complete example

```om
// @om 1
@param wall = 2mm { min = 1.2mm, max = 4mm, step = 0.2mm, desc = "Wall thickness" };
@param radius = 3mm { min = 1mm, max = 8mm, step = 0.5mm, desc = "Corner radius" };

let body = box([80mm, 50mm, 30mm], center = true)
    .fillet(edges = "vertical", r = radius)
    .shell(thickness = wall, open = "top")
    .chamfer(d = 0.8mm, edges = "top");

export(body, "tray.glb");
```

The body is rounded first, then hollowed, then the top rim is chamfered. Chamfering before shelling would cut the
inner wall as well and produce an inconsistent wall thickness.

## Errors

| Code | Condition | Fix |
|---|---|---|
| `E0208` | wrong argument count | check the signature |
| `E0209` | unknown named argument | use `r`, `edges`, `segments`, `thickness`, `open`, `count`, `offset`, or `level` |
| `E0308` | modifier size exceeds the local geometry | lower the size |
| `E0309` | no selected edge is convex with an angle at most 90deg | select convex edges or use `chamfer` |
| `E0310` | shell collapses | lower `thickness` |
| `E0317` | selector matches nothing | widen the selector |

## Next

- [Variables and functions](09-variables-and-functions.md)
- [Parametric enclosure](../recipes/parametric-enclosure.md)
- [OML reference](00-reference.md)
