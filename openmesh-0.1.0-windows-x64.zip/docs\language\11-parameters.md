# Parameters

This page specifies `@param` and `@preset`: the syntax, the metadata that drives sliders, validation, and the CLI
overrides. Parameters are the interface between one model and a family of parts.

## Declaration

```om
@param width = 80mm { min = 20mm, max = 300mm, step = 1mm, desc = "Enclosure width" };
@param wall = 2mm { min = 0.8mm, max = 6mm, step = 0.2mm, desc = "Wall thickness" };
@param diameter = 3.4mm { min = 2mm, max = 8mm, step = 0.1mm, desc = "Hole diameter" };
```

`@param` declares an immutable binding. The default expression determines the type. An optional annotation can
pin it:

```om
@param width: Length = 80mm { min = 20mm, max = 300mm, step = 1mm };
```

The compiler infers `Length`, `Angle`, `Number`, `Bool`, or `String`. `Color` and geometry values are not valid
parameter types; a model that needs a color choice uses a string option and applies the color in a branch.

Parameters are top-level only (`E0414` applies to `export`, and `@param` in a block is `E0108`). They are visible in
the whole file and can be used before their declaration.

## Metadata

| Key | Applies to | Unit | Meaning |
|---|---|---|---|
| `min` | `Length`, `Angle`, `Number` | same as the parameter | lower bound, inclusive |
| `max` | `Length`, `Angle`, `Number` | same as the parameter | upper bound, inclusive |
| `step` | `Length`, `Angle`, `Number` | same as the parameter | slider increment, must be positive |
| `unit` | `Length`, `Angle` | `mm`, `cm`, `m`, `in`; `deg`, `rad` | display unit; does not convert the value |
| `desc` | all | text | one-line description shown in the panel |
| `group` | all | text | panel section name |
| `options` | `String` | list of strings | allowed values; renders a dropdown |

`min`, `max`, and `step` must use the parameter's type and unit tag. A length parameter with `min = 2` (a bare
number) is `E0202`; `min = 2in` on a millimetre parameter is `E0205`, so convert with `to_mm(2in)`.

A default outside `[min, max]` is `E0410`. A non-positive `step` is `E0207`. A `step` larger than the range is
accepted but produces a one-value slider; the compiler emits no warning.

## Slider panel

The desktop editor builds the parameter panel from the metadata:

| Parameter type | Control | Behavior |
|---|---|---|
| `Length`, `Angle`, `Number` with `min` and `max` | slider plus field | clamps to range, steps by `step` |
| `Length`, `Angle`, `Number` without a range | text field | accepts an explicit unit, validates the type |
| `Bool` | checkbox | `true` / `false` |
| `String` with `options` | dropdown | restricts to the listed values |
| `String` without options | text field | free text |

Editing a control recompiles the model and updates the viewport. The edited value is a new default in memory; it is
not written back to the source file unless the user saves it. Parameters never mutate during a single compile.

## Example: M3 clearance hole

```om
// @om 1
@param d = 3mm {
    min = 2mm, max = 6mm, step = 0.5mm,
    unit = "mm", desc = "Nominal screw diameter"
};
@param clearance = 0.2mm {
    min = 0mm, max = 0.6mm, step = 0.05mm,
    unit = "mm", desc = "Radial clearance"
};

let hole_d = d + 2 * clearance;
let hole = cylinder(h = 10mm, d = hole_d, center = true);

export(hole, "m3-clearance.glb");
```

For `d = 3mm` and `clearance = 0.2mm`, `hole_d` is `3.4mm`, the volume is `π * 1.7^2 * 10 = 90.79 mm3`, and the
bounding box is `3.4 x 3.4 x 10 mm`. A nominal M3 screw has a 3 mm major diameter, so the 0.4 mm diametral
clearance gives a sliding fit in FDM at 0.2 mm layer height.

## Presets

```om
@preset loose {
    clearance = 0.3mm;
}
@preset press {
    clearance = 0.05mm;
}
```

A preset overrides parameter defaults by name. It cannot introduce a new name (`E0401`), change a type (`E0201`),
or set a value outside the range (`E0410`). Presets are applied before the model is evaluated, so every reference to
the parameter sees the preset value.

## CLI overrides

```bash
openmesh build model.om -o hole.glb --param clearance=0.3mm
openmesh build model.om -o hole.glb --preset loose
openmesh params model.om --json
```

| Flag | Effect |
|---|---|
| `--param name=value` | overrides one parameter; repeatable |
| `--preset name` | applies a preset; a later `--param` wins |
| `--json` (on `params`) | prints parameters and presets as JSON |

`--param` values are parsed as OML literals: `0.3mm`, `45deg`, `12`, `true`, `"round"`. A value without a unit for a
`Length` parameter is `E0203`. An unknown name is `E0401`; a type mismatch is `E0201`.

## MCP

MCP tools accept only source text, not a separate parameter map. An agent changes a default in the source or
rewrites the call that uses it. `om_get_reference` returns the parameter metadata for a page, and `om_compile`
reports the resolved parameters in `stats` so the agent can confirm which values were used.

## Errors

| Code | Condition | Fix |
|---|---|---|
| `E0202` | metadata value has the wrong type | match the parameter type and unit |
| `E0205` | metadata mixes units | convert to the parameter's unit |
| `E0207` | `step <= 0` | use a positive step |
| `E0401` | preset sets an unknown name | use a declared parameter |
| `E0410` | default or preset value outside `[min, max]` | widen the range or fix the value |
| `E0108` | `@param` or `@preset` syntax is malformed | add `= value` and a valid metadata block |

## Next

- [Errors](12-errors.md)
- [Limits](13-limits.md)
- [Parametric enclosure](../recipes/parametric-enclosure.md)
