# Errors

This page is the complete diagnostic catalog for OML 1.0. Every compiler error has a stable code, a span, an action
in `hint`, an optional `suggestion`, and a link to a section of this page. Read the catalog when a build fails or
when an agent needs to repair generated source without guessing.

## Diagnostic object

```json
{
  "code": "E0307",
  "severity": "error",
  "message": "difference() produced a non-manifold result",
  "span": { "start": 142, "end": 168, "line": 7, "col": 5 },
  "hint": "The cutter is flush with a face or touches only an edge. Overlap the target by 0.01mm.",
  "suggestion": "cylinder(d = 10mm, h = 2.02mm).translate([0mm, 0mm, -0.01mm])",
  "doc": "docs/language/12-errors.md#e0307"
}
```

| Field | Type | Meaning |
|---|---|---|
| `code` | string | stable identifier, `E` for errors, `W` for warnings |
| `severity` | string | `error` or `warning` |
| `message` | string | one sentence, no fix |
| `span.start` | number | 0-based UTF-8 byte offset, inclusive |
| `span.end` | number | 0-based UTF-8 byte offset, exclusive |
| `span.line` | number | 1-based line |
| `span.col` | number | 1-based column in Unicode code points |
| `hint` | string | required action that resolves the error |
| `suggestion` | string | optional replacement source |
| `doc` | string | repository-relative path and anchor |

A diagnostic without `hint` is a compiler bug. A `suggestion` is valid OML and is meant to be applied to the span,
not appended to the file.

## Catalog

| Code | Title |
|---|---|
| [`E0101`](#e0101) | Unexpected character |
| [`E0102`](#e0102) | Unterminated string |
| [`E0103`](#e0103) | Unterminated block comment |
| [`E0104`](#e0104) | Expected expression |
| [`E0105`](#e0105) | Unclosed delimiter |
| [`E0106`](#e0106) | Invalid number literal |
| [`E0107`](#e0107) | Unknown unit suffix |
| [`E0108`](#e0108) | Malformed annotation |
| [`E0109`](#e0109) | Invalid escape sequence |
| [`E0201`](#e0201) | Type mismatch |
| [`E0202`](#e0202) | Expected Length, got Number |
| [`E0203`](#e0203) | Missing unit suffix |
| [`E0204`](#e0204) | Invalid arithmetic between Length and Number |
| [`E0205`](#e0205) | Mixed units |
| [`E0206`](#e0206) | Angle requires a unit |
| [`E0207`](#e0207) | Value out of range |
| [`E0208`](#e0208) | Wrong argument count |
| [`E0209`](#e0209) | Unknown named argument |
| [`E0210`](#e0210) | Division by zero |
| [`E0211`](#e0211) | Index out of bounds |
| [`E0301`](#e0301) | Empty boolean result |
| [`E0302`](#e0302) | Non-manifold solid |
| [`E0303`](#e0303) | Self-intersecting sketch |
| [`E0304`](#e0304) | Open sketch |
| [`E0305`](#e0305) | Degenerate triangle |
| [`E0306`](#e0306) | Zero-volume solid |
| [`E0307`](#e0307) | difference() produced a non-manifold result |
| [`E0308`](#e0308) | Fillet radius or chamfer distance too large |
| [`E0309`](#e0309) | Edge not supported by fillet |
| [`E0310`](#e0310) | Shell collapse |
| [`E0311`](#e0311) | Result is not watertight |
| [`E0312`](#e0312) | Coincident faces in union |
| [`E0313`](#e0313) | Sweep path too sharp |
| [`E0314`](#e0314) | Revolve profile crosses axis |
| [`E0315`](#e0315) | Offset collapses sketch |
| [`E0316`](#e0316) | Non-planar polygon |
| [`E0317`](#e0317) | Selector matched no elements |
| [`E0318`](#e0318) | Modifier is not local to the selected edges |
| [`E0401`](#e0401) | Undefined name |
| [`E0402`](#e0402) | Duplicate definition |
| [`E0403`](#e0403) | Reassignment of immutable binding |
| [`E0404`](#e0404) | Module not found |
| [`E0405`](#e0405) | Circular import |
| [`E0406`](#e0406) | Private symbol access |
| [`E0407`](#e0407) | Path outside project root |
| [`E0408`](#e0408) | Unknown type |
| [`E0409`](#e0409) | No export |
| [`E0410`](#e0410) | Parameter default outside range |
| [`E0411`](#e0411) | Circular value reference |
| [`E0412`](#e0412) | Unsupported export extension |
| [`E0413`](#e0413) | Duplicate export path |
| [`E0414`](#e0414) | Export inside a block |
| [`E0415`](#e0415) | Return outside function |
| [`E0901`](#e0901) | CPU limit exceeded |
| [`E0902`](#e0902) | Memory limit exceeded |
| [`E0903`](#e0903) | Triangle limit exceeded |
| [`E0904`](#e0904) | Recursion depth exceeded |
| [`E0905`](#e0905) | Import depth exceeded |
| [`E0906`](#e0906) | Source size exceeded |

## E01xx: lexer and parser

## E0101

**Unexpected character.** The lexer found a character that does not start a token.

**Hint:** Remove the character or replace it with an ASCII equivalent; only `//`, `/*`, `"""`-free strings, and the
documented operators are valid.

```om
// bad
let x = 10mm § 2mm;
```

```om
// good
let x = 10mm + 2mm;
```

## E0102

**Unterminated string.** A string reached a newline or the end of the file before the closing quote.

**Hint:** Close the string with `"` on the same line; use `\n` for a line break inside a string.

```om
// bad
let name = "body;
```

```om
// good
let name = "body";
```

## E0103

**Unterminated block comment.** A `/*` has no matching `*/`.

**Hint:** Add `*/` after the comment text; block comments do not nest.

```om
// bad
/* dimensions
let x = 10mm;
```

```om
// good
/* dimensions */
let x = 10mm;
```

## E0104

**Expected expression.** A construct that requires a value found `)`, `]`, `}`, a comma, or a newline.

**Hint:** Put a value after `=` or inside the parentheses; every declaration needs an initializer.

```om
// bad
let x = ;
```

```om
// good
let x = 10mm;
```

## E0105

**Unclosed delimiter.** A `(`, `[`, or `{` has no matching closing delimiter.

**Hint:** Add the missing closing delimiter before the end of the statement; count pairs when calls are nested.

```om
// bad
let x = box([10mm, 20mm, 30mm];
```

```om
// good
let x = box([10mm, 20mm, 30mm]);
```

## E0106

**Invalid number literal.** A number has a trailing dot, a missing exponent, or two dots.

**Hint:** Write `1.0` instead of `1.`, and include digits after `e`.

```om
// bad
let x = 1.;
```

```om
// good
let x = 1.0;
```

## E0107

**Unknown unit suffix.** A number is followed by an unknown suffix, or a space separates the number and the unit.

**Hint:** Use `mm`, `cm`, `m`, `in`, `deg`, or `rad` directly after the digits, with no space.

```om
// bad
let x = 10 mm;
```

```om
// good
let x = 10mm;
```

## E0108

**Malformed annotation.** `@param` or `@preset` is missing `= value`, a name, or a valid metadata block.

**Hint:** Write `@param name = value { key = value, ... };` and close the metadata block.

```om
// bad
@param width 80mm { min = 20mm };
```

```om
// good
@param width = 80mm { min = 20mm };
```

## E0109

**Invalid escape sequence.** A string uses a backslash followed by a character that is not `"`, `\`, `n`, `t`, or
`r`.

**Hint:** Escape the backslash as `\\`; Windows paths in OML use forward slashes or doubled backslashes.

```om
// bad
let path = "C:\models\part.glb";
```

```om
// good
let path = "C:/models/part.glb";
```

## E02xx: types and units

## E0201

**Type mismatch.** A value has a different type from the one required by the declaration, parameter, or branch.

**Hint:** Check both sides of the expression. A `Length` needs a unit such as `10mm`; a vector needs `Length`
components; a function value must be called with `()`. For a builtin, compare the call with its signature in
[the reference](00-reference.md).

```om
// bad: circle returns a Sketch
fn outline(w: Length) -> Solid {
    circle(d = w)
}
```

```om
// good: extrude the sketch into a solid
fn outline(w: Length) -> Solid {
    extrude(circle(d = w), 3mm)
}
```

```om
// good
fn outline(w: Length) -> Sketch {
    circle(d = w)
}
```

## E0202

**Expected Length, got Number.** A `Number` value was passed where a `Length` is required.

**Hint:** Add a unit to the value or multiply a dimensionless factor by a length.

```om
// bad
let x: Length = 10;
```

```om
// good
let x: Length = 10mm;
```

## E0203

**Missing unit suffix.** A numeric literal in a length or angle position has no suffix.

**Hint:** Write `10mm` instead of `10`; the only unitless literal accepted as a length is `0`.

```om
// bad
@param width = 40 { min = 10, max = 100 };
```

```om
// good
@param width = 40mm { min = 10mm, max = 100mm };
```

## E0204

**Invalid arithmetic between Length and Number.** `+` or `-` combined a length with a dimensionless number.

**Hint:** Add only lengths; multiply a number by a length when scaling is intended.

```om
// bad
let x = 10mm + 5;
```

```om
// good
let x = 10mm + 5mm;
```

## E0205

**Mixed units.** An operation combined `mm` with `in`, `cm`, `m`, `deg`, or `rad` without conversion.

**Hint:** Convert one operand with `to_mm`, `to_cm`, `to_m`, `to_in`, `to_deg`, or `to_rad`.

```om
// bad
let x = 10mm + 1in;
```

```om
// good
let x = 10mm + to_mm(1in);
```

## E0206

**Angle requires a unit.** A bare number was used where an `Angle` is expected.

**Hint:** Add `deg` or `rad`, including for common angles such as `90deg`.

```om
// bad
let a = 90;
let p = [10mm * cos(a), 0mm, 0mm];
```

```om
// good
let a = 90deg;
let p = [10mm * cos(a), 0mm, 0mm];
```

## E0207

**Value out of range.** A dimension is zero or negative, a count is not an integer, or two mutually exclusive
arguments are set.

**Hint:** Use a positive dimension, an integer count within the documented range, and exactly one of `r`/`delta`.

```om
// bad
let c = cylinder(h = 10mm, d = -2mm);
```

```om
// good
let c = cylinder(h = 10mm, d = 2mm);
```

## E0208

**Wrong argument count.** A call has too few or too many arguments.

**Hint:** Compare the call with the signature; named arguments still count toward the total.

```om
// bad
let c = cylinder(10mm);
```

```om
// good
let c = cylinder(h = 10mm, d = 5mm);
```

## E0209

**Unknown named argument.** A named argument does not match any parameter name.

**Hint:** Use the documented parameter name; `diameter` is `d`, and `height` is `h`.

```om
// bad
let c = cylinder(h = 10mm, diameter = 5mm);
```

```om
// good
let c = cylinder(h = 10mm, d = 5mm);
```

## E0210

**Division by zero.** `/`, `%`, or a range division produced a zero divisor.

**Hint:** Guard the divisor with an `if` or change the range so the step is non-zero.

```om
// bad
let x = 10 / 0;
```

```om
// good
let x = 10 / 2;
```

## E0211

**Index out of bounds.** A list index is negative or greater than or equal to `len(list)`.

**Hint:** Index within `0 .. len(list) - 1`; for the last element use `len(list) - 1`.

```om
// bad
let p = [[0mm, 0mm], [10mm, 0mm]][2];
```

```om
// good
let p = [[0mm, 0mm], [10mm, 0mm]][0];
```

## E03xx: geometry and CSG

## E0301

**Empty boolean result.** A `difference` removed everything, or an `intersection` has no common volume.

**Hint:** Check that the operands overlap; move the cutter or expand the intersection operand.

```om
// bad
intersection(box(10mm), box(10mm).translate([50mm, 0mm, 0mm]));
```

```om
// good
intersection(box(10mm), box(10mm).translate([5mm, 0mm, 0mm]));
```

## E0302

**Non-manifold solid.** A `polyhedron` is open, has an edge used once, has inward winding, or has a non-manifold
vertex.

**Hint:** Close the surface, order every face counter-clockwise seen from outside, and use each edge exactly twice.

```om
// bad: only three faces, the surface is open
let t = polyhedron(
    points = [[0, 0, 0], [10mm, 0mm, 0mm], [0mm, 10mm, 0mm], [0mm, 0mm, 10mm]],
    faces = [[0, 2, 1], [0, 1, 3], [0, 3, 2]],
);
```

```om
// good
let t = polyhedron(
    points = [[0, 0, 0], [10mm, 0mm, 0mm], [0mm, 10mm, 0mm], [0mm, 0mm, 10mm]],
    faces = [[0, 2, 1], [0, 1, 3], [0, 3, 2], [1, 2, 3]],
);
```

## E0303

**Self-intersecting sketch.** A polygon boundary crosses itself, or a hole crosses the outer boundary.

**Hint:** Reorder the points so the boundary is simple; holes must lie strictly inside the outer loop.

```om
// bad: bow-tie
let s = polygon([[0, 0], [20mm, 20mm], [20mm, 0], [0, 20mm]]);
```

```om
// good
let s = polygon([[0, 0], [20mm, 0], [20mm, 20mm], [0, 20mm]]);
```

## E0304

**Open sketch.** `extrude`, `revolve`, `offset`, or a boolean received an open `path`.

**Hint:** Set `closed = true` on the path, or build the region with `polygon`.

```om
// bad
let p = path([[0, 0], [20mm, 0], [20mm, 10mm]]);
let s = p.extrude(5mm);
```

```om
// good
let p = path([[0, 0], [20mm, 0], [20mm, 10mm], [0, 10mm]], closed = true);
let s = p.extrude(5mm);
```

## E0305

**Degenerate triangle.** Two vertices coincide, a face has zero area, or a segment has zero length.

**Hint:** Remove duplicate consecutive points and give every face a non-zero area.

```om
// bad
let s = polygon([[0, 0], [10mm, 0], [10mm, 0], [10mm, 10mm]]);
```

```om
// good
let s = polygon([[0, 0], [10mm, 0], [10mm, 10mm]]);
```

## E0306

**Zero-volume solid.** An extrusion height is zero, a revolve angle is zero, or a scaled solid collapsed.

**Hint:** Use a positive height or angle; a zero-size feature cannot become a solid.

```om
// bad
let s = rect(10mm, 10mm).extrude(0mm);
```

```om
// good
let s = rect(10mm, 10mm).extrude(5mm);
```

## E0307

**difference() produced a non-manifold result.** The cutter is flush with a face or touches the target only along an
edge or a vertex, so the result has no well-defined neighborhood.

**Hint:** Overlap the cutter with the target by at least 0.01 mm; do not rely on exact contact.

```om
// bad: the cutter starts exactly at the top face
let plate = box([20mm, 20mm, 2mm]);
let cut = cylinder(d = 8mm, h = 2mm).translate([0mm, 0mm, 2mm]);
let body = difference(plate, cut);
```

```om
// good
let plate = box([20mm, 20mm, 2mm]);
let cut = cylinder(d = 8mm, h = 2.02mm).translate([0mm, 0mm, 1.99mm]);
let body = difference(plate, cut);
```

## E0308

**Fillet radius or chamfer distance too large.** The requested size does not fit the adjacent faces or is larger
than half the shortest edge.

**Hint:** Lower `r` or `d` to less than half of the shortest edge at the selected corners.

```om
// bad
let b = box(20mm, center = true).fillet(r = 12mm, edges = "vertical");
```

```om
// good
let b = box(20mm, center = true).fillet(r = 2mm, edges = "vertical");
```

## E0309

**Edge not supported by fillet.** No selected edge is convex with a dihedral angle at most 90 degrees.

**Hint:** Select different edges or use `chamfer`; `fillet` skips concave edges and edges above 90 degrees, and
fails only when no selected edge qualifies.

```om
// bad: the cone base edge is not a supported fillet edge
let c = cone(h = 20mm, d = 10mm).fillet(r = 1mm, edges = "all");
```

```om
// good
let c = cone(h = 20mm, d = 10mm).chamfer(d = 1mm, edges = "all");
```

## E0310

**Shell collapse.** The wall thickness made two inward faces meet or self-intersect.

**Hint:** Lower `thickness` below half the smallest bounding-box dimension; remove narrow slots or split the body.

```om
// bad
let s = box([20mm, 20mm, 20mm], center = true).shell(thickness = 10mm, open = "top");
```

```om
// good
let s = box([20mm, 20mm, 20mm], center = true).shell(thickness = 2mm, open = "top");
```

## E0311

**Result is not watertight.** A sweep without caps, an open shell, or an invalid input produced a surface with a
boundary.

**Hint:** Enable caps, close the input, and export only watertight solids; a 3D print requires a closed mesh.

```om
// bad
let pipe = circle(d = 8mm).sweep([[0, 0, 0], [0, 0, 40mm]], cap = false);
```

```om
// good
let pipe = circle(d = 8mm).sweep([[0, 0, 0], [0, 0, 40mm]], cap = true);
```

## E0312

**Coincident faces in union.** A `union` of two solids shares an exact face without a volume overlap; the compiler
requires a positive overlap to resolve the surface.

**Hint:** Offset one operand by 0.01 mm so the faces overlap instead of coincide.

```om
// bad: face-to-face contact
let a = box([10mm, 10mm, 10mm]);
let b = box([10mm, 10mm, 10mm]).translate([10mm, 0mm, 0mm]);
let c = union([a, b]);
```

```om
// good
let a = box([10mm, 10mm, 10mm]);
let b = box([10mm, 10mm, 10mm]).translate([9.99mm, 0mm, 0mm]);
let c = union([a, b]);
```

## E0313

**Sweep path too sharp.** A path corner turns by more than 90 degrees and the profile self-intersects on the inside
of the turn.

**Hint:** Split the sweep into two paths and union the results, or round the corner with a radius larger than the
profile half-width.

```om
// bad: a 90-degree turn with a 10mm profile
let pipe = circle(d = 20mm).sweep([[0, 0, 0], [30mm, 0, 0], [30mm, 30mm, 0]], cap = true);
```

```om
// good: two straight sweeps, each capped, then unioned
let a = circle(d = 20mm).sweep([[0, 0, 0], [30mm, 0, 0]], cap = true);
let b = circle(d = 20mm).sweep([[30mm, 0, 0], [30mm, 30mm, 0]], cap = true);
let pipe = union([a, b]);
```

## E0314

**Revolve profile crosses axis.** A profile point has `x < 0`, so the revolved volume intersects itself.

**Hint:** Move the profile to `x >= 0`; touching `x = 0` is allowed, crossing it is not.

```om
// bad
let p = polygon([[-5mm, 0mm], [5mm, 0mm], [5mm, 10mm], [-5mm, 10mm]]);
let s = p.revolve(360deg);
```

```om
// good
let p = polygon([[5mm, 0mm], [15mm, 0mm], [15mm, 10mm], [5mm, 10mm]]);
let s = p.revolve(360deg);
```

## E0315

**Offset collapses sketch.** A negative offset removed the whole region or left a self-intersecting boundary.

**Hint:** Reduce the magnitude of the negative offset and keep it below half the smallest width.

```om
// bad
let s = rect(40mm, 20mm).offset(r = -30mm);
```

```om
// good
let s = rect(40mm, 20mm).offset(r = -5mm);
```

## E0316

**Non-planar polygon.** A `polyhedron` face has vertices that do not lie in one plane.

**Hint:** Split the face into triangles; each triangle is planar by construction.

```om
// bad: four points not in one plane
let p = polyhedron(
    points = [[0, 0, 0], [10mm, 0, 0], [10mm, 10mm, 5mm], [0, 10mm, 0]],
    faces = [[0, 1, 2, 3]],
);
```

```om
// good
let p = polyhedron(
    points = [[0, 0, 0], [10mm, 0, 0], [10mm, 10mm, 5mm], [0, 10mm, 0]],
    faces = [[0, 1, 2], [0, 2, 3]],
);
```

## E0317

**Selector matched no elements.** An `edges` or `faces` filter selected nothing, so the modifier has no work.

**Hint:** Widen the filter, check the preset name, or confirm that the solid has the edge orientation you expect.

```om
// bad: no edge is longer than 1 m
let base = box(20mm, center = true);
let b = base.fillet(r = 2mm, edges = base.edges.where(e => e.length > 1m));
```

```om
// good
let base = box(20mm, center = true);
let b = base.fillet(r = 2mm, edges = base.edges.where(e => e.length > 5mm));
```

## E0318

**Modifier is not local to the selected edges.** A `fillet`, `chamfer`, or `shell` removed material that the selected
edges cannot account for. The usual cause is an edge selection on a boolean result: the seam between two operands is
not a real outer edge, and cutting along it slices the body while still producing a watertight mesh.

**Hint:** Apply the modifier to the primitive before the boolean, reduce the size, or leave the edge sharp.

```om
// bad: the fillet runs after the union and selects the seam
let body = union([box([80mm, 60mm, 6mm]), box([80mm, 6mm, 70mm])]);
export(body.fillet(edges = "vertical", r = 4mm), "part.glb");
```

```om
// good: fillet the primitive, then combine
let plate = box([80mm, 60mm, 6mm]);
export(plate.fillet(edges = "vertical", r = 2mm), "plate.glb");
```

The compiler checks every modifier against its input: the bounding box may shrink by at most the operation's reach,
the volume may not grow, and the removed volume must be explainable by the selected edge length.

## E04xx: names and scopes

## E0401

**Undefined name.** A value or function is not declared in the current scope or any imported module.

**Hint:** Check the spelling and the import alias; use `box` instead of `cube`, and `0..n` instead of `range`.

```om
// bad
let b = boxx([10mm, 10mm, 10mm]);
```

```om
// good
let b = box([10mm, 10mm, 10mm]);
```

## E0402

**Duplicate definition.** Two declarations in the same scope use the same name.

**Hint:** Rename one declaration; shadowing is allowed only in an inner block.

```om
// bad
let width = 10mm;
let width = 20mm;
```

```om
// good
let width = 10mm;
let inner_width = 20mm;
```

## E0403

**Reassignment of immutable binding.** An assignment targets an existing `let` or parameter name.

**Hint:** Create a new binding with a new name; OML has no mutation.

```om
// bad
let width = 10mm;
width = 20mm;
```

```om
// good
let width = 10mm;
let wider = 20mm;
```

## E0404

**Module not found.** An `import` path does not resolve to a file inside the project root.

**Hint:** Check the relative path, the `.om` extension, and the project root passed with `--root`.

```om
// bad
import "./parts/missing.om" as parts;
```

```om
// good
import "./parts/base.om" as parts;
```

## E0405

**Circular import.** Module `a` imports `b`, which imports `a`.

**Hint:** Move the shared declarations into a third module that both import.

```om
// bad: a.om imports b.om, b.om imports a.om
// a.om
import "./b.om" as b;
// b.om
import "./a.om" as a;
```

```om
// good: both import c.om
// a.om
import "./c.om" as c;
// b.om
import "./c.om" as c;
```

## E0406

**Private symbol access.** A module name starts with `_` and is not exported.

**Hint:** Use a public symbol or add a public wrapper in the module.

```om
// bad
let h = fast._clearance(3mm, 0.2mm);
```

```om
// good
let h = fast.m3_hole(10mm);
```

## E0407

**Path outside project root.** An import or export resolves above the directory given by `--root`.

**Hint:** Use a path inside the project root; `..` cannot escape the sandbox.

```om
// bad
export(box(10mm), "../out.glb");
```

```om
// good
export(box(10mm), "out.glb");
```

## E0408

**Unknown type.** A type annotation names a type that OML does not define.

**Hint:** Use `Number`, `Length`, `Angle`, `Bool`, `String`, `Vec2`, `Vec3`, `Sketch`, `Solid`, `Color`, or `List<T>`.

```om
// bad
fn f(x: Cuboid) -> Solid { box(x); }
```

```om
// good
fn f(x: Vec3) -> Solid { box(x); }
```

## E0409

**No export.** The model compiled but declares no `export`, so there is nothing to write.

**Hint:** Add `export(value, "file.ext")` at top level; a `let` alone is not an output.

```om
// bad
let b = box(10mm);
```

```om
// good
let b = box(10mm);
export(b, "box.glb");
```

## E0410

**Parameter default outside range.** A default or preset value violates `min` or `max`.

**Hint:** Widen the range or move the default inside it; `min <= default <= max`.

```om
// bad
@param width = 5mm { min = 10mm, max = 100mm };
```

```om
// good
@param width = 20mm { min = 10mm, max = 100mm };
```

## E0411

**Circular value reference.** Top-level values depend on each other in a cycle.

**Hint:** Break the cycle by making one value a function parameter or a literal.

```om
// bad
let a = b + 1mm;
let b = a + 1mm;
```

```om
// good
let a = 10mm;
let b = a + 1mm;
```

## E0412

**Unsupported export extension.** An `export` path ends in an extension that is not `.glb`, `.obj`, `.stl`, `.3mf`,
`.svg`, or `.dxf`.

**Hint:** Use a supported extension; the extension chooses the writer.

```om
// bad
export(box(10mm), "part.step");
```

```om
// good
export(box(10mm), "part.glb");
```

## E0413

**Duplicate export path.** Two `export` calls target the same path.

**Hint:** Give every export a unique path, or remove the duplicate.

```om
// bad
export(a, "part.glb");
export(b, "part.glb");
```

```om
// good
export(a, "part-a.glb");
export(b, "part-b.glb");
```

## E0414

**Export inside a block.** `export` was called inside a function, `if`, or `for`.

**Hint:** Move the export to top level and export the value returned by the function.

```om
// bad
fn save(s: Solid) {
    export(s, "part.glb");
}
```

```om
// good
let s = box(10mm);
export(s, "part.glb");
```

## E0415

**Return outside function.** A `return` statement appears at top level or inside a block that is not a function body.

**Hint:** Remove the `return` and let the top-level expression stand, or move it into an `fn`.

```om
// bad
return box(10mm);
```

```om
// good
fn make() -> Solid {
    return box(10mm);
}
```

## E09xx: limits and resources

## E0901

**CPU limit exceeded.** Compilation used more than the configured CPU time, 10 s by default.

**Hint:** Lower `segments`/`rings`, simplify booleans, or raise `--time-limit`; the message reports the actual time.

```om
// bad: a sphere with 1024 x 512 divisions and a boolean per triangle
let s = sphere(d = 100mm, segments = 1024, rings = 512);
```

```om
// good
let s = sphere(d = 100mm, segments = 64, rings = 32);
```

## E0902

**Memory limit exceeded.** Compilation used more than the configured RAM, 512 MiB by default.

**Hint:** Reduce mesh density or split the model into modules; raise `--memory-limit` only when the machine has room.

```om
// bad: a million-element array held at once
let cells = for i in 0..1000000 { box(1mm).translate([i * 1mm, 0mm, 0mm]) };
```

```om
// good
let cells = for i in 0..1000 { box(1mm).translate([i * 1mm, 0mm, 0mm]) };
```

## E0903

**Triangle limit exceeded.** The result has more than 2,000,000 triangles.

**Hint:** Reduce segment counts, replace `minkowski` with `fillet`, or raise `--triangle-limit`.

```om
// bad
let s = sphere(d = 100mm, segments = 1024, rings = 512).minkowski(box(1mm));
```

```om
// good
let s = sphere(d = 100mm, segments = 64, rings = 32);
```

## E0904

**Recursion depth exceeded.** A function called itself more than 64 times without reaching a base case.

**Hint:** Add a terminating branch, reduce the recursion depth, or convert the pattern to a `for` range.

```om
// bad: no base case
fn f(n: Number) -> Solid {
    f(n + 1)
}
```

```om
// good
fn f(n: Number) -> Solid {
    if n == 0 { box(10mm) } else { box(10mm).translate([0mm, 0mm, n * 10mm]) }
}
```

## E0905

**Import depth exceeded.** The import chain is deeper than 16 modules.

**Hint:** Flatten the module hierarchy; a shared module should be imported directly, not through a chain of wrappers.

```om
// bad: a chain of 17 modules, each importing the next
// a.om -> b.om -> ... -> q.om
```

```om
// good: a.om imports the shared module directly
import "./shared.om" as shared;
```

## E0906

**Source size exceeded.** The root source or the combined imported source is larger than 16 MiB.

**Hint:** Split the model into smaller modules or remove generated point tables that are no longer used.

```om
// bad: a single 20 MiB .om file of literal points
```

```om
// good: split the points into modules imported by the root file
import "./points/a.om" as a;
import "./points/b.om" as b;
```

## Warnings

Warnings do not stop compilation. They carry the same object shape with `severity: "warning"`.

| Code | Meaning | Action |
|---|---|---|
| `W0101` | compiler major version differs from the `// @om` header | update the header or the compiler |
| `W0102` | a binding shadows an outer binding | rename the inner binding |
| `W0103` | a deprecated symbol is used | migrate to the replacement named in the message |

## Next

- [Limits](13-limits.md)
- [MCP error contract](../mcp/04-error-contract.md)
- [Common LLM failures](../ai/02-common-failures.md)
