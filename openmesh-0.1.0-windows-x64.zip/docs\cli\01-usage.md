# CLI usage

> **Status: 0.1.0.** The commands below are in the released Windows x64 archive. The behavior may change in a 0.x
> minor release.

This page lists every command, flag, exit code, and output shape of the `openmesh` binary. Read it when scripting a
build or wiring OpenMesh into CI.

## Invocation

```text
openmesh <command> [arguments] [flags]
```

| Command | Purpose |
|---|---|
| `build` | compile a model and write the artifacts declared by `export` |
| `check` | parse and typecheck without evaluating geometry |
| `preview` | render a quick single-view PNG with the CPU rasterizer |
| `render` | render a deterministic contact sheet for CI and vision models |
| `params` | print parameters and presets |
| `docs` | open or print the bundled documentation |
| `mcp` | start the Model Context Protocol server |
| `cache` | inspect or clear the build cache |
| `version` | print the compiler, OML, and platform versions |
| `help` | print command help |

Global flags apply to every command:

| Flag | Default | Meaning |
|---|---|---|
| `--root DIR` | directory of the input file | project root for imports and source exports |
| `--json` | off | write a single JSON object to stdout; logs go to stderr |
| `--quiet` | off | suppress progress output; diagnostics still print |
| `--verbose` | off | print timing and cache information |
| `--color auto\|always\|never` | `auto` | colorize text output |
| `--help` | — | print help and exit 0 |
| `--version` | — | print the version and exit 0 |

`--root` does not change the working directory. It defines the sandbox boundary for `import` and for paths inside
`export(...)` calls. The `-o` flag is resolved against the current working directory and may point outside the root
because the user typed it.

## build

Compiles a model, validates every solid, and writes every `export` target.

```text
openmesh build <input.om> [-o PATH] [flags]
```

| Flag | Unit | Default | Meaning |
|---|---|---|---|
| `-o, --output PATH` | path | — | override the only export target; requires exactly one export |
| `--param name=value` | literal | — | override a parameter; repeatable |
| `--preset name` | name | — | apply a preset before `--param` overrides |
| `--dry-run` | — | off | compile and validate without writing files |
| `--no-cache` | — | off | bypass the artifact cache |
| `--cache-dir DIR` | path | `<root>/.openmesh-cache` | cache location |
| `--time-limit DURATION` | `ms`, `s`, `m` | `10s` | CPU budget |
| `--memory-limit SIZE` | `MiB`, `GiB` | `512MiB` | peak memory budget |
| `--triangle-limit N` | count | `2000000` | final triangle budget |
| `--max-recursion N` | frames | `64` | function recursion limit |
| `--max-import-depth N` | files | `16` | import chain limit |
| `--max-source-size SIZE` | bytes | `16MiB` | root plus imports |
| `--max-artifact-size SIZE` | bytes | `1GiB` | maximum size of one artifact |

Examples:

```bash
openmesh build cable-clip.om
openmesh build cable-clip.om -o clip.glb
openmesh build enclosure.om --preset compact --param wall=2.4mm
openmesh build model.om --dry-run --json
```

Without `-o`, `build` writes every `export` in the source, in lexicographic path order. With `-o`, the model must
declare exactly one export; otherwise the command exits with code 2 and the message:

```text
openmesh: -o requires exactly one export, found 2 (bracket.glb, bracket.stl)
```

A source with no export exits with code 1 and `E0409`.

Text output for a model with two exports:

```text
bracket.glb  60 x 30 x 40 mm  22753.72 mm3  glb  18420 bytes
bracket.stl  60 x 30 x 40 mm  22753.72 mm3  stl  11204 bytes
```

JSON output for a single-export model:

```json
{
  "ok": true,
  "command": "build",
  "outputs": [
    {
      "path": "cable-clip.glb",
      "format": "glb",
      "bytes": 12840,
      "sha256": "8f0c...",
      "stats": {
        "triangles": 200,
        "vertices": 102,
        "bbox": { "min": [-15, -9, 0], "max": [15, 9, 12] },
        "volume": 5575.22,
        "area": 2583.86,
        "watertight": true,
        "components": 1
      }
    }
  ],
  "diagnostics": [],
  "duration_ms": 38
}
```

## check

Runs the lexer, parser, and typechecker. It does not evaluate geometry and does not write files, so it is fast enough
for a pre-commit hook and for an agent's first validation step.

`check` cannot see values that depend on geometry. A model can pass `check` and fail `build` with `E0205`, `E03xx`, or
`E09xx` when a computed size mixes units, a boolean produces a non-manifold result, a modifier is not local to its
selection, or a resource limit is exceeded. Run `build` before export or printing.

```text
openmesh check <input.om> [flags]
```

Flags: `--json`, `--param`, `--preset`, `--root`, `--time-limit`, `--memory-limit`, `--triangle-limit`.

```bash
openmesh check model.om
openmesh check model.om --json --param wall=3mm
```

Text output on success:

```text
model.om: ok
parameters: width=80mm, wall=2mm
exports: enclosure.glb (glb)
```

JSON output on success:

```json
{
  "ok": true,
  "command": "check",
  "params": { "width": "80mm", "wall": "2mm" },
  "exports": [{ "path": "enclosure.glb", "format": "glb" }],
  "diagnostics": [],
  "duration_ms": 3
}
```

On failure, `ok` is `false`, `diagnostics` contains up to five entries, and the exit code is 1. `check` does not
report triangle counts or volume because it does not evaluate geometry.

## preview

Renders a quick single-view PNG with the CPU rasterizer. The camera is orthographic and looks at the combined
bounding box of all exported values. For a deterministic contact sheet, use `render` below.

```text
openmesh preview <input.om> [-o PATH] [flags]
```

| Flag | Unit | Default | Meaning |
|---|---|---|---|
| `-o, --output PATH` | path | `preview.png` | image path |
| `--camera PRESET` | preset | `iso` | `iso`, `front`, `back`, `left`, `right`, `top`, `bottom` |
| `--size N` | pixels | `768` | square image side, 128..2048 |
| `--background COLOR` | hex | `#202020` | background color |
| `--param`, `--preset` | — | — | same as `build` |

```bash
openmesh preview model.om -o model.png --camera iso --size 1024
openmesh preview model.om --camera top --size 512 --json
```

JSON output:

```json
{
  "ok": true,
  "command": "preview",
  "path": "model.png",
  "bytes": 48211,
  "camera": "iso",
  "size": 1024,
  "stats": { "triangles": 200, "watertight": true },
  "diagnostics": [],
  "duration_ms": 62
}
```

The preview is a diagnostic image, not a render. It has no lights, shadows, or materials beyond a flat base color. A
preview needs no GPU and no display server; it works over SSH and in a container.

## render

Renders a deterministic contact sheet: isometric plus front, top, and right views, a scale bar, and labeled
dimensions. This is the command for CI artifacts and vision models. The full flag set and the modes are on the
[Headless render](04-render.md) page.

```text
openmesh render <input.om> [-o PATH] [flags]
```

| Flag | Unit | Default | Meaning |
|---|---|---|---|
| `-o, --output PATH` | path | `render.png` | output image |
| `--views LIST` | names | `iso,front,top,right` | comma-separated views |
| `--mode MODE` | name | `shaded` | `shaded`, `wire`, `section`, `thickness` |
| `--size N` | pixels | `1024` | long edge of the sheet, 256..2048 |
| `--renderer NAME` | name | `software` | `software` for byte-identical output |
| `--param`, `--preset` | — | — | parameter overrides |

```bash
openmesh render model.om -o sheet.png
openmesh render model.om -o wire.png --mode wire --views iso,right
openmesh render model.om -o section.png --mode section --views front,top
```

The `software` renderer is byte-identical across runs and machines. `auto` may use a GPU and may change bytes.

## params

Prints the parameter schema and the resolved defaults.

```text
openmesh params <input.om> [--json] [--param name=value] [--preset name]
```

Text output:

```text
width      Length  80mm    20mm..300mm  step 1mm    Enclosure width
wall       Length  2mm     0.8mm..6mm   step 0.2mm  Wall thickness
style      String  "round" round|square             Corner style
presets: compact, loose
```

JSON output:

```json
{
  "params": [
    {
      "name": "width",
      "type": "Length",
      "default": "80mm",
      "min": "20mm",
      "max": "300mm",
      "step": "1mm",
      "unit": "mm",
      "desc": "Enclosure width",
      "group": "Body",
      "options": null
    }
  ],
  "presets": { "compact": { "width": "50mm" } }
}
```

An unknown parameter or preset name is `E0401` and exit code 1.

## docs

Opens the bundled documentation in the viewer, or prints it.

```text
openmesh docs [page] [flags]
```

| Flag | Meaning |
|---|---|
| `--list` | print every page path and title |
| `--print` | print the page content to stdout as Markdown |
| `--open` | open the viewer even on a headless machine (fails without a display) |

```bash
openmesh docs
openmesh docs language/00-reference.md
openmesh docs --list
openmesh docs start/02-first-model.md --print
```

Paths are relative to `docs/`. Without a page, the command opens `docs/index.md` or the README when no index exists.
On a headless machine without `--print`, the command prints the absolute path of the requested file instead of
starting a GUI.

## mcp

Starts the Model Context Protocol server. The full contract is in the [MCP section](../mcp/01-overview.md).

```text
openmesh mcp [--root DIR] [--http ADDR] [--read-only] [flags]
```

| Flag | Default | Meaning |
|---|---|---|
| `--root DIR` | current directory | project root for imports and exports |
| `--http ADDR` | off | listen on `host:port` with Streamable HTTP instead of stdio |
| `--read-only` | off | disable `om_export` and artifact writing |
| `--time-limit`, `--memory-limit`, `--triangle-limit` | defaults | per-call limits |
| `--max-artifact-size SIZE` | `1GiB` | maximum size of one artifact |

```bash
openmesh mcp --root C:\work\models
openmesh mcp --root . --read-only
openmesh mcp --root . --http 127.0.0.1:7331
```

The stdio transport prints nothing to stdout except JSON-RPC frames. Logs go to stderr. `--read-only` still allows
`om_compile` without a format and `om_preview`, because neither writes to the project.

## cache

```text
openmesh cache info [--cache-dir DIR]
openmesh cache clear [--cache-dir DIR]
```

```bash
openmesh cache info
openmesh cache clear
```

`info` prints the cache directory, entry count, and total size. `clear` removes the directory. The cache is safe to
delete at any time; a missing cache only makes the next build slower.

## version

```bash
openmesh version
```

```text
openmesh 0.1.0 (oml 1.0)
```

`openmesh --version` and `openmesh version --json` are equivalent; the JSON form is:

```json
{ "openmesh": "0.1.0", "oml": "1.0", "platform": "windows-x64" }
```

## Exit codes

| Code | Meaning | Typical cause |
|---|---|---|
| 0 | success | artifacts written, or check passed |
| 1 | model diagnostics | syntax, type, unit, geometry, or export error |
| 2 | usage or configuration | unknown flag, missing input, `-o` with multiple exports |
| 3 | resource limit | `E0901`, `E0902`, `E0903`, `E0904`, `E0905`, `E0906` |
| 4 | I/O | permission denied, disk full, missing output directory |
| 5 | internal error | compiler bug; include the diagnostic and version in a report |
| 130 | interrupted | Ctrl+C |

`--json` never changes the exit code. A script should branch on the exit code first and then read `diagnostics`.

## Complete example

```bash
openmesh check enclosure.om --json > check.json
openmesh build enclosure.om --preset compact --param wall=2.4mm
openmesh render enclosure.om -o enclosure.png --mode shaded
openmesh params enclosure.om --json > params.json
openmesh cache info
```

## Next

- [Build and CI](02-build-and-ci.md)
- [Export formats](03-export-formats.md)
- [Headless render](04-render.md)
- [MCP overview](../mcp/01-overview.md)
