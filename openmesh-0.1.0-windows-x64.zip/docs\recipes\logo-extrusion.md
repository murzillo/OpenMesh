# Logo extrusion

This recipe turns a flat vector logo into a beveled 3D badge: an SVG path becomes a contour with a hole, the contour
is extruded, and the top edges are chamfered. It reports the bounding box and volume with and without the bevel.

## Task

A hexagonal ring logo, 80 mm across, extruded to 6 mm, with a 0.8 mm chamfer on the exposed edges. The result is a
badge or a keychain insert.

## Constraints

| Constraint | Value | Reason |
|---|---|---|
| Process | FDM PLA or resin | flat back, no supports |
| Outer size | 80 mm across | fits a 100 mm bed |
| Ring width | 12 mm | strong enough at 6 mm height |
| Minimum feature | 0.8 mm | printable chamfer |
| Back | flat | first layer adhesion |
| Orientation | flat on the bed | no supports |

## From SVG to contour

OpenMesh does not read SVG at compile time: the DSL has no file I/O. Convert the SVG path to points once and paste
the points into `polygon`.

1. In an SVG editor, convert strokes to paths and flatten curves to line segments at 0.1 mm tolerance.
2. Read the `d` attribute. For a path made of `M`, `L`, and `Z` commands, each coordinate pair is a point.
3. Negate the SVG Y coordinate, because SVG Y points down and OML Y points up.
4. Put the outer loop in `points` and the inner loop in `holes`.

Example SVG path for the outer hexagon:

```text
M 40,0 L 20,34.641 L -20,34.641 L -40,0 L -20,-34.641 L 20,-34.641 Z
```

| SVG point | OML point (Y negated) |
|---|---|
| `(40, 0)` | `(40mm, 0mm)` |
| `(20, 34.641)` | `(20mm, -34.641mm)` |
| `(-20, 34.641)` | `(-20mm, -34.641mm)` |
| `(-40, 0)` | `(-40mm, 0mm)` |
| `(-20, -34.641)` | `(-20mm, 34.641mm)` |
| `(20, -34.641)` | `(20mm, 34.641mm)` |

The example is symmetric, so negating Y produces the same six points in reverse order. For an asymmetric logo, the
negation matters. A curve becomes a series of short lines; the compiler has no bezier primitive.

## Code

```om
// @om 1
@param outer_r = 40mm { min = 20mm, max = 80mm, step = 1mm, desc = "Outer hex radius" };
@param inner_r = 28mm { min = 10mm, max = 70mm, step = 1mm, desc = "Inner hex radius" };
@param h = 6mm { min = 2mm, max = 20mm, step = 0.5mm, desc = "Extrusion height" };
@param bevel = 0.8mm { min = 0.1mm, max = 2mm, step = 0.1mm, desc = "Chamfer size" };

let outer = for i in 0..6 {
    vec2(outer_r * cos(60deg * i), outer_r * sin(60deg * i))
};
let inner = for i in 0..6 {
    vec2(inner_r * cos(60deg * i), inner_r * sin(60deg * i))
};

let ring = polygon(outer, holes = [inner]);
let logo = ring.extrude(h).chamfer(d = bevel, edges = "all");

export(logo, "logo.glb");
export(logo, "logo.stl");
```

## Verification

| Check | Expected before bevel | Expected after 0.8 mm bevel |
|---|---|---|
| Bounding box | `80 x 69.282 x 6 mm` | approximately `78.4 x 67.9 x 6 mm` |
| Ring area | `2120.03 mm2` | approximately `2100 mm2` |
| Volume | `12720.18 mm3` | approximately `12540 mm3` |
| Watertight | `true` | `true` |
| Hole clearance | 28 mm inner radius | unchanged at the mid-height |
| Components | `1` | `1` |

The outer hex area is `(3 * sqrt(3) / 2) * 40^2 = 4156.92 mm2`; the inner hex area is `2036.89 mm2`; the ring is
`2120.03 mm2`. Extruding 6 mm gives `12720.18 mm3`.

The chamfer cuts both the top and bottom perimeter and the vertical edges, so the bounding box shrinks slightly and
the volume drops by roughly 180 mm3. The exact values come from `om_query_geometry`.

## Bevel versus fillet

`chamfer` cuts a flat bevel and accepts every edge, convex or concave. `fillet` rounds an edge and supports convex
edges with a dihedral angle at most 90 degrees. For a logo, the chamfer reads as a machined bevel and prints with a
crisp highlight; a fillet reads as a soft plastic edge.

```om
let soft = ring.extrude(h).fillet(r = 1mm, edges = "top");
```

`edges = "top"` restricts the round to the top perimeter, keeping the bottom flat on the bed. The bounding box stays
80 x 69.282 x 6 mm because the bottom face is untouched.

## Variations

| Change | Effect |
|---|---|
| `--param inner_r=24mm` | thicker ring, larger area |
| `--param h=10mm` | taller badge |
| `--param bevel=1.2mm` | stronger highlight; check the 12 mm ring width |
| `.extrude(h, twist = 15deg, slices = 16)` | twisted ring, taller bounding box |
| `.color(rgb(200, 60, 40))` | red material in GLB/3MF |

A twist on a ring with a hole can self-intersect near the inner corners at large angles. Keep the twist below
`15deg` for a 12 mm ring, or increase `slices` to 32 and inspect the preview.

## SVG export

The same contour can be exported back to SVG for a laser-cut template:

```om
export(ring, "logo-template.svg");
```

The SVG writer flips Y back, so the file matches the original orientation.

## Bounding box and volume

```text
bbox before bevel: 80 x 69.282 x 6 mm
volume before:     12720.18 mm3
bbox after bevel:  approximately 78.4 x 67.9 x 6 mm
volume after:      approximately 12540 mm3
```

## Next

- [Laser panel](laser-panel.md)
- [Modifiers](../language/08-modifiers.md)
- [Export formats](../cli/03-export-formats.md)
