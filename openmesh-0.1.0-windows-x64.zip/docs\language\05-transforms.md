# Transforms

This page specifies translation, rotation, scaling, and mirroring for sketches and solids, including the exact
composition order. Transform bugs are the second most common source of wrong geometry after unit errors, so the
order rules are stated with numbers.

## Signature

```om
translate(v: Vec2 | Vec3, child: Sketch | Solid) -> Sketch | Solid
rotate(angle: Angle, child: Sketch) -> Sketch
rotate(axis: Vec3, angle: Angle, child: Solid) -> Solid
scale(s: Number | List<Number>, child: Sketch | Solid) -> Sketch | Solid
mirror(normal: Vec3, child: Sketch | Solid) -> Sketch | Solid
```

Every function is also a method on its first geometry argument:

```om
let a = translate([0mm, 0mm, 5mm], box([10mm, 10mm, 10mm]));
let b = box([10mm, 10mm, 10mm]).translate([0mm, 0mm, 5mm]);
```

`a` and `b` are the same solid. Method chains apply from left to right; nested free calls apply from the inside out.

## translate

Moves geometry by a vector. A `Vec2` moves a `Sketch` in the XY plane; a `Vec3` moves a `Solid` or a `Sketch` in
space.

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `v` | `Vec2 \| Vec3` | mm | required | finite components | translation vector |
| `child` | `Sketch \| Solid` | — | required | matching dimension | geometry to move |

```om
// @om 1
let post = cylinder(h = 20mm, d = 8mm).translate([10mm, 0mm, 5mm]);
export(post, "post.glb");
```

The cylinder axis is still Z; the base moves from `z = 0` to `z = 5` and the center from `x = 0` to `x = 10`.
Bounding box `8 x 8 x 20 mm` at `x = 6..14`, `y = -4..4`, `z = 5..25`.

## rotate

Rotates a sketch around the origin in the XY plane, or a solid around an arbitrary axis through the origin. The
angle is counter-clockwise for a positive value, following the right-hand rule: `rotate(Z, 90deg)` maps `+X` to
`+Y`.

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `angle` | `Angle` | deg | required | finite | 2D rotation angle |
| `axis` | `Vec3` | mm | required | non-zero length | 3D rotation axis |
| `child` | `Sketch \| Solid` | — | required | matching overload | geometry to rotate |

```om
// @om 1
let flat = rect(20mm, 10mm, center = true);
let turned = flat.rotate(90deg);

let bar = box([20mm, 10mm, 5mm], center = true);
let tilted = bar.rotate(X, 30deg);

export(turned, "turned.svg");
export(tilted, "tilted.glb");
```

`turned` has bounding box `10 x 20 mm`, area `200 mm2`, and is rotated about the origin. `tilted` is rotated about
the X axis; its bounding box grows in Y and Z because the bar is no longer axis-aligned.

## scale

Scales geometry about the origin. A single `Number` scales uniformly; a list of two or three `Number`s scales per
axis.

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `s` | `Number \| List<Number>` | dimensionless | required | every component > 0 | scale factors |
| `child` | `Sketch \| Solid` | - | required | matching dimension | geometry to scale |

> [!WARNING]
> Scale factors are dimensionless. `[1, 1, 0.34]` is a factor vector; `[1mm, 1mm, 0.34mm]` is a vector of lengths and
> is rejected with `E0202`. A unit-tagged vector used as a factor would silently scale the model by `0.001`.

```om
// @om 1
let block = box([10mm, 20mm, 5mm]).scale([2, 1, 1]);
export(block, "block.glb");
```

The result spans `x = 0..20`, `y = 0..20`, `z = 0..5`; volume `2000 mm3`; bounding box `20 x 20 x 5 mm`. A negative
or zero factor is `E0207`; use `mirror` for reflection and keep the solid orientation valid.

## mirror

Reflects geometry across the plane through the origin with the given normal. The result keeps a valid outward
winding, so volume stays positive.

| Name | Type | Unit | Default | Constraints | Description |
|---|---|---|---|---|---|
| `normal` | `Vec3` | mm | required | non-zero length | normal of the mirror plane |
| `child` | `Sketch \| Solid` | — | required | — | geometry to mirror |

```om
// @om 1
let half = box([10mm, 10mm, 10mm]);
let mirrored = half.mirror(X).translate([0.01mm, 0mm, 0mm]);
let pair = union([half, mirrored]);
export(pair, "pair.glb");
```

`mirror(X)` maps `x` to `-x`; the reflected box spans `x = -10..0` and the 0.01 mm translation makes it overlap the
original at `x = 0` instead of only touching. The union is a `20.01 x 10 x 10 mm` solid with volume
`2000.01 mm3`. Exact face contact would be `E0312`; exact edge contact would be `E0307`.

## Composition order

Nested calls apply from the innermost call outward. This expression applies scale first, rotation second, and
translation last:

```om
let arm = translate(
    [0mm, 0mm, 10mm],
    rotate(Z, 90deg, scale([2, 2, 2], box([10mm, 2mm, 2mm])))
);

export(arm, "arm.glb");
```

Trace the corner `p = [10mm, 0mm, 0mm]`:

| Step | Operation | Point |
|---|---|---|
| 0 | original | `(10, 0, 0)` mm |
| 1 | `scale([2, 2, 2])` | `(20, 0, 0)` mm |
| 2 | `rotate(Z, 90deg)` | `(0, 20, 0)` mm |
| 3 | `translate([0, 0, 10mm])` | `(0, 20, 10)` mm |

The final bounding box is `4 x 20 x 14 mm` (`x = -4..0`, `y = 0..20`, `z = 10..14`); volume `320 mm3`.

The method form applies in reading order and produces the same result:

```om
let arm = box([10mm, 2mm, 2mm])
    .scale([2, 2, 2])
    .rotate(Z, 90deg)
    .translate([0mm, 0mm, 10mm]);
```

Read a chain as a pipeline: the box is scaled, the scaled solid is rotated, the rotated solid is translated.
Read nested calls as parentheses: the innermost call runs first. The two views are consistent; do not reverse one
of them.

## Center and origin

`box`, `cylinder`, and `cone` default to `center = false`: their local origin is a corner or the base, not the
center of mass. `sphere` and `torus` are always centered. A rotation or scale always uses the world origin, not the
center of the geometry. To rotate a part about its own center, center it at the origin first, transform it, then
translate it into place:

```om
// @om 1
let boss = cylinder(h = 10mm, d = 12mm, center = true)
    .rotate(X, 90deg)
    .translate([20mm, 0mm, 8mm]);
export(boss, "boss.glb");
```

## Complete example

```om
// @om 1
let plate = box([40mm, 20mm, 5mm], center = true);

let hole = cylinder(d = 6mm, h = 10mm, center = true);
let holes = [
    hole.translate([-12mm, 0mm, 0mm]),
    hole.translate([ 12mm, 0mm, 0mm]),
];

let tilted = difference(plate, union(holes))
    .rotate(Y, 15deg);

export(tilted, "plate.glb");
```

The holes are cut while the plate is axis-aligned, then the finished plate is tilted. Cutting after the rotation
would also work, but the hole axes would no longer be parallel to Z unless rotated with the plate.

## Errors

| Code | Condition | Fix |
|---|---|---|
| `E0201` | a `Vec2` is used on a `Solid`, or a `Vec3` on a 2D-only overload | match the dimension |
| `E0202` | a translation component lacks a unit | add `mm` |
| `E0205` | the vector mixes `mm` and `in` components | convert all components to one unit |
| `E0207` | a scale factor is zero or negative | use a positive factor or `mirror` |
| `E0207` | the rotation axis has zero length | pass `X`, `Y`, `Z`, or a non-zero vector |

## Next

- [Booleans](06-booleans.md)
- [Modifiers](08-modifiers.md)
- [OML reference](00-reference.md)
