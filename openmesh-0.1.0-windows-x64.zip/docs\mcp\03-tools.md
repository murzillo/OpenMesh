# MCP tools

This page specifies the eight MCP tools: purpose, input schema, output schema, token budget, a success example, an
error example, and timeout behavior. The error object is defined in [Error contract](04-error-contract.md).

Every tool returns a standard MCP result:

```json
{
  "content": [{ "type": "text", "text": "{...same object as structuredContent...}" }],
  "structuredContent": { "ok": true },
  "isError": false
}
```

A model-domain failure uses `isError: false` and an object with `ok: false` and `diagnostics`. An invalid argument
uses `isError: true` and a JSON-RPC error. A transport failure uses a JSON-RPC error with code `-32000`.

Output schemas that show `"$ref": "#/$defs/diagnostic"` refer to the diagnostic schema in
[Error contract](04-error-contract.md#diagnostic-schema). The server publishes each tool schema with that definition
inlined under `$defs`.

## `source` or `file`

Every tool that parses or compiles a model accepts one of two inputs:

| Parameter | Type | Meaning |
|---|---|---|
| `source` | string | Inline OML text. Relative `import` paths do not resolve against a directory. |
| `file` | string | Path relative to the project root, at most 512 characters. The file is read from disk, and `import` resolves from its directory. |

Use `file` for a model that imports other `.om` modules or that you want to keep on disk; use `source` for a generated
snippet. When both are present, `file` wins. Passing neither is an invalid argument.

## om_search_docs

Finds documentation pages before generating code. One call replaces reading the whole manual.

### Input

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["query"],
  "properties": {
    "query": { "type": "string", "minLength": 1, "maxLength": 500 },
    "limit": { "type": "integer", "minimum": 1, "maximum": 20, "default": 5 }
  }
}
```

### Output

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["results"],
  "properties": {
    "results": {
      "type": "array",
      "maxItems": 20,
      "items": {
        "type": "object",
        "additionalProperties": false,
        "required": ["path", "title", "snippet", "score"],
        "properties": {
          "path": { "type": "string" },
          "title": { "type": "string" },
          "snippet": { "type": "string", "maxLength": 320 },
          "score": { "type": "number", "minimum": 0, "maximum": 1 }
        }
      }
    }
  }
}
```

Budget: 400 tokens. Timeout: 5 s.

### Success

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "om_search_docs",
    "arguments": { "query": "fillet edges limitation", "limit": 2 }
  }
}
```

```json
{
  "results": [
    {
      "path": "docs/language/08-modifiers.md",
      "title": "Modifiers",
      "snippet": "fillet handles convex edges and skips concave and knife edges...",
      "score": 0.91
    },
    {
      "path": "docs/language/12-errors.md",
      "title": "Errors",
      "snippet": "E0309 Edge not supported by fillet...",
      "score": 0.77
    }
  ]
}
```

### Error

An empty query fails schema validation:

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/call",
  "params": { "name": "om_search_docs", "arguments": { "query": "" } }
}
```

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "error": { "code": -32602, "message": "Invalid params: query must not be empty" }
}
```

A query with no match returns `{"results": []}` and is not an error.

### Timeout

The index is in memory; a search completes in milliseconds. If the index is unavailable, the tool returns
`isError: true` with code `-32000` and `data.reason = "index_unavailable"`. Do not retry more than once.

## om_get_reference

Returns the exact signature, parameters, units, example, and error codes for one symbol. Use it instead of reading
a full page when the symbol is already known.

### Input

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["symbol"],
  "properties": {
    "symbol": { "type": "string", "minLength": 1, "maxLength": 80 }
  }
}
```

### Output

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["found", "symbol"],
  "properties": {
    "found": { "type": "boolean" },
    "symbol": { "type": "string" },
    "kind": { "type": "string", "enum": ["function", "method", "type", "directive", "constant"] },
    "signature": { "type": "string" },
    "params": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": false,
        "required": ["name", "type", "unit", "default", "constraints", "description"],
        "properties": {
          "name": { "type": "string" },
          "type": { "type": "string" },
          "unit": { "type": "string" },
          "default": { "type": ["string", "null"] },
          "constraints": { "type": "string" },
          "description": { "type": "string" }
        }
      }
    },
    "units": { "type": "string" },
    "example": { "type": "string" },
    "errors": { "type": "array", "items": { "type": "string" } },
    "doc": { "type": "string" },
    "suggestions": { "type": "array", "items": { "type": "string" } }
  }
}
```

Budget: 800 tokens. Timeout: 5 s.

### Success

```json
{ "jsonrpc": "2.0", "id": 3, "method": "tools/call",
  "params": { "name": "om_get_reference", "arguments": { "symbol": "fillet" } } }
```

```json
{
  "found": true,
  "symbol": "fillet",
  "kind": "function",
  "signature": "fillet(solid: Solid, r: Length, edges: EdgeSelector | String = \"all\", segments: Number = 4) -> Solid",
  "params": [
    {
      "name": "solid",
      "type": "Solid",
      "unit": "none",
      "default": null,
      "constraints": "closed manifold",
      "description": "input body"
    },
    {
      "name": "r",
      "type": "Length",
      "unit": "mm",
      "default": null,
      "constraints": "0 < r < half the shortest adjacent edge",
      "description": "fillet radius"
    },
    {
      "name": "edges",
      "type": "EdgeSelector | String",
      "unit": "none",
      "default": "\"all\"",
      "constraints": "matches at least one convex edge",
      "description": "edges to round"
    },
    {
      "name": "segments",
      "type": "Number",
      "unit": "count",
      "default": "4",
      "constraints": "integer 1..32",
      "description": "arc segments per edge"
    }
  ],
  "units": "mm",
  "example": "box([40mm, 40mm, 20mm], center = true).fillet(edges = \"vertical\", r = 3mm)",
  "errors": ["E0308", "E0309", "E0317"],
  "doc": "docs/language/08-modifiers.md#fillet"
}
```

### Error

```json
{ "jsonrpc": "2.0", "id": 4, "method": "tools/call",
  "params": { "name": "om_get_reference", "arguments": { "symbol": "nurbs" } } }
```

```json
{
  "found": false,
  "symbol": "nurbs",
  "suggestions": ["surface", "sweep", "revolve"]
}
```

The response is not an error; the model should use a suggestion or `om_search_docs`.

### Timeout

5 s. The reference index is loaded at startup; a timeout indicates a broken installation. Return the error to the
user; do not loop.

## om_validate

Parses and typechecks source without evaluating geometry. This is the fast first step of every generation loop.

### Input

```json
{
  "type": "object",
  "additionalProperties": false,
  "anyOf": [{ "required": ["source"] }, { "required": ["file"] }],
  "properties": {
    "source": { "type": "string", "minLength": 1, "maxLength": 1048576 },
    "file": { "type": "string", "minLength": 1, "maxLength": 512 }
  }
}
```

### Output

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["ok", "diagnostics", "stats"],
  "properties": {
    "ok": { "type": "boolean" },
    "diagnostics": {
      "type": "array",
      "maxItems": 5,
      "items": {
        "type": "object",
        "additionalProperties": false,
        "required": ["code", "severity", "message", "span", "hint", "doc"],
        "properties": {
          "code": { "type": "string" },
          "severity": { "type": "string", "enum": ["error", "warning"] },
          "message": { "type": "string" },
          "span": {
            "type": "object",
            "additionalProperties": false,
            "required": ["start", "end", "line", "col"],
            "properties": {
              "start": { "type": "integer", "minimum": 0 },
              "end": { "type": "integer", "minimum": 0 },
              "line": { "type": "integer", "minimum": 1 },
              "col": { "type": "integer", "minimum": 1 }
            }
          },
          "hint": { "type": "string" },
          "suggestion": { "type": "string" },
          "doc": { "type": "string" }
        }
      }
    },
    "stats": {
      "type": "object",
      "additionalProperties": false,
      "required": ["lines", "symbols", "parameters", "exports"],
      "properties": {
        "lines": { "type": "integer", "minimum": 0 },
        "symbols": { "type": "integer", "minimum": 0 },
        "parameters": { "type": "object", "additionalProperties": { "type": "string" } },
        "exports": {
          "type": "array",
          "items": {
            "type": "object",
            "additionalProperties": false,
            "required": ["path", "format"],
            "properties": { "path": { "type": "string" }, "format": { "type": "string" } }
          }
        }
      }
    }
  }
}
```

Budget: diagnostics 300 tokens each, maximum 5. Timeout: 10 s.

### Success

```json
{ "jsonrpc": "2.0", "id": 5, "method": "tools/call",
  "params": { "name": "om_validate", "arguments": {
    "source": "// @om 1\n@param w = 40mm { min = 10mm };\nexport(box([w, 10mm, 5mm]), \"part.glb\");\n"
  } } }
```

```json
{
  "ok": true,
  "diagnostics": [],
  "stats": {
    "lines": 3,
    "symbols": 2,
    "parameters": { "w": "40mm" },
    "exports": [{ "path": "part.glb", "format": "glb" }]
  }
}
```

### Error

```json
{ "jsonrpc": "2.0", "id": 6, "method": "tools/call",
  "params": { "name": "om_validate", "arguments": {
    "source": "let x = 10;\nexport(box([x, 10mm, 5mm]), \"part.glb\");\n"
  } } }
```

```json
{
  "ok": false,
  "diagnostics": [
    {
      "code": "E0202",
      "severity": "error",
      "message": "expected Length, got Number",
      "span": { "start": 34, "end": 36, "line": 2, "col": 11 },
      "hint": "Add a unit to the value, for example 10mm.",
      "suggestion": "let x = 10mm;",
      "doc": "docs/language/12-errors.md#e0202"
    }
  ],
  "stats": { "lines": 2, "symbols": 1, "parameters": {}, "exports": [] }
}
```

### Timeout

10 s. Validation is linear in source size and does not evaluate geometry; a timeout means the source exceeded the
input limit or the server is unhealthy. Return `E0901`.

## om_compile

Compiles geometry, validates every exported solid, and optionally writes one artifact. This is the main tool of the
generation loop.

### Input

```json
{
  "type": "object",
  "additionalProperties": false,
  "anyOf": [{ "required": ["source"] }, { "required": ["file"] }],
  "properties": {
    "source": { "type": "string", "minLength": 1, "maxLength": 1048576 },
    "file": { "type": "string", "minLength": 1, "maxLength": 512 },
    "format": { "type": "string", "enum": ["glb", "obj", "stl", "3mf", "svg", "dxf"] }
  }
}
```

### Output

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["ok", "diagnostics", "stats"],
  "properties": {
    "ok": { "type": "boolean" },
    "diagnostics": { "type": "array", "maxItems": 5, "items": { "$ref": "#/$defs/diagnostic" } },
    "stats": {
      "type": "object",
      "additionalProperties": false,
      "required": ["triangles", "vertices", "bbox", "volume", "area", "watertight", "components"],
      "properties": {
        "triangles": { "type": "integer", "minimum": 0 },
        "vertices": { "type": "integer", "minimum": 0 },
        "bbox": {
          "type": "object",
          "additionalProperties": false,
          "required": ["min", "max"],
          "properties": {
            "min": { "type": "array", "items": { "type": "number" }, "minItems": 3, "maxItems": 3 },
            "max": { "type": "array", "items": { "type": "number" }, "minItems": 3, "maxItems": 3 }
          }
        },
        "volume": { "type": "number", "minimum": 0 },
        "area": { "type": "number", "minimum": 0 },
        "watertight": { "type": "boolean" },
        "components": { "type": "integer", "minimum": 0 },
        "degenerate_triangles": { "type": "integer", "minimum": 0 }
      }
    },
    "artifact": {
      "type": "object",
      "additionalProperties": false,
      "required": ["path", "bytes", "format", "sha256"],
      "properties": {
        "path": { "type": "string" },
        "bytes": { "type": "integer", "minimum": 0 },
        "format": { "type": "string" },
        "sha256": { "type": "string" }
      }
    }
  }
}
```

Budget: errors 300 tokens each, maximum 5; success under 300. Timeout: 30 s.

Artifacts are never returned as base64. With `format`, the file is written to
`<root>/.openmesh-out/compile-<sha8>.<format>` and `artifact.path` is relative to the root. Without `format`, the
tool returns stats and writes nothing. Source-level `export` paths are validated but are not written by
`om_compile`.

### Success

```json
{ "jsonrpc": "2.0", "id": 7, "method": "tools/call",
  "params": { "name": "om_compile", "arguments": {
    "source": "// @om 1\nlet p = box([40mm, 20mm, 5mm], center = true);\nexport(p, \"plate.glb\");\n",
    "format": "glb"
  } } }
```

```json
{
  "ok": true,
  "diagnostics": [],
  "stats": {
    "triangles": 12,
    "vertices": 8,
    "bbox": { "min": [-20, -10, -2.5], "max": [20, 10, 2.5] },
    "volume": 4000,
    "area": 2200,
    "watertight": true,
    "components": 1,
    "degenerate_triangles": 0
  },
  "artifact": {
    "path": ".openmesh-out/compile-4f0c2a91.glb",
    "bytes": 11204,
    "format": "glb",
    "sha256": "4f0c2a91..."
  }
}
```

### Error

A cutter that touches a face exactly:

```json
{
  "ok": false,
  "diagnostics": [
    {
      "code": "E0307",
      "severity": "error",
      "message": "difference() produced a non-manifold result",
      "span": { "start": 142, "end": 168, "line": 7, "col": 5 },
      "hint": "The cutter is flush with a face or touches only at an edge. Overlap it by at least 0.01mm.",
      "suggestion": "cylinder(d = 10mm, h = 2.02mm).translate([0mm, 0mm, -0.01mm])",
      "doc": "docs/language/12-errors.md#e0307"
    }
  ],
  "stats": {
    "triangles": 0,
    "vertices": 0,
    "bbox": { "min": [0, 0, 0], "max": [0, 0, 0] },
    "volume": 0,
    "area": 0,
    "watertight": false,
    "components": 0
  }
}
```

### Timeout

30 s hard limit. The compiler applies `--time-limit` (10 s by default) and returns `E0901` before the transport
timeout. If the client abandons the call, the server cancels evaluation and writes no artifact.

## om_preview

Renders a contact sheet with the CPU rasterizer. This is the only tool that returns base64.

### Input

```json
{
  "type": "object",
  "additionalProperties": false,
  "anyOf": [{ "required": ["source"] }, { "required": ["file"] }],
  "properties": {
    "source": { "type": "string", "minLength": 1, "maxLength": 1048576 },
    "file": { "type": "string", "minLength": 1, "maxLength": 512 },
    "views": {
      "type": "array",
      "items": { "type": "string", "enum": ["iso", "front", "top", "right"] },
      "minItems": 1,
      "maxItems": 4,
      "uniqueItems": true,
      "default": ["iso", "front", "top", "right"]
    },
    "mode": {
      "type": "string",
      "enum": ["shaded", "wire", "section", "thickness"],
      "default": "shaded"
    },
    "size": { "type": "integer", "minimum": 256, "maximum": 2048, "default": 1024 }
  }
}
```

The default is a 2 x 2 contact sheet: isometric, front, top, and right. A single view uses a 1 x 1 layout; two views
use 1 x 2. `size` is the long edge of the sheet. `section` cuts through the bounding-box center perpendicular to each
view. `thickness` colors the wall thickness and adds a numeric legend.

### Output

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["ok"],
  "properties": {
    "ok": { "type": "boolean" },
    "image": {
      "type": "object",
      "additionalProperties": false,
      "required": ["mime", "data"],
      "properties": {
        "mime": { "type": "string", "enum": ["image/png"] },
        "data": { "type": "string" }
      }
    },
    "views": {
      "type": "array",
      "items": { "type": "string", "enum": ["iso", "front", "top", "right"] }
    },
    "mode": { "type": "string", "enum": ["shaded", "wire", "section", "thickness"] },
    "size": { "type": "integer", "minimum": 256, "maximum": 2048 },
    "layout": { "type": "string", "enum": ["1x1", "1x2", "2x2"] },
    "stats": { "type": "object" },
    "diagnostics": { "type": "array", "maxItems": 5, "items": { "$ref": "#/$defs/diagnostic" } }
  }
}
```

Budget: image bytes are not counted as text; the text fields stay under 300 tokens. Timeout: 30 s.

### Success

```json
{ "jsonrpc": "2.0", "id": 8, "method": "tools/call",
  "params": { "name": "om_preview", "arguments": {
    "source": "export(box([40mm, 20mm, 10mm], center = true), \"p.glb\");",
    "views": ["iso", "front", "top", "right"],
    "mode": "shaded", "size": 1024
  } } }
```

```json
{
  "ok": true,
  "image": { "mime": "image/png", "data": "iVBORw0KGgoAAAANSUhEUg..." },
  "views": ["iso", "front", "top", "right"],
  "mode": "shaded",
  "size": 1024,
  "layout": "2x2",
  "stats": { "triangles": 12, "watertight": true }
}
```

The base64 string is truncated here; a 1024 px contact sheet is roughly 120-300 KiB. The image contains a scale bar
and labeled dimensions.

### Error

A compile error returns no image:

```json
{
  "ok": false,
  "diagnostics": [
    {
      "code": "E0304",
      "severity": "error",
      "message": "open sketch",
      "span": { "start": 0, "end": 20, "line": 1, "col": 1 },
      "hint": "Set closed = true or use polygon.",
      "doc": "docs/language/12-errors.md#e0304"
    }
  ],
  "stats": { "triangles": 0, "watertight": false }
}
```

### Timeout

30 s. Rendering is CPU-only. A timeout usually means the mesh exceeded the triangle limit; lower `size` or reduce the
model. No partial image is returned.

## om_export

Writes one artifact to an explicit path inside the project root.

### Input

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["format", "path"],
  "anyOf": [{ "required": ["source"] }, { "required": ["file"] }],
  "properties": {
    "source": { "type": "string", "minLength": 1, "maxLength": 1048576 },
    "file": { "type": "string", "minLength": 1, "maxLength": 512 },
    "format": { "type": "string", "enum": ["glb", "obj", "stl", "3mf", "svg", "dxf"] },
    "path": { "type": "string", "minLength": 1, "maxLength": 512 }
  }
}
```

### Output

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["path", "bytes", "sha256", "stats"],
  "properties": {
    "path": { "type": "string" },
    "bytes": { "type": "integer", "minimum": 0 },
    "sha256": { "type": "string" },
    "stats": { "type": "object" },
    "diagnostics": { "type": "array", "maxItems": 5, "items": { "$ref": "#/$defs/diagnostic" } }
  }
}
```

Budget: 300 tokens. Timeout: 60 s.

The extension of `path` must match `format`; a mismatch is invalid params. The path is relative to the root or
absolute inside the root. Existing files are replaced atomically. In `--read-only` mode the tool returns
`isError: true` with `data.reason = "read_only"`.

### Success

```json
{ "jsonrpc": "2.0", "id": 9, "method": "tools/call",
  "params": { "name": "om_export", "arguments": {
    "source": "export(box([30mm, 18mm, 12mm], center = true), \"clip.glb\");",
    "format": "glb", "path": "out/clip.glb"
  } } }
```

```json
{
  "path": "out/clip.glb",
  "bytes": 11204,
  "sha256": "b31d...",
  "stats": { "triangles": 12, "watertight": true, "volume": 6480 }
}
```

### Error

A path outside the root:

```json
{
  "path": "../clip.glb",
  "bytes": 0,
  "sha256": "",
  "stats": {},
  "diagnostics": [
    { "code": "E0407", "severity": "error", "message": "path outside project root",
      "span": { "start": 0, "end": 0, "line": 1, "col": 1 },
      "hint": "Use a relative path inside --root.", "doc": "docs/language/12-errors.md#e0407" }
  ]
}
```

### Timeout

60 s. The writer is fast; a timeout means the compile stage exceeded its budget. Check `diagnostics`; if the
client aborted, the previous file is intact.

## om_query_geometry

Returns numeric geometry facts without writing a file. Use it to answer "did I get the size I asked for?".

### Input

```json
{
  "type": "object",
  "additionalProperties": false,
  "anyOf": [{ "required": ["source"] }, { "required": ["file"] }],
  "properties": {
    "source": { "type": "string", "minLength": 1, "maxLength": 1048576 },
    "file": { "type": "string", "minLength": 1, "maxLength": 512 }
  }
}
```

### Output

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["ok", "exports", "totals", "diagnostics"],
  "properties": {
    "ok": { "type": "boolean" },
    "exports": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": false,
        "required": ["path", "format", "bbox", "volume", "area", "triangles", "vertices", "components", "watertight", "degeneracies"],
        "properties": {
          "path": { "type": "string" },
          "format": { "type": "string" },
          "bbox": { "type": "object" },
          "volume": { "type": "number" },
          "area": { "type": "number" },
          "triangles": { "type": "integer" },
          "vertices": { "type": "integer" },
          "components": { "type": "integer" },
          "watertight": { "type": "boolean" },
          "degeneracies": { "type": "object" }
        }
      }
    },
    "totals": {
      "type": "object",
      "description": "All exports evaluated as one scene; a solid written to three formats is counted three times.",
      "properties": {
        "bbox": { "type": "object" },
        "volume": { "type": "number" },
        "area": { "type": "number" },
        "triangles": { "type": "integer" },
        "vertices": { "type": "integer" },
        "components": { "type": "integer" },
        "watertight": { "type": "boolean" },
        "degeneracies": { "type": "object" }
      }
    },
    "diagnostics": { "type": "array", "maxItems": 5, "items": { "$ref": "#/$defs/diagnostic" } }
  }
}
```

Read `exports` when a model writes more than one file: each entry is the geometry of that export. `totals` is the
scene, not a material volume — exporting the same part to GLB, STL, and 3MF counts it three times and sets
`components` to 3.

Budget: 400 tokens. Timeout: 20 s.

### Success

```json
{ "jsonrpc": "2.0", "id": 10, "method": "tools/call",
  "params": { "name": "om_query_geometry", "arguments": {
    "source": "export(box([60mm, 40mm, 5mm], center = true), \"p.glb\");"
  } } }
```

```json
{
  "ok": true,
  "bbox": { "min": [-30, -20, -2.5], "max": [30, 20, 2.5] },
  "volume": 12000,
  "area": 5800,
  "triangles": 12,
  "vertices": 8,
  "components": 1,
  "watertight": true,
  "degeneracies": {
    "degenerate_triangles": 0,
    "duplicate_vertices": 0,
    "open_edges": 0,
    "non_manifold_edges": 0
  }
}
```

### Error

```json
{
  "ok": false,
  "bbox": { "min": [0, 0, 0], "max": [0, 0, 0] },
  "volume": 0,
  "area": 0,
  "triangles": 0,
  "vertices": 0,
  "components": 0,
  "watertight": false,
  "degeneracies": {
    "degenerate_triangles": 0,
    "duplicate_vertices": 0,
    "open_edges": 0,
    "non_manifold_edges": 0
  },
  "diagnostics": [
    {
      "code": "E0409",
      "severity": "error",
      "message": "no export",
      "span": { "start": 0, "end": 0, "line": 1, "col": 1 },
      "hint": "Add export(value, \"file.glb\") at top level.",
      "doc": "docs/language/12-errors.md#e0409"
    }
  ]
}
```

### Timeout

20 s. The tool evaluates geometry but does not rasterize or write. Lower the triangle limit or the model density.

## om_get_examples

Returns canonical snippets by tag. Use it when the model needs a known-good starting point instead of generating
syntax from memory.

### Input

```json
{
  "type": "object",
  "additionalProperties": false,
  "properties": {
    "tag": { "type": "string", "maxLength": 40 }
  }
}
```

### Output

```json
{
  "type": "object",
  "additionalProperties": false,
  "required": ["examples"],
  "properties": {
    "examples": {
      "type": "array",
      "maxItems": 20,
      "items": {
        "type": "object",
        "additionalProperties": false,
        "required": ["title", "source", "tags"],
        "properties": {
          "title": { "type": "string" },
          "source": { "type": "string" },
          "tags": { "type": "array", "items": { "type": "string" } }
        }
      }
    }
  }
}
```

Budget: 2000 tokens. Timeout: 5 s.

### Success

```json
{ "jsonrpc": "2.0", "id": 11, "method": "tools/call",
  "params": { "name": "om_get_examples", "arguments": { "tag": "bracket" } } }
```

```json
{
  "examples": [
    {
      "title": "L-bracket plate",
      "source": "// @om 1\nexport(box([60mm, 30mm, 6mm]), \"bracket.glb\");",
      "tags": ["bracket", "holes", "fdm"]
    }
  ]
}
```

### Error

An unknown tag returns an empty list, not an error:

```json
{ "examples": [] }
```

### Timeout

5 s. The examples are compiled into the binary; a timeout indicates an installation problem.

## Next

- [Error contract](04-error-contract.md)
- [MCP recipes](05-recipes.md)
- [Limits](../language/13-limits.md)
