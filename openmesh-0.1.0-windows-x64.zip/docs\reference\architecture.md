# Architecture

This page describes the compiler pipeline, the data it passes between stages, and the decisions that make the
output deterministic. Read it when debugging a diagnostic, extending a writer, or embedding the compiler in another
tool.

## Pipeline

```text
root .om
   |
   v
source loader ---> import graph ---> source hash
   |
   v
lexer ---> tokens with spans
   |
   v
parser ---> AST
   |
   v
typechecker ---> typed AST + diagnostics + parameter schema
   |
   v
evaluator ---> geometry values (Sketch, Solid, Color, List)
   |
   v
validator ---> watertight, components, degeneracies, stats
   |                    |
   v                    v
writers ---> GLB / OBJ+MTL / STL / 3MF / SVG / DXF
                        |
                        v
                  renderer ---> contact sheet PNG
```

`check` stops after the typechecker. `params` stops after the parameter schema. `preview` and `render` stop after the
validator and rasterize. `build` and `om_export` run every stage.

## Source loader

The loader resolves the root file and every `import`:

- Paths are relative to the importing file, normalized, and checked against the project root.
- A path that escapes the root, a symlink that resolves outside it, or a missing `.om` file is `E0404` or `E0407`.
- The import graph is acyclic (`E0405`) and at most 16 levels deep (`E0905`).
- The combined source size is limited to 16 MiB (`E0906`) and hashed with BLAKE3 for the cache key.
- A module's top-level `export` calls are parsed but ignored when the module is imported. Only the root file's
  exports produce artifacts.

The loader records the bytes of every file so a diagnostic can point to the original line and column.

## Lexer

The lexer emits tokens with a byte span, a line, and a column. It recognizes:

- identifiers and keywords;
- numbers, length literals, and angle literals, with the unit suffix attached to the token;
- strings with the five escapes;
- comments, discarded from the token stream but retained for formatting;
- punctuation and operators, including `..`, `=>`, and `@`.

A malformed literal produces `E0101`, `E0102`, `E0103`, `E0106`, `E0107`, or `E0109` at the token span. The lexer
does not attempt error recovery inside a malformed literal; it skips to the next whitespace and continues.

## Parser

The parser is a hand-written recursive-descent parser with precedence climbing for binary operators. It produces an
AST with:

| Node | Fields |
|---|---|
| `Program` | declarations, exports |
| `ParamDecl` | name, type, default, metadata |
| `PresetDecl` | name, entries |
| `LetDecl` | name, optional type, initializer |
| `FnDecl` | name, parameters, return type, body |
| `ImportDecl` | path, alias |
| `ExportCall` | value, path |
| `IfExpr` | condition, then block, else block |
| `ForExpr` | binding, iterable, body |
| `RangeExpr` | start, end |
| `CallExpr` | callee, arguments |
| `MemberExpr` | receiver, name |
| `ClosureExpr` | parameter, body |

The parser accepts optional semicolons and trailing commas. It reports the first syntax error in a statement and
recovers at the next newline or `;`, so a file with several syntax errors reports up to five of them.

## Typechecker

The typechecker walks the AST once and builds a symbol table per scope. It enforces:

- declared types for function parameters and return values;
- unit tags for `Length` and `Angle`, with no implicit conversion (`E0205`);
- immutability of `let`, `@param`, and function parameters (`E0403`);
- one definition per name per scope (`E0402`);
- order-independent top-level names with cycle detection (`E0411`);
- subtype rules: `Sketch` is not `Solid`, `Vec2` is not `Vec3`, `Number` is not `Length`;
- method resolution: a method call is rewritten to the free function with the receiver as the first argument;
- selector types: `edges` and `faces` are valid only for `Solid`, and `where` accepts a preset or a closure with the
  right element type;
- parameter metadata: keys, types, ranges, and defaults (`E0410`);
- export rules: top level only (`E0414`), supported extension (`E0412`), unique path (`E0413`);
- at least one export (`E0409`).

The typed AST stores the resolved symbol for every identifier, so the evaluator does not perform name lookup by
string.

## Evaluator

The evaluator is a tree-walking interpreter over the typed AST. Values are immutable:

| Value | Representation |
|---|---|
| `Number` | float64 |
| `Length` | float64 metres plus a compile-time unit tag |
| `Angle` | float64 radians plus a compile-time unit tag |
| `Vec2`, `Vec3` | arrays of lengths |
| `Bool`, `String` | native values |
| `Sketch` | contour loops in metres, plus an open/closed flag |
| `Solid` | mesh handle plus a color |
| `List` | array of values |
| `Color` | three 8-bit channels |
| `EdgeSelector`, `FaceSelector` | filtered index sets over a solid |

Top-level declarations are evaluated in dependency order after cycle detection. A function body is evaluated when
called; it captures an environment of immutable bindings. `for` evaluates its body per element and collects the
results into a list. `if` evaluates one branch. There is no global mutable state.

The evaluator applies transforms and modifiers by constructing a new mesh. A method call is the same as
the free call; `box(...).translate(v)` rewrites to `translate(v, box(...))`.

## Geometry core

All solid operations go through one CSG core: a BSP tree with polygon splitting and T-junction repair. It is
self-contained and deterministic.

- Primitives are generated as triangle meshes with consistent outward winding.
- `union`, `difference`, and `intersection` split both operands against each other's planes and keep the selected cells.
- `hull` uses the convex hull; `minkowski` is exact for convex operands and is bounded by the triangle limit.
- `extrude`, `revolve`, and `sweep` generate a mesh from the sketch and validate it before it becomes a `Solid`.
- `fillet`, `chamfer`, and `shell` are mesh operations with explicit preconditions; they validate the result before
  returning a `Solid`.

Lengths are converted to metres before a CSG call. The DSL and reports use millimetres; the writer converts to
the format's unit.

## Validator

Before any `Solid` reaches a writer, the validator checks:

| Check | Diagnostic |
|---|---|
| every edge has exactly two incident faces | `E0302` |
| no self-intersection | `E0302` or `E0303` |
| consistent outward winding | `E0302` |
| no degenerate triangles | `E0305` |
| non-zero volume | `E0306` |
| watertight boundary | `E0311` |
| component count | reported, not an error by itself |

The validator also computes the statistics returned by the CLI and MCP:

```json
{
  "triangles": 200,
  "vertices": 102,
  "bbox": { "min": [-15, -9, 0], "max": [15, 9, 12] },
  "volume": 5575.22,
  "area": 2583.86,
  "watertight": true,
  "components": 1,
  "degenerate_triangles": 0
}
```

Area and volume are computed from the triangles, not from the source parameters, so a failed or approximate mesh
reports the real numbers.

## Preview and render

The renderer is a separate consumer of the validated scene, not a writer. It receives the exported values, the
camera presets, and the display mode, and returns a PNG.

- The scene is the same set of validated meshes that the writers receive; a render never evaluates source text.
- The default contact sheet is a 2 x 2 grid: isometric, front, top, and right, with a 10% framing margin, a scale
  bar, and labeled dimensions.
- `section` cuts through the bounding-box center perpendicular to each view; `thickness` samples the distance to the
  nearest opposite surface and adds a numeric legend.
- The rasterizer is CPU-only. On Linux it uses llvmpipe or OSMesa; on Windows it uses the bundled software backend.
  Hardware acceleration is optional and never required.
- The viewport uses the same rasterizer. A failed compile keeps the last good mesh; the viewport shows the last
  valid scene until the next successful build.
- PNG determinism comes from a fixed camera, a fixed sampling pattern, a fixed palette and legend, fixed PNG
  compression, and no timestamps. `--renderer auto` may change bytes across GPUs.

## Writers

Each writer receives the validated meshes, the export path, and the color table. The writers are deterministic:

- **GLB**: fixed JSON key order, no timestamps, one buffer, one material per color, Y-up conversion on write.
- **OBJ**: fixed vertex order, no date comments, a sidecar MTL with `Kd` colors.
- **STL**: binary, zero-filled header, millimetres, one merged mesh.
- **3MF**: fixed ZIP entry order and timestamps, millimetres, one object per solid.
- **SVG**: fixed number formatting, Y flip, `fill-rule="evenodd"`.
- **DXF**: fixed header, R12 entities, `$INSUNITS 4`.

The writer writes to a temporary file in the target directory, flushes it, and renames it over the target. A failed
write leaves the previous file intact.

## Cache

The cache key is:

```text
BLAKE3(
  root source bytes,
  imported source bytes in path order,
  resolved parameters,
  compiler version,
  format and writer version
)
```

A hit returns the stored bytes and stats. A miss compiles and stores. Failures are never cached. The cache is
content-addressed and safe to delete; `--no-cache` bypasses it.

## Diagnostics

Every token, AST node, and geometry value carries a span. The diagnostic registry maps an error condition to a code,
a message template, a hint, and a documentation anchor. The span is attached at the point where the condition is
detected:

| Stage | Span |
|---|---|
| lexer | the malformed token |
| parser | the unexpected token or the unclosed delimiter |
| typechecker | the expression with the wrong type or unit |
| evaluator | the call that produced invalid geometry |
| validator | the exported value or the whole file for a limit |

The registry guarantees that every diagnostic has a non-empty `hint` and a `doc` anchor that exists in the bundled
documentation. The error contract is in [MCP error contract](../mcp/04-error-contract.md).

## MCP server

The server wraps the same compiler and validator:

- `om_search_docs` queries an in-memory index of the bundled Markdown.
- `om_get_reference` reads the symbol index built from the docs.
- `om_validate`, `om_compile`, `om_preview`, `om_query_geometry` call the pipeline in-process.
- `om_export` writes inside the project root.
- `--read-only` blocks writers.
- Limits are applied per call; the transport timeout is larger than the server limit so the server can return
  `E0901` first.

The server does not call the network and does not start a GUI. A headless Linux host runs the same binary as a
desktop.

## Security

| Layer | Protection |
|---|---|
| Language | no I/O, network, clock, environment, or reflection |
| Import | `.om` files inside the root only, acyclic, depth-limited |
| Export | paths inside the root only, extension allowlist |
| Resources | CPU, memory, triangles, recursion, import depth, source size |
| MCP | `--read-only`, localhost default, no authentication in HTTP mode |
| Output | atomic writes, no partial artifact |

The compiler is not an OS sandbox. A model can still allocate the configured budget and write artifacts inside the
root. Run the server with `--read-only` when the client does not need to write.

## File layout

```text
openmesh
docs/
  start/
  language/
  cli/
  mcp/
  ai/
  recipes/
  reference/
  llms.txt
LICENSE
README.md
```

The compiler does not read `docs/`; the viewer and the MCP index do. A build with the docs directory removed still
compiles, but `om_search_docs` and `om_get_reference` return an empty result.

## Next

- [Formal grammar](grammar.ebnf)
- [Changelog](changelog.md)
- [Error contract](../mcp/04-error-contract.md)
