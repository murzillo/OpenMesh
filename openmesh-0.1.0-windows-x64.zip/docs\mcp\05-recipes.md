# MCP recipes

This page contains seven end-to-end scenarios: a user prompt, the tool calls, the expected result, and the stop
condition. Each scenario uses the eight tools from [Tools](03-tools.md) and the error contract from
[Error contract](04-error-contract.md).

## 1. Bracket from a text request

**Prompt:** "Make a 60 x 30 x 40 mm L-bracket, 6 mm thick, with two 4.5 mm holes in the base and one in the wall.
Plain PLA, export GLB."

**Calls:**

1. `om_search_docs("bracket holes union difference")` -> modifiers, booleans.
2. `om_get_reference("difference")` -> two operands, list required for multiple cutters.
3. `om_validate(source)` -> ok.
4. `om_compile(source, null)` -> bbox `60 x 30 x 40`, volume `22753.72`, watertight true.
5. `om_export(source, "glb", "bracket.glb")`.

**Source:** the bracket recipe in [Printable bracket](../recipes/printable-bracket.md).

**Stop if:** `components > 1` (the wall and base are not unioned) or `watertight` is false.

## 2. Failing model repair

**Prompt:** "Fix this model; it fails with E0307."

```om
// @om 1
let plate = box([40mm, 20mm, 5mm], center = true);
let cut = cylinder(d = 8mm, h = 5mm, center = true).translate([0mm, 0mm, 5mm]);
export(difference(plate, cut), "plate.glb");
```

**Calls:**

1. `om_validate(source)` -> `E0307` at the `difference` span, hint to overlap.
2. The cutter starts exactly at the top face (`z = 2.5`, plate top `z = 2.5`). Change it to
   `translate([0mm, 0mm, 4.99mm])` and make it `5.02mm` high.
3. `om_validate(fixed)` -> ok.
4. `om_compile(fixed, null)` -> watertight true.
5. `om_export(fixed, "glb", "plate.glb")`.

**Stop if:** the same `E0307` span appears twice. That means the overlap was not applied to the right operand.

## 3. Parametric enclosure variants

**Prompt:** "Give me three enclosure sizes: 80 x 48 x 30, 100 x 60 x 40, and 120 x 80 x 40 mm, wall 2.4 mm, with a
2 mm lid lip."

**Calls:**

1. `om_get_reference("shell")` and `om_search_docs("enclosure tolerance")`.
2. Build one source with parameters and a `@preset` per size, or compile three sources with edited defaults.
3. `om_validate` each -> ok.
4. `om_compile` each without a format -> record bbox and volume.
5. `om_export` each with a distinct path.

**Result:** three GLB files, each with `watertight: true` and `components: 1` per part. The wall thickness is
2.4 mm, the lid clearance is 0.3 mm per side.

**Stop if:** a preset violates `min`/`max` (`E0410`) or the lip thickness exceeds the wall (`E0308`).

## 4. Laser panel to DXF

**Prompt:** "Make a 200 x 120 mm panel with 8 mm corner radius, four M5 mounting holes, and a 6 x 3 grid of 8 mm
holes. Export DXF for a laser."

**Calls:**

1. `om_search_docs("offset rounded rectangle")`, `om_get_reference("offset")`.
2. `om_validate(source)` -> ok.
3. `om_compile(source, "dxf")` -> area, bbox, watertight (2D checks).
4. `om_preview(source, views = ["top"], mode = "shaded", size = 768)` -> visual check of hole spacing.
5. `om_export(source, "dxf", "panel.dxf")`.

**Source:** [Laser panel](../recipes/laser-panel.md).

**Stop if:** the area differs from `22945.2 mm2` by more than 1%, or a hole touches the rounded corner.

## 5. Vision-driven iteration

**Prompt:** "Make the handle thicker and move the mounting boss to the left."

**Calls:**

1. `om_preview(source, views = ["iso", "front", "top", "right"], mode = "shaded", size = 1024)` -> contact sheet.
2. The model inspects the isometric and orthographic cells and edits the parameters or the translation.
3. `om_preview(source, views = ["iso", "front", "top", "right"], mode = "shaded", size = 1024)` -> compare.
4. Repeat at most three times. If wall thickness is the question, switch to `mode = "thickness"`; if an internal
   feature is hidden, use `mode = "section"`.
5. `om_export(source, "glb", "handle.glb")`.

**Result:** the contact sheet shows the boss on the left and the handle at the requested thickness, with a scale bar
and labeled dimensions in every cell.

**Stop if:** the preview is empty (compile failed), the watertight flag is false, or the image does not change after
two edits. Ask for a dimension instead of guessing.

## 6. Logo extrusion from SVG points

**Prompt:** "Extrude this hexagonal logo ring to 6 mm and bevel the top edge by 0.8 mm."

**Calls:**

1. `om_search_docs("polygon holes extrude chamfer")`.
2. The client converts the SVG path to points; OpenMesh does not read SVG. The source uses
   `polygon(points, holes = [...])`.
3. `om_validate(source)` -> ok.
4. `om_compile(source, null)` -> bbox and volume.
5. `om_preview(source, views = ["iso"], mode = "shaded", size = 768)` -> check the ring and the bevel.
6. `om_export(source, "stl", "logo.stl")`.

**Source:** [Logo extrusion](../recipes/logo-extrusion.md).

**Stop if:** the hole boundary touches the outer boundary (`E0303`) or the bevel consumes the ring (`E0308`).

## 7. Existing model audit

**Prompt:** "Here is my model. Is it printable and what size is it?"

The user pastes the source; the agent has no filesystem read tool.

**Calls:**

1. `om_validate(source)` -> list diagnostics.
2. `om_compile(source, null)` -> stats.
3. `om_query_geometry(source)` -> bbox, volume, components, degeneracies.
4. `om_preview(source, views = ["front", "top"], mode = "shaded", size = 768)` -> optional visual check.
5. Report: dimensions, volume, watertight, components, and the first three diagnostics with hints.

**Stop if:** the source is larger than the tool input limit; ask the user to split it or paste the failing section.

## 8. Triangle limit recovery

**Prompt:** "The build fails with E0903; make it fit 300,000 triangles without changing the outer dimensions."

**Calls:**

1. `om_query_geometry(source)` -> actual triangle count, e.g. `412880`.
2. Lower `segments` on cylinders and spheres, lower fillet `segments` from 4 to 2, and replace `minkowski` with
   `fillet` where the shape allows.
3. `om_compile(source, null)` -> check the count and that the bbox is unchanged.
4. `om_preview(source, views = ["iso", "front"], mode = "shaded", size = 768)` -> confirm the visible quality.
5. `om_export(source, "stl", "part.stl")` if watertight.

**Stop if:** the count is still above the limit after two reductions, or the bbox changed. Ask whether the limit or
the dimensions may change.

## Next

- [Tools](03-tools.md)
- [Error contract](04-error-contract.md)
- [Prompting guide](../ai/01-prompting-guide.md)
