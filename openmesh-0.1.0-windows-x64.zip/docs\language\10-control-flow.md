# Control flow

This page specifies `if`, `for`, ranges, and list handling. It also states why OML has no `while` and no
`break`/`continue`, and what to use instead.

## if

`if` is an expression. Both branches are required and must have the same type.

```om
// @om 1
@param wall = 2mm { min = 1mm, max = 5mm, step = 0.5mm, desc = "Wall thickness" };

let height = if wall > 3mm { 50mm } else { 35mm };
let body = box([40mm, 30mm, height]);

export(body, "box.glb");
```

`if` nests without `else if`:

```om
let size = if wall < 1.5mm {
    10mm
} else {
    if wall < 3mm {
        20mm
    } else {
        30mm
    }
};
```

A branch that produces a different type is `E0201`. There is no empty branch and no `Void`; when a branch should
add no geometry, use an empty list and `flatten`.

## for

`for` is an expression. It evaluates its block once per element and returns a `List` of the block values.

```om
// @om 1
let angles = for i in 0..6 { i * 60deg };
let points = for a in angles { [30mm * cos(a), 30mm * sin(a), 0mm] };
let pins = for p in points {
    cylinder(d = 4mm, h = 10mm).translate(p)
};

export(union(pins), "ring.glb");
```

`0..6` yields `[0, 1, 2, 3, 4, 5]`. The upper bound is excluded. A range with a start greater than or equal to the
end is an empty list, not an error.

| Form | Result | Notes |
|---|---|---|
| `0..4` | `[0, 1, 2, 3]` | step 1, end-exclusive |
| `4..0` | `[]` | empty |
| `0.5..3` | `[0.5, 1.5, 2.5]` | endpoints are numbers, not lengths |
| `for x in xs` | list of block values | `xs` is any `List<T>` |

Ranges accept numbers only. A length range such as `0mm..10mm` is `E0201`; iterate an integer range and multiply:

```om
let holes = for i in 0..5 {
    cylinder(d = 4mm, h = 8mm).translate([i * 20mm, 0mm, 0mm])
};
```

## Nested loops

A `for` inside a `for` produces a list of lists. Use `flatten` before `union`, because `union` accepts a flat list.
Each nested loop adds one level: `flatten(x)` removes one, `flatten(x, 2)` two, and `flatten(x, 0)` every level.

```om
// @om 1
let pattern = for i in 0..5 {
    for j in 0..3 {
        cylinder(d = 6mm, h = 8mm, center = true).translate([i * 20mm, j * 20mm, 0mm])
    }
};

let cutters = flatten(pattern);
let plate = box([110mm, 70mm, 8mm], center = true);
let holes = union(cutters).translate([-40mm, -20mm, 0mm]);

export(difference(plate, holes), "perforated.glb");
```

The plate is `110 x 70 x 8 mm`; the 15 holes are 6 mm in diameter and pass through. Volume
`61600 - 15 * π * 9 * 8 = 61600 - 3392.92 = 58207.08 mm3`.

## Conditional geometry

`if` inside `for` needs a list on both branches. Return a one-element list or an empty list, then flatten:

```om
// @om 1
let features = flatten(for i in 0..6 {
    if i % 2 == 0 {
        [cylinder(d = 5mm, h = 10mm).translate([i * 12mm, 0mm, 0mm])]
    } else {
        []
    }
});

export(union(features), "even-pins.glb");
```

The result contains three pins at `x = 0, 24, 48 mm`. `%` is the remainder operator; `i % 2` is `0` for even
numbers. A remainder by zero is `E0210`.

## Loop termination

OML has no `while` loop. A model must terminate for every input, and a `while` loop makes termination a property of
the data rather than of the syntax. The compiler guarantees termination through three rules:

1. Every loop iterates a finite list or a finite range.
2. Recursion is limited to 64 frames (`E0904`).
3. There is no mutation, so a loop cannot depend on state that changes outside its iteration.

Determinism is the second reason: a loop bounded by a list produces the same values in the same order on every
machine. A `while` loop with a floating-point condition does not.

There is no `break` or `continue` either. To stop early, filter the input with a conditional list or split the loop
into two ranges. To skip an element, return `[]` and flatten, as shown above.

## Lists

```om
let xs = [10mm, 20mm, 30mm];
let first = xs[0];
let last = xs[len(xs) - 1];
let grid = [[0, 1], [2, 3]];
```

Lists are immutable and homogeneous. Indexing is zero-based and out of range is `E0211`. `len` returns the element
count. `flatten` removes one nesting level. `union` consumes a flat `List<Solid>` or `List<Sketch>`; `export` accepts
a list and writes one object per element.

## Complete example

```om
// @om 1
@param count = 6 { min = 2, max = 12, step = 1, desc = "Number of holes" };
@param diameter = 8mm { min = 3mm, max = 20mm, step = 0.5mm, desc = "Hole diameter" };

let holes = for i in 0..count {
    cylinder(d = diameter, h = 12mm, center = true)
        .translate([(i - (count - 1) / 2) * 15mm, 0mm, 0mm])
};

let plate = box([count * 15mm + 15mm, 30mm, 6mm], center = true);
export(difference(plate, union(holes)), "strip.glb");
```

For `count = 6`, the plate is `105 x 30 x 6 mm` and the six 8 mm holes leave
`18900 - 6 * π * 16 * 6 = 18900 - 1809.56 = 17090.44 mm3`.

## Errors

| Code | Condition | Fix |
|---|---|---|
| `E0201` | `if` branches differ, or a range uses lengths | make branches equal; iterate numbers |
| `E0210` | `%` or `/` by zero | guard the divisor or change the range |
| `E0211` | list index out of range | use `0 .. len(list) - 1` |
| `E0904` | recursion exceeds 64 frames | add a terminating branch or reduce the depth |

## Next

- [Parameters](11-parameters.md)
- [Variables and functions](09-variables-and-functions.md)
- [OML reference](00-reference.md)
