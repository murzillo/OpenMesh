# Syntax

This page defines how an OML file is tokenized and parsed: file structure, comments, literals, declarations, calls,
and operator precedence. Read it before writing a model by hand or generating one from a schema.

## Language rationale

Python creates false expectations: a model written in Python reaches for `import` of arbitrary packages, mutable
state, and f-strings, while the sandbox supports none of them. OpenSCAD has no types, no unit checking, and no
actionable diagnostics, which is exactly where a language model fails. Lisp-like and JavaScript-like exotics are
less familiar to models and readers. OML deliberately resembles JavaScript and Rust in form and does not resemble
them in capabilities: the syntax is predictable, the semantics are narrow, and every value is immutable.

## File structure

An OML file is UTF-8 with LF line endings and the `.om` extension. A leading UTF-8 BOM is ignored. The optional first line selects the language
version:

```om
// @om 1
```

`// @om 1` accepts any 1.x compiler. `// @om 1.0` accepts 1.0 and later 1.x compilers but pins the minor line for
tooling. A different major version produces warning `W0101` and compilation continues. A different minor version
produces no warning. Without a header, the current compiler version applies.

A file contains top-level declarations and top-level `export` calls. Top-level declarations are order-independent:
a function may call a function declared below it, and a `let` may refer to a later `let` as long as the reference
graph has no cycle (`E0411`). A model with no `export` is `E0409` and writes nothing.

```om
// @om 1
@param size = 40mm { min = 10mm, max = 100mm, step = 1mm, desc = "Cube edge" };

fn block(edge: Length) -> Solid {
    box([edge, edge, edge], center = true)
}

export(block(size), "cube.glb");
```

## Comments

```om
// A line comment ends at the newline.
let a = 10mm; // A comment may follow a statement.

/* A block comment may span
   several lines. Block comments do not nest. */
let b = 20mm;
```

An unterminated block comment is `E0103`; an unterminated string is `E0102`.

## Identifiers

An identifier starts with an ASCII letter or `_` and continues with letters, digits, or `_`. Identifiers are
case-sensitive. A leading `_` marks a module symbol as private (`E0406`). Keywords are reserved: `let`, `fn`,
`import`, `as`, `if`, `else`, `for`, `in`, `return`, `true`, `false`, `export`.

Built-in constants are `PI`, `X`, `Y`, `Z`, `ORIGIN`, `vertical`, `horizontal`, `top`, `bottom`, `convex`,
`concave`, and `all`. They are not keywords: a `let`, `@param`, or `fn` with the same name shadows the constant in the
scope where it is declared.

```om
let top = 5mm;                  // shadows the `top` face preset
export(box([10mm, 10mm, top]), "plate.glb");
```

## Literals

| Literal | Form | Example |
|---|---|---|
| Number | digits, optional fraction, optional exponent | `0`, `42`, `3.5`, `2.5e-3` |
| Length | number immediately followed by `mm`, `cm`, `m`, or `in` | `10mm`, `2.4cm`, `0.25in` |
| Angle | number immediately followed by `deg` or `rad` | `90deg`, `0.7854rad` |
| Boolean | keyword | `true`, `false` |
| String | double quotes, escapes `\" \\ \n \t \r` | `"body"` |
| List | square brackets, comma separated, trailing comma allowed | `[1, 2, 3]` |
| Vector | list of lengths in a vector context, or `vec2` / `vec3` | `[10mm, 0mm, 5mm]` |

A unit suffix must touch the number: `10 mm` is `E0107`. A bare number is dimensionless. The literals `0` and `0.0`
are the only dimensionless values accepted where a `Length` or `Angle` is expected.

```om
let a = 10mm;
let b = 2in;
let c = to_mm(b);        // 50.8mm
let d = 90deg;
let e = [a, 20mm, 30mm];
```

String escapes are limited to `\"`, `\\`, `\n`, `\t`, and `\r`; any other escape is `E0109`. OML has no string
interpolation and no template strings.

## Declarations

### let

`let` binds an immutable value. The type is inferred; an optional annotation documents it and is checked.

```om
let wall: Length = 2mm;
let label = "body";
let points = [[0mm, 0mm], [40mm, 0mm], [40mm, 20mm]];
```

Assignment after declaration does not exist. `wall = 3mm;` is `E0403`. Shadowing an outer name inside a function,
`if`, or `for` block is allowed and produces `W0102`.

### fn

```om
fn name(a: Type, b: Type = default) -> Type {
    // statements
    result
}
```

The last expression of the body is the result. `return expr` exits early. Parameters require types; defaults are
optional. Named arguments are allowed in calls, and positional arguments must precede named ones.

```om
fn plate(w: Length, h: Length = 40mm, thickness: Length = 5mm) -> Solid {
    box([w, h, thickness], center = true)
}

let a = plate(60mm);
let b = plate(w = 60mm, thickness = 8mm);
```

Functions may be recursive (depth limit 64) and may be declared inside a block. An inner `fn` captures immutable
bindings from the enclosing scope.

### import

```om
import "./parts/fasteners.om" as fast;

let screw = fast.m3_screw(12mm);
```

The path is relative to the importing file, must end in `.om`, and must stay inside the project root (`E0407`).
Only files are importable; there are no packages, URLs, or environment lookups. Imports are acyclic (`E0405`) and
are limited to 16 levels (`E0905`).

### @param and @preset

```om
@param width = 60mm { min = 20mm, max = 200mm, step = 1mm, desc = "Outer width" };
@param style = "round" { options = ["round", "square"], desc = "Corner style" };
@preset narrow { width = 30mm; style = "square" };
```

`@param` declares an immutable, typed value whose default determines the type. `@preset` overrides defaults.
Details and validation rules are in [Parameters](11-parameters.md).

### export

```om
export(body, "body.glb");
export([body, lid], "enclosure.3mf");
```

`export` is allowed only at top level (`E0414`). It takes one geometry value or a list of values and a string path.
The extension selects the format. The path is relative to the project root and must stay inside it (`E0407`). Two
exports with the same path are `E0413`; an unsupported extension is `E0412`.

`export` does not run during evaluation. It registers a target; the writer runs after a successful compile. A failed
compile writes no artifact.

## Expressions

### Calls and named arguments

```om
box([40mm, 20mm, 10mm], center = true);
cylinder(h = 20mm, d = 10mm, segments = 64);
```

Positional arguments come first, then named arguments. A named argument must match a declared parameter (`E0209`).
Argument count mismatches are `E0208`. Trailing commas are accepted in calls, lists, and function parameter lists.

### Methods

Every geometry function whose first argument is geometry is available as a method:

```om
let a = translate([0mm, 0mm, 5mm], box([10mm, 10mm, 10mm]));
let b = box([10mm, 10mm, 10mm]).translate([0mm, 0mm, 5mm]);
```

`a` and `b` are identical. Method chains apply from left to right; nested free calls apply from the inside out.
Both forms accept named arguments:

```om
let body = difference(outer, inner)
    .fillet(edges = "vertical", r = 3mm)
    .color(rgb(210, 210, 210));
```

### Lambdas

An inline function is an expression. Two forms exist: a typed arrow and the `fn` form with a block body.

```om
let double = (x: Number) => x * 2;
let scale = fn(w: Length, k: Number) -> Length { w * k };
let long_edges = body.edges.where(e => e.length > 10mm);
```

The arrow form infers its return type. The `fn` form requires `-> Type` and checks the body against it. A bare
one-parameter arrow is a selector predicate, and `where` supplies the element type.

### Operators

| Priority | Operators | Notes |
|---|---|---|
| 1 | `()` `[]` `.` | call, index, member |
| 2 | unary `-`, `!` | |
| 3 | `*`, `/`, `%` | `%` is remainder |
| 4 | `+`, `-` | |
| 5 | `..` | range, end-exclusive |
| 6 | `<`, `<=`, `>`, `>=` | same unit tags only |
| 7 | `==`, `!=` | exact float comparison |
| 8 | `&&` | short-circuit |
| 9 | `\|\|` | short-circuit |
| 10 | `=>` | closure |

Comparisons between different unit tags are `E0205`. `&&` and `||` require `Bool` operands (`E0201`). There is no
ternary operator; use `if`.

### Control flow

```om
let height = if width > 60mm { 40mm } else { 30mm };

let holes = for i in 0..4 {
    cylinder(d = 3.4mm, h = 10mm)
        .translate([30mm * cos(90deg * i), 30mm * sin(90deg * i), 0mm])
};
```

`if` is an expression and requires both branches with the same type. `for` is an expression that returns a `List`.
`0..4` yields `[0, 1, 2, 3]`. There is no `while`, `break`, or `continue`. Full rules are in
[Control flow](10-control-flow.md).

## A complete file

```om
// @om 1
@param width = 60mm { min = 20mm, max = 120mm, step = 1mm, desc = "Plate width" };
@param depth = 40mm { min = 20mm, max = 80mm, step = 1mm, desc = "Plate depth" };

fn plate(w: Length, h: Length, t: Length = 5mm) -> Solid {
    box([w, h, t], center = true)
}

let hole = cylinder(d = 8mm, h = 10mm, center = true);
let holes = for i in 0..2 {
    hole.translate([(i * 2 - 1) * (width / 2 - 10mm), 0mm, 0mm])
};

let body = difference(plate(width, depth), union(holes))
    .color(rgb(200, 200, 200));

export(body, "plate.glb");
```

## Errors

| Code | Condition | Fix |
|---|---|---|
| `E0101` | character outside the grammar | remove it or replace it with ASCII |
| `E0102` | string reaches a newline or end of file | close the quote |
| `E0103` | block comment has no `*/` | close the comment |
| `E0104` | expression expected | complete the expression |
| `E0105` | unclosed `(`, `[`, or `{` | add the closing delimiter |
| `E0106` | malformed number such as `1.` or `1e` | use `1.0` or `1e-3` |
| `E0107` | unknown suffix or space before a unit | use `10mm`, not `10 mm` |
| `E0108` | malformed `@param` or `@preset` | add `= value` and a valid metadata block |
| `E0109` | unknown string escape | use one of `\" \\ \n \t \r` |

## Next

- [Types and units](02-types-and-units.md)
- [Formal grammar](../reference/grammar.ebnf)
- [OML reference](00-reference.md)
