# MCP overview

> **Status: 0.1.0.** The server is part of the CLI (`openmesh mcp`) in the release archive. The contract may change in
> a 0.x minor release.

This page explains what the OpenMesh MCP server is for, how it is structured, and what it requires. Read it before
configuring a client or writing an agent loop.

## Purpose

The MCP server lets an external model read the same documentation a human reads, generate OML, compile it, inspect
diagnostics and geometry, preview an image, and write artifacts. The loop closes without a human when the model can
repair its own source from the structured errors.

The server is not a code interpreter for arbitrary languages. It evaluates OML only, inside the project root, under
the limits described in [Limits](../language/13-limits.md).

## Architecture

```text
MCP client (Claude Desktop, OpenCode, custom)
        |
        | JSON-RPC over stdio or Streamable HTTP
        v
openmesh mcp --root <project>
        |
        +-- docs index over <install>/docs
        +-- OML parser and typechecker
        +-- evaluator and CSG
        +-- mesh validator and stats
        +-- CPU contact-sheet renderer
        +-- artifact writer (root sandbox)
```

The server is a single native process. It loads the documentation from the installation directory, not from the
network. It compiles in-process and never starts a GUI. A server on a headless Linux host behaves the same as one on
a desktop.

## Tools

| Tool | Purpose | Writes files |
|---|---|---|
| `om_search_docs` | find a documentation page by query | no |
| `om_get_reference` | fetch one symbol's signature, parameters, units, example, errors | no |
| `om_validate` | parse and typecheck without geometry | no |
| `om_compile` | compile, return stats, optionally write an artifact | with `format` |
| `om_preview` | render a contact sheet and return base64 | no |
| `om_export` | write a file to a path inside the root | yes |
| `om_query_geometry` | numeric check: bbox, volume, area, components, watertight | no |
| `om_get_examples` | canonical OML snippets by tag | no |

The full input and output schemas are in [Tools](03-tools.md). The error object is in
[Error contract](04-error-contract.md).

## Requirements

| Item | Requirement |
|---|---|
| Binary | the same `openmesh` binary as the CLI, version 0.1.0 or newer |
| Root | a directory containing the `.om` files and the `docs/` installation |
| Transport | stdio (default) or Streamable HTTP |
| Display | none |
| Network | none; the server does not call the network |
| Permissions | read access to the root; write access only when `om_export` is used |
| Limits | 10 s CPU, 512 MiB RAM, 2,000,000 triangles per call by default |

The root is a sandbox, not a working directory. `import` and `export` paths resolve inside it; `..` cannot escape.
A server started without `--root` uses the current directory.

## Security model

- OML has no file I/O, network, clock, environment variables, or reflection.
- `import` reads only `.om` files inside the root and only through the compiler.
- `om_export` writes only inside the root and refuses absolute paths outside it.
- `--read-only` disables `om_export` and the artifact-writing form of `om_compile`; validation, preview, and stats
  still work.
- The preview is a CPU rasterization of validated geometry; it does not evaluate model-provided shaders. The default
  contact sheet contains isometric, front, top, and right views, a scale bar, and labeled dimensions.
- The server binds to localhost by default. HTTP mode has no authentication; expose it only through an SSH tunnel or
  a reverse proxy that authenticates.

Running generated code is bounded by geometry limits, not by an operating-system sandbox. A malicious model can
still consume the configured CPU, memory, and disk for artifacts until a limit stops it.

## Context budgets

| Tool | Budget |
|---|---|
| `om_search_docs` | 400 tokens per response |
| `om_get_reference` | 800 tokens per response |
| `om_validate` / `om_compile` errors | 300 tokens per diagnostic, at most 5 diagnostics |
| `om_preview` | image bytes are not counted as text; text fields stay under 300 tokens; default 2 x 2 contact sheet |
| `om_query_geometry` | 400 tokens |
| `om_get_examples` | 2000 tokens |
| `docs/ai/00-context-pack.md` | 6000 tokens |

A response over budget is a documentation bug, not a model failure. Shorten the page or the snippet that produced
the oversized result.

## Transports

### stdio

The default. The client starts the process and exchanges newline-delimited JSON-RPC frames on stdin/stdout. Logs go
to stderr. This is the transport for Claude Desktop and OpenCode.

### Streamable HTTP

```bash
openmesh mcp --root . --http 127.0.0.1:7331
```

The endpoint is `http://127.0.0.1:7331/mcp`. The server accepts POST requests with JSON-RPC bodies and returns
JSON or an SSE stream for notifications. It has no authentication and no TLS; keep it on localhost or behind a
tunnel.

## Versioning

The server reports its protocol version during `initialize` and its compiler version in `serverInfo`. A client that
requires a newer tool schema should check `om_search_docs` for `changelog` before calling the tool. Tool names and
input fields are stable within a major version; new optional output fields may appear in a minor version.

## Next

- [Setup](02-setup.md)
- [Tools](03-tools.md)
- [Error contract](04-error-contract.md)
