# Developing OpenMesh

This repository contains the pre-alpha Rust implementation of the OpenMesh compiler described in `docs/`. The
documentation is the specification; this tree is the implementation.

## Build

```powershell
cargo build --release
.\target\release\openmesh.exe version
```

The Windows executable embeds `assets/openmesh.ico` through `build.rs`. The icon and `assets/icon.png` are also kept as
plain assets for packaging.

## Test

```powershell
cargo test
.\target\release\openmesh.exe build examples\enclosure.om --json
```

`tests/examples.rs` typechecks every example model in `examples/` and writes GLB, 3MF, STL, OBJ, SVG, and DXF artifacts
to a temporary directory.

## Layout

| Path | Contents |
|---|---|
| `src/lexer.rs`, `src/parser.rs` | OML 1.0 tokens and AST |
| `src/typecheck.rs` | types, units, scopes, parameters, export rules |
| `src/eval.rs` | tree-walking evaluator and builtin dispatch |
| `src/geometry/` | mesh core, BSP CSG, primitives, sketch booleans/offset, extrude/revolve/sweep, selectors, modifiers |
| `src/writers/` | GLB, OBJ+MTL, STL, 3MF, SVG, DXF |
| `src/render.rs` | CPU rasterizer and deterministic PNG contact sheets |
| `src/mcp.rs` | stdio and Streamable HTTP MCP server |
| `src/project.rs` | import graph, sandbox, limits, source hashing |
| `src/params.rs` | `@param`/`@preset` schema and CLI overrides |
| `src/compile.rs` | pipeline from source to validated artifacts |

## Geometry notes

- Solid operations use a BSP-based CSG engine with T-junction repair. It is deterministic and self-contained.
- 2D booleans use `i_overlay`; rounded offsets use `cavalier_contours` and a corner-rounding pass.
- `fillet` and `chamfer` are implemented as ordered plane cuts. They are deterministic but approximate a true rolling
  ball fillet with `segments` planes per edge. Convex edges are supported; concave fillets are skipped.
- `shell` builds an inset cavity and subtracts it. For a cavity that cannot be inset cleanly (for example after a
  fillet), it falls back to a box cavity so the operation still produces a printable solid.
- Very small numerical cracks are ignored by the watertight check; a mesh is treated as watertight when its boundary
  loops enclose less than 1 mm² and it has at most 32 non-manifold edges. This tolerance keeps CSG output usable while
  still rejecting open shells and uncapped sweeps.

## Known limitations

User-facing geometry limits — approximation in `fillet`, `shell`, and `minkowski`, and the watertight tolerance — are
documented in [`docs/language/13-limits.md`](docs/language/13-limits.md), which ships with the manual.

Still missing from the pre-alpha tree:

- The live viewport from `docs/start/05-preview.md`; `preview` and `render` provide the headless equivalents.
- MCP Streamable HTTP accepts JSON POST bodies; SSE notifications are not implemented.

## Viewport prototypes

Two binaries are built behind features so a plain `cargo build --release` keeps no GUI dependency:

- `openmesh-view` (`viewer`): `minifb` framebuffer plus the CPU rasterizer through `render_view_pixels`. No GPU.
- `openmesh-view-gpu` (`viewer-gpu`): `winit` + `wgpu` surface, a triangle pipeline with flat normals and a line pass
  for feature edges, orbit and zoom with the mouse. `--once out.png` renders offscreen for verification.

The watcher, 150 ms debounce, last-good scene, and status line are shared by both. The GPU camera is orthographic and
matches the CPU basis (Z-up, iso from `[1, -1, 1]`).

## Package

```powershell
.\scripts\package.ps1
```

This creates `dist/openmesh-0.1.0-windows-x64.zip` with the release binary, `docs/`, `LICENSE`, `README.md`, and
`assets/icon.png`.

The icon is generated from a square source image with `python scripts/make_icon.py path/to/icon.png` (Pillow is
required); it writes `assets/icon.png` and a multi-size `assets/openmesh.ico`, which `build.rs` embeds into the
Windows executable.
