# Common LLM failures

This page lists the fifteen errors that generated OML produces most often, with the diagnostic, the wrong pattern,
the correct pattern, and a prevention rule. Read it before evaluating a model's output.

## 1. Missing export

**Symptom:** the model compiles but writes nothing. `E0409`.

```om
// wrong
let body = box([40mm, 20mm, 10mm]);
```

```om
// right
let body = box([40mm, 20mm, 10mm]);
export(body, "body.glb");
```

**Prevention:** require at least one top-level `export(value, "file.ext")` in the prompt and in the response
checklist.

## 2. Unitless lengths

**Symptom:** `E0203` or `E0202` at a literal or a parameter.

```om
// wrong
@param width = 60 { min = 20, max = 120 };
let b = box([width, 40, 5]);
```

```om
// right
@param width = 60mm { min = 20mm, max = 120mm };
let b = box([width, 40mm, 5mm]);
```

**Prevention:** every length has a suffix; the only unitless literal accepted as a length is `0`.

## 3. Legacy syntax

**Symptom:** `E0401` on `cube`, `part`, `$fn`, or a block-style transform.

```om
// wrong
part body = cube([20, 20, 20], center = true);
translate([0, 0, 10]) { body }
```

```om
// right
let body = box([20mm, 20mm, 20mm], center = true).translate([0mm, 0mm, 10mm]);
export(body, "body.glb");
```

**Prevention:** OML has `box`, not `cube`; no `part` keyword; no `$fn`; transforms take a child and return a value.

## 4. Implicit union

**Symptom:** only one of several solids appears in the artifact. No diagnostic.

```om
// wrong: only `lid` is exported
let body = box([40mm, 40mm, 20mm]);
let lid = box([40mm, 40mm, 2mm]).translate([0mm, 0mm, 20mm]);
export(lid, "box.glb");
```

```om
// right
let body = box([40mm, 40mm, 20mm]);
let lid = box([40mm, 40mm, 2mm]).translate([0mm, 0mm, 20mm]);
export(union([body, lid]), "box.glb");
```

**Prevention:** separate expressions are never merged. Use `union([...])` or export a list when the parts must stay
separate.

## 5. union with two arguments

**Symptom:** `E0208` wrong argument count.

```om
// wrong
let s = union(a, b);
```

```om
// right
let s = union([a, b]);
```

**Prevention:** `union` takes exactly one `List`. `difference` takes exactly two solids.

## 6. difference with several cutters

**Symptom:** `E0208` or an ignored cutter.

```om
// wrong
let s = difference(plate, hole_a, hole_b);
```

```om
// right
let s = difference(plate, union([hole_a, hole_b]));
```

**Prevention:** union the cutters first; one `difference` removes one solid.

## 7. Reversed transform order

**Symptom:** the part is in the wrong place, rotated about the wrong origin, or mirrored.

```om
// wrong: rotates after the translation, so the part swings around the origin
let p = box([10mm, 2mm, 2mm]).translate([20mm, 0mm, 0mm]).rotate(Z, 90deg);
```

```om
// right: rotate first, then translate
let p = box([10mm, 2mm, 2mm]).rotate(Z, 90deg).translate([20mm, 0mm, 0mm]);
```

**Prevention:** method chains apply left to right; nested calls apply inside out. State the intended order in the
prompt.

## 8. Extruding an open sketch

**Symptom:** `E0304` open sketch.

```om
// wrong
let s = path([[0, 0], [40mm, 0], [40mm, 10mm]]).extrude(5mm);
```

```om
// right
let s = path([[0, 0], [40mm, 0], [40mm, 10mm], [0, 10mm]], closed = true).extrude(5mm);
```

**Prevention:** `extrude`, `revolve`, `offset`, and booleans require closed sketches; use `polygon` or
`closed = true`.

## 9. Fillet on the wrong edge

**Symptom:** `E0309` edge not supported, `E0308` radius too large, or `E0317` no match.

```om
// wrong: no convex edge above the filter, and r is too large for the wall
let s = box([20mm, 20mm, 20mm], center = true).fillet(r = 12mm, edges = "vertical");
```

```om
// right
let s = box([20mm, 20mm, 20mm], center = true).fillet(r = 2mm, edges = "vertical");
```

**Prevention:** fillet supports convex edges with a dihedral angle at most 90 degrees; the radius must fit the
adjacent faces. Select edges explicitly and lower `r` before raising the segment count.

## 10. Boolean contact without overlap

**Symptom:** `E0307` or `E0312`.

```om
// wrong: cutter starts exactly at the top face
let plate = box([20mm, 20mm, 2mm]);
let cut = cylinder(d = 8mm, h = 2mm).translate([0mm, 0mm, 2mm]);
let s = difference(plate, cut);
```

```om
// right
let plate = box([20mm, 20mm, 2mm]);
let cut = cylinder(d = 8mm, h = 2.02mm).translate([0mm, 0mm, 1.99mm]);
let s = difference(plate, cut);
```

**Prevention:** overlap by at least 0.01 mm; never rely on exact face, edge, or vertex contact.

## 11. Shell too thick

**Symptom:** `E0310` shell collapse.

```om
// wrong: 10 mm wall on a 20 mm box
let s = box([20mm, 20mm, 20mm], center = true).shell(thickness = 10mm, open = "top");
```

```om
// right
let s = box([20mm, 20mm, 20mm], center = true).shell(thickness = 2mm, open = "top");
```

**Prevention:** thickness below half the smallest bounding-box dimension; no narrow slots that close on themselves.

## 12. Invalid polyhedron

**Symptom:** `E0302`, `E0316`, or `E0305`.

```om
// wrong: three faces, open surface
let t = polyhedron(
    points = [[0, 0, 0], [10mm, 0, 0], [0mm, 10mm, 0], [0mm, 0mm, 10mm]],
    faces = [[0, 2, 1], [0, 1, 3], [0, 3, 2]],
);
```

```om
// right: four faces, closed, counter-clockwise from outside
let t = polyhedron(
    points = [[0, 0, 0], [10mm, 0, 0], [0mm, 10mm, 0], [0mm, 0mm, 10mm]],
    faces = [[0, 2, 1], [0, 1, 3], [0, 3, 2], [1, 2, 3]],
);
```

**Prevention:** every edge exactly twice, outward winding, planar faces.

## 13. Mutation, while, and range

**Symptom:** `E0403`, `E0401`, or a parse error.

```om
// wrong
let x = 10mm;
x = 20mm;
let i = 0;
while i < 4 { i = i + 1; }
```

```om
// right
let xs = for i in 0..4 { i * 10mm };
```

**Prevention:** `let` is immutable; there is no `while`; use `0..n` and a `for` expression. `range(...)` is not an
OML function.

## 14. Radius versus diameter

**Symptom:** `E0209` on `r =`, or a hole twice the intended size.

```om
// wrong: d is a diameter, and cylinder has no r parameter
let h = cylinder(h = 10mm, r = 4mm);
```

```om
// right
let h = cylinder(h = 10mm, d = 8mm);
```

**Prevention:** `sphere`, `cylinder`, `cone`, and `torus` take diameters. `offset` takes a radius. Check the unit
column in the reference.

## 15. Parameter metadata

**Symptom:** `E0410`, `E0108`, or a parameter without a slider.

```om
// wrong: label is not a metadata key and the default is outside the range
@param width = 5mm { min = 10mm, max = 100mm, label = "Width" };
```

```om
// right
@param width = 60mm { min = 10mm, max = 100mm, step = 1mm, desc = "Width" };
```

**Prevention:** use `min`, `max`, `step`, `unit`, `desc`, `group`, `options`; keep the default inside the range;
use `=` between the metadata key and value.

## Next

- [Prompting guide](01-prompting-guide.md)
- [AI context pack](00-context-pack.md)
- [Errors](../language/12-errors.md)
